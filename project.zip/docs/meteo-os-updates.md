# Meteo OS — OTA-обновления веб-интерфейса

Система доставки новых версий React-интерфейса (веб-бандла) **без публикации
APK в магазине**. Нативные обновления приложения (RuStore / Google Play /
universal через `StoreUpdateManager`) остаются как были и работают параллельно.

Зачем: если в вебе нашёлся баг или нужен срочный фикс — выкладываем новый
бандл на GitHub Releases, и приложение подтягивает его само.

---

## 0. Версионирование

У Meteo OS **своя линейка версий** (`1.0.0`, `1.0.1`, `1.1.0`, …), полностью
независимая от `versionName` APK (`9.0.3 full`). Это сделано специально,
чтобы обновления интерфейса не путались с нативными обновлениями приложения:

* версия APK — это то, что видит магазин (RuStore / Google Play);
* версия Meteo OS — это версия React-интерфейса внутри приложения;
* встроенная версия задаётся `METEO_OS_VERSION` в `android/app/build.gradle.kts`;
* если новый OTA-релиз требует свежий APK (новые методы моста) — укажите
  `--min-version-code` при упаковке: старые APK **не будут** качать это
  обновление, а покажут пользователю «рекомендуем обновить основное
  приложение» и сразу предложат нативное обновление через магазин.

## 1. Как это работает

```
APK (заводская версия интерфейса в assets/dist)
        │
        ▼ старт
resolveStartUrl() ──► активная OTA-версия?  ──нет──► file:///android_asset/dist/index.html
        │                     │да
        │                     ▼
        │        file:///data/data/ru.wfllive.meteo/files/meteo-os/versions/<v>/index.html
        │
        ▼ прошлый запуск не подтвердился (trial)?
   авто-откат на последнюю рабочую версию или на встроенную
```

Полный цикл обновления:

1. **Проверка** — `meteoOsCheckForUpdates()` качает манифест `meteo-os.json`
   с GitHub (`releases/latest/download/meteo-os.json`).
2. **Загрузка** — `meteoOsDownloadUpdate()` качает zip, на лету считает
   SHA-256, проверяет размер и подпись, распаковывает в
   `files/meteo-os/versions/<версия>/`.
3. **Применение** — по кнопке пользователя `meteoOsApplyUpdate()`:
   версия помечается активной **в режиме trial**, WebView перезагружается.
4. **Подтверждение** — новый бандл после успешного монтирования React зовёт
   `meteoOsReportHealthy()` (автоматически, см. `src/index.jsx`). Версия
   закрепляется как «последняя рабочая».
5. **Авто-откат** — если подтверждения не было (белый экран, краш JS),
   при следующем старте `resolveStartUrl()` откатывается на последнюю
   рабочую версию или на встроенную в APK, а сломанная версия удаляется.
6. **Ручной сброс** — кнопка «Сбросить» в диалоге обновлений возвращает
   встроенную в APK версию и чистит все OTA-файлы.

## 2. Защита

| Механизм | Что даёт |
|---|---|
| только `https://` в манифесте | нельзя подсунуть обновление по http |
| SHA-256 архива | целостность: файл не побился и не подменён |
| RSA-подпись манифеста (SHA256withRSA) | аутентичность: обновление выпустил владелец приватного ключа, даже если GitHub-аккаунт скомпрометирован |
| zip-slip guard + лимиты размера/файлов | архив не может писать вне своей папки и раздуть диск |
| `minVersionCode` | обновление, требующее нового моста, не скачивается на старый APK — вместо этого UI рекомендует обновить основное приложение (статус `requiresAppUpdate`) |
| trial + авто-откат | сломанный бандл живёт максимум один запуск |

Подписывается каноничная строка `"<version>\n<sha256>\n<size>"`.
Публичный ключ вшит в APK (`assets/meteo_os_public.pem`); если его нет,
проверка подписи пропускается (переходный режим), но SHA-256 обязателен всегда.

## 3. Выпуск обновления (шпаргалка)

```bash
# один раз: пара ключей (приватный НЕ коммитится, публичный — в assets APK)
npm run os:keygen
# ...пересобрать и выпустить APK, чтобы публичный ключ попал в приложение

# каждый релиз:
npm run build                                  # свежий бандл в assets/dist
npm run os:pack -- 1.0.1 --notes "Что нового"  # zip + подписанный манифест

gh release create meteo-os-v1.0.1 \
   release/meteo-os/meteo-os-1.0.1.zip \
   release/meteo-os/meteo-os.json \
   --repo wfllive/Meteo-Live-off-9 \
   --title "Meteo OS 1.0.1" --notes "Что нового" --latest
```

Важно:

* релиз обязан быть помечен `--latest` — приложение ищет манифест по
  `releases/latest/download/meteo-os.json`;
* `--min-version-code N` в `os:pack` — если бандл требует новых методов моста,
  укажите минимальный `versionCode` APK;
* при выпуске нового APK поднимите `METEO_OS_VERSION` в
  `android/app/build.gradle.kts` до версии вшитого бандла — иначе приложение
  будет предлагать «обновление» на то, что уже встроено.

## 4. Где что лежит

### Android (Kotlin)

| Файл | Ответственность |
|---|---|
| `ota/MeteoOsUpdateManager.kt` | Вся логика: манифест, загрузка, SHA-256/подпись, распаковка, trial, откат, сброс. |
| `bridge/NativeBridge.kt` | `@JavascriptInterface`-методы `meteoOs*` (JS → native). |
| `bridge/BridgeHost.kt` | `meteoOsManager` + `reloadWebApp(url)` — контракт для Activity. |
| `MainActivity.kt` | Стартует WebView с `resolveStartUrl()`, реализует `reloadWebApp`. |
| `build.gradle.kts` | `METEO_OS_VERSION` (встроенная версия) и `METEO_OS_MANIFEST_URL`. |

### Web (JS)

| Файл | Ответственность |
|---|---|
| `src/native/bridge/androidBridge.js` | Публичное API `AndroidBridge.meteoOs.*`. |
| `src/native/bridge/events.js` | Событие `native:meteoOs`. |
| `src/index.jsx` | Автоматический `reportHealthy()` после монтирования React. |
| `src/drawer/Drawer.jsx` | Состояние обновлений Meteo OS для UI. |
| `src/drawer/Menu/UpdateDialog.jsx` | Диалог с двумя секциями: «Meteo OS» и «Приложение». |
| `src/native/devMock.js` | Эмуляция полного цикла в браузере (`?nativeMock=1`). |

### Инструменты

| Файл | Ответственность |
|---|---|
| `scripts/meteo-os/keygen.mjs` | Генерация RSA-пары (`npm run os:keygen`). |
| `scripts/meteo-os/pack.mjs` | Упаковка zip + подписанный манифест (`npm run os:pack`). |

## 5. Контракт JS ↔ native

JS → native (`window.AndroidBridge`):

| Метод | Возврат | Описание |
|---|---|---|
| `meteoOsGetState()` | JSON | Версии (builtin/active/pending/lastGood), источник, ошибки. |
| `meteoOsCheckForUpdates()` | — | Проверка. Ответ событием. |
| `meteoOsDownloadUpdate()` | — | Загрузка + проверка. Прогресс событиями. |
| `meteoOsApplyUpdate()` | — | Применить pending: перезагрузка WebView. |
| `meteoOsReportHealthy()` | — | Подтвердить успешный старт (иначе авто-откат). |
| `meteoOsResetToBuiltin()` | — | Сброс до встроенной версии. |

native → JS: событие **`native:meteoOs`** с `detail`:

```json
{ "status": "available",          "version": "1.0.1", "size": 4194304, "notes": "…" }
{ "status": "requiresAppUpdate", "version": "1.2.0", "notes": "…" }
{ "status": "upToDate",           "version": "1.0.0" }
{ "status": "downloading", "progress": 42 }
{ "status": "downloaded" }
{ "status": "applying" }
{ "status": "reset" }
{ "status": "error",       "error": "текст ошибки" }
```

## 6. Формат манифеста `meteo-os.json`

```json
{
  "version": "1.0.1",
  "url": "https://github.com/wfllive/Meteo-Live-off-9/releases/download/meteo-os-v1.0.1/meteo-os-1.0.1.zip",
  "sha256": "d2b2…64 hex-символа…9f",
  "size": 4194304,
  "minVersionCode": 0,
  "notes": "Что нового",
  "signature": "base64(RSA-SHA256 от \"version\\nsha256\\nsize\")",
  "publishedAt": "2026-08-17T12:00:00.000Z"
}
```

## 7. Отладка

* Браузер: `?nativeMock=1` — полный цикл эмулируется (проверка → загрузка →
  применение с перезагрузкой страницы → сброс).
* Устройство: `adb logcat | grep MeteoOsUpdate` — все шаги и причины отказов.
* Состояние на устройстве: `files/meteo-os/versions/…` + SharedPreferences
  `meteo_os_prefs` (active/pending/last_good/trial/last_error).
