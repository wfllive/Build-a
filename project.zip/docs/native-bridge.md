# Мост JS ↔ Android + нативная карта

Документ описывает слой связи между React-приложением и Android-обёрткой:
что где лежит, какой контракт, как работает раскладка нативной карты и
как решён вопрос с системной навигацией (navigation bar).

---

## 1. Где что лежит

### Android (Kotlin) — `android/app/src/main/java/ru/wfllive/meteo/bridge/`

| Файл | Ответственность |
|---|---|
| `BridgeHost.kt` | Контракт: что Activity обязана предоставить мосту (тема, реклама, обновления, геолокация). Мост НЕ знает про `MainActivity`. |
| `BridgeChannel.kt` | Единственный канал **native → JS**. Всё через `emit(event, payload)` с JSON-сериализацией (`org.json`), плюс `callGlobal()` для старых колбэков. |
| `SystemInsetsController.kt` | Edge-to-edge, чтение `WindowInsets`, определение типа навигации (жесты / 3 кнопки), рассылка отступов. |
| `MapViewportGeometry.kt` | Чистая математика: CSS-px → px устройства, перевод отступов в координаты контейнера, применение режима `auto/safe/edge`. Без единой ссылки на View — легко читать и отлаживать. |
| `MapWebViewController.kt` | Сам WebView карты: создание, позиционирование, статусы, геолокация, жизненный цикл. |
| `NativeBridge.kt` | Все `@JavascriptInterface` методы (**JS → native**). Регистрируется как `window.AndroidBridge` и `window.Android`. |
| `ThemeBridge.kt` | `window.AndroidTheme` и `window.AndroidApi`. |
| `NativeBridgeManager.kt` | Сборка всего вместе. Именно её вызывает `MainActivity`. |

`WebAppInterface.kt` больше не используется — его обязанности разъехались по
файлам выше (старый код остался в истории git).

### Web (JS) — `src/native/`

| Файл | Ответственность |
|---|---|
| `bridge/core.js` | Низкий уровень: поиск нативных объектов, безопасный вызов, разбор JSON, шина событий. |
| `bridge/events.js` | Имена событий (зеркало Kotlin-объекта `BridgeEvents`). |
| `bridge/androidBridge.js` | Публичное API: `AndroidBridge.map`, `.insets`, `.theme`, `.location`, `.ads`, `.updates`. |
| `safeArea.js` | Раскладывает отступы Android в CSS-переменные. |
| `hooks/useNativeInsets.js` | Отступы в React-виде. |
| `hooks/useNativeMapView.js` | Держит нативную карту точно в границах DOM-слота. |
| `devMock.js` | Эмулятор моста для браузера (`?nativeMock=1`). |
| `index.js` | Единая точка импорта: `import { AndroidBridge } from '@/native'`. |

> Правило: **в компонентах не должно быть `window.Android`** — только `AndroidBridge`.

---

## 2. Контракт JS → native (`window.AndroidBridge`)

| Метод | Возврат | Описание |
|---|---|---|
| `bridgeVersion()` | `Int` | Версия контракта. `2` — текущая. |
| `getAppVersion()` | `String` | Версия приложения. |
| `getDeviceInfo()` | JSON | Производитель, модель, SDK, плотность, планшет ли. |
| `getInsets()` | JSON | Безопасные отступы (px и CSS-px). |
| `requestInsets()` | — | Попросить прислать отступы ещё раз. |
| `isDarkMode()` | `Boolean` | Тёмная тема активна. |
| `getLocationStatus()` | `String` | `granted` / `denied` / `should_show_rationale` / `unknown`. |
| `requestLocationPermission()` | — | Запросить разрешение (раньше метода не было вовсе). |
| `mapUpdate(json)` | JSON | **Главный метод раскладки карты**, см. ниже. |
| `mapSetUrl(url)` | — | Сменить URL без пересчёта геометрии. |
| `mapShow()` / `mapHide()` | — | Показать / спрятать. |
| `mapReload()` | — | Перезагрузить текущий URL. |
| `mapSuspend()` | — | Остановить загрузку и спрятать (WebView жив). |
| `mapRelease()` | — | Уничтожить WebView карты. |
| `mapStatus()` | JSON | Текущий статус и прямоугольник. |
| `getAdFreeState()` / `showRewardedAd()` / `isRewardedAdReady()` / `activateAdFreeFor5Minutes()` | JSON | Реклама. |
| `checkForUpdates()` / `startFlexibleUpdate()` / `installUpdate()` / `checkIsLatestVersion()` | — | Обновления APK через магазин. |
| `meteoOsGetState()` / `meteoOsCheckForUpdates()` / `meteoOsDownloadUpdate()` / `meteoOsApplyUpdate()` / `meteoOsReportHealthy()` / `meteoOsResetToBuiltin()` | JSON / — | **Meteo OS**: OTA-обновления веб-бандла без магазина. Подробно: `docs/meteo-os-updates.md`. |

Старые методы (`updateWebView`, `updateUrl`, `showWebView`, `hideWebView`,
`retryLoading`, `softCleanup`, `onTabChanged`) сохранены — старый JS-бандл
продолжит работать с новым APK.

### Payload `mapUpdate`

```json
{
  "url": "https://map.blitzortung.org",
  "rect":     { "x": 0, "y": 96, "width": 412, "height": 620 },
  "viewport": { "width": 412, "height": 915 },
  "insetsMode": "auto",
  "visible": true
}
```

* `rect` — `element.getBoundingClientRect()` слота, в CSS-пикселях;
* `viewport` — `window.innerWidth / innerHeight` того же WebView;
* `insetsMode` — `auto` (по умолчанию) / `safe` / `edge`.

---

## 3. Контракт native → JS (события)

Каждое событие приходит двумя путями: в шину моста и как `CustomEvent` на
`window` (для старого кода). `AndroidBridge.on(...)` дедуплицирует.

| Событие | detail |
|---|---|
| `native:ready` | `{ version, insets }` |
| `native:insets` | `{ px, css, density, navigationMode, isLandscape, keyboardVisible }` |
| `native:map` | `{ status, url, description, visible }`, где `status` = `loading` / `loaded` / `error` / `offline` / `released` |
| `native:theme` | `{ theme, isDark }` |
| `native:location` | `{ granted, latitude, longitude, accuracy, timestamp, source }` |
| `native:locationPermission` | `{ granted }` |

Legacy-события (`androidThemeChanged`, `androidLocationUpdate`,
`adFreeStateChanged`, `rewardedAdStateChanged`, `updateAvailable`, …) и старые
глобальные колбэки (`window.onWebViewLoaded`, `window.onAndroidLocationData`, …)
продолжают работать.

---

## 4. Почему карта «разъезжалась» и что изменилось

Было:

```js
// JS придумывал отступы из воздуха
const minMargin = 360;             // dp?
const maxMargin = 200;
window.Android.updateWebView(url, 0, mT, W, H - mT - mB, mT / H, mB / H, H > 1000);
```

```kotlin
// Native умножал CSS-px на density и сравнивал с размерами ЭКРАНА
windowManager.defaultDisplay.getMetrics(displayMetrics)   // deprecated
val widthPx = (width * density).toInt()
```

Три источника ошибок:

1. **Магические константы** (`360`, `200`, `74vh`, `isTablet = H > 1000`) —
   подобраны под одно устройство, на другом промахиваются.
2. **`density` вместо реального масштаба.** Если у пользователя изменён размер
   шрифта/масштаб экрана или сайт задаёт свой viewport, `CSS-px * density`
   ≠ реальным пикселям WebView.
3. **Разные системы координат.** JS считал координаты внутри вьюпорта, а native
   сравнивал их с метриками экрана, куда входят статус-бар, навбар и баннер
   рекламы. Отсюда съезды по вертикали.

Стало:

1. JS отдаёт **фактический прямоугольник слота** (`getBoundingClientRect`) —
   никакой арифметики в компонентах.
2. Масштаб считается честно: `scaleX = hostWebView.width / viewport.width`
   (и так же по Y). Работает при любом зуме, шрифте и плотности.
3. Системные отступы переводятся **в координаты контейнера карты**
   (`MapViewportGeometry.localize`), потому что контейнер не равен экрану.
4. Пересчёт происходит нативно при любом изменении размеров/поворота/insets —
   без ожидания round-trip в JS. Плюс на стороне JS: `ResizeObserver`,
   `visualViewport`, `scroll` (capture), `orientationchange` и страховочный
   таймер, всё сведено в один rAF-кадр и с защитой от повторной отправки.

---

## 5. Системные бары и navigation bar

Задача: под кнопки навигации залезать нельзя, но и оставлять чёрную полосу
внизу не хочется.

Решение опирается на insets `tappableElement`:

| Режим навигации | `navigationBars.bottom` | `tappableElement.bottom` | Что делаем |
|---|---|---|---|
| Жесты | ~24dp | **0** | Полоска прозрачная и ничего не перехватывает → карту и фон **тянем до самого края экрана** (edge-to-edge). |
| 3 кнопки | 48dp+ | **48dp+** | Там реальные кнопки → карта обрезается **ровно над ними**, а панель вкладок поднимается на `--app-bottom-gap`. |

### Сами бары — непрозрачные

Статус-бар и системная навигация (назад / домой / недавние) закрашены фоном
темы, контент под ними не просвечивает:

* до Android 15 — напрямую `statusBarColor` / `navigationBarColor`
  (+ `isNavigationBarContrastEnforced = false`);
* с Android 15 эти свойства — no-op, поэтому фон под барами рисует Compose:
  у корневой `Column` есть `background()` на всю площадь и
  `windowInsetsPadding(WindowInsets.systemBars)`. Итог визуально одинаковый.

Контраст иконок баров переключается вместе с темой
(`isAppearanceLightStatusBars` / `isAppearanceLightNavigationBars`).

### Кто и какие отступы применяет

Чтобы отступы не применились дважды, мост отдаёт вебу значения **в координатах
контейнера WebView**, а не всего окна (`SystemInsetsController.contentInsets`):

| Кто | Что делает |
|---|---|
| Compose | отодвигает WebView от статус-бара и навбара, закрашивает их зоны |
| Мост | отдаёт вебу «остаток» — внутри контейнера это обычно нули |
| Веб | добавляет только косметический `--app-bottom-gap` под плавающую панель |
| Нативная карта | вписывается в контейнер, дополнительно проверяя `tappableElement` |

Полные оконные отступы доступны в JS как `insets.windowInsets` — для отладки
и на случай, если Compose-паддинг когда-нибудь отключат: тогда те же формулы
автоматически начнут работать по «оконным» значениям.

Как это устроено технически:

1. Окно переведено в edge-to-edge (`WindowCompat.setDecorFitsSystemWindows(window, false)`)
   — иначе на Android 15+ отступы просто не доедут; на внешний вид баров это
   не влияет, их закрашивает Compose.
2. Реальные отступы уезжают в веб и превращаются в CSS-переменные:

   ```
   --safe-area-top / --safe-area-bottom / --safe-area-left / --safe-area-right
   --nav-inset        сколько реально занято навигацией (жесты → 0)
   --app-bottom-gap   готовый отступ для плавающих панелей
   --tabbar-space     место под нижнюю панель вкладок (измеряется в рантайме)
   ```

   > `--tabbar-space` считает не «64px + отступ», а фактический замер
   > (`src/native/hooks/useTabBarSpace.js`): высота панели **плюс выступающий
   > над ней круг активной вкладки** плюс системный отступ. Нативный WebView
   > карты рисуется поверх веба, поэтому всё, что он накроет, просто исчезнет —
   > карта обязана заканчиваться выше круга.

   А также атрибуты на `<html>`: `data-nav-mode="gesture|buttons|none"`,
   `data-keyboard="open|closed"`, `data-native="true|false"`.

   > Важно: `env(safe-area-inset-bottom)` в Android WebView почти всегда `0`,
   > поэтому вёрстка на нём и уезжала под кнопки. Теперь значения приходят
   > из системы.

4. Нативная карта в режиме `insetsMode: "auto"`:
   * низ прижимается к `hostHeight - tappableBottom` (под кнопки не лезем);
   * если `tappableBottom == 0` и слот и так почти достаёт до низа (порог 48dp),
     карта растягивается до самого края — красивый full-bleed под жестовой полосой;
   * то же самое по бокам в ландшафте (боковой навбар и вырез).

Готовые Tailwind-утилиты: `pt-safe`, `pb-safe`, `pb-nav`, `mb-nav`,
`pb-tabbar`, `mb-tabbar`.

---

## 6. Использование в React

```jsx
import { useRef } from 'react';
import { AndroidBridge, useNativeMapView, useNativeInsets } from '@/native';

function MapScreen({ url, isActive }) {
  const slotRef = useRef(null);
  const { isNative, isLoading, hasError, retry } = useNativeMapView({
    slotRef,
    url,
    active: isActive,
    insetsMode: 'auto',
  });

  return (
    <div ref={slotRef} className="flex-1" style={{ marginBottom: 'var(--tabbar-space)' }}>
      {/* В нативе слот остаётся пустым — в него native кладёт свой WebView */}
      {!isNative && <iframe src={url} className="h-full w-full border-0" />}
    </div>
  );
}
```

Отступы напрямую:

```jsx
const insets = useNativeInsets();
<div style={{ paddingBottom: insets.tappableBottom }} />
```

---

## 7. Отладка без сборки APK

```
npm run dev
# затем открыть:
http://localhost:3000/?nativeMock=1         # жестовая навигация
http://localhost:3000/?nativeMock=buttons   # три кнопки
http://localhost:3000/?nativeMock=1&mockTop=48
```

Мок (`src/native/devMock.js`) рисует статус-бар, навбар и «нативную» карту
там, где её разместил бы Android, повторяя логику `MapViewportGeometry`.
Так видно, что раскладка корректна, ещё до сборки.

Нюанс: мок специально моделирует «худший случай» — контент лежит под барами
(отступы приходят полные). На устройстве бары непрозрачные и Compose уже
отодвигает WebView, поэтому веб получает нули. Проверять вёрстку удобно именно
на моке — если она корректна там, на устройстве точно не уедет.

Логи моста в консоли: добавьте `?bridgeDebug=1`.

На устройстве: `adb logcat | grep -E "NativeBridge|MapWebViewController"`
(в debug-сборке включён подробный лог геометрии).

---

## 8. Чек-лист проверки на устройстве

- [ ] Портрет/ландшафт: карта попадает точно в свой слот, без белых полос.
- [ ] Жестовая навигация: карта доходит до низа, панель вкладок не перекрыта.
- [ ] Три кнопки: карта заканчивается над кнопками, панель вкладок выше кнопок.
- [ ] Планшет / складной: при смене размера окна карта пересчитывается.
- [ ] Split-screen: то же самое.
- [ ] Переход на другую вкладку: карта скрывается, трафик не идёт.
- [ ] Возврат на вкладку карты: показывается мгновенно, без перезагрузки.
- [ ] Открытие модалки «Добавить в избранное»: карта не перекрывает диалог.
- [ ] Ошибка/офлайн: показывается веб-экран ошибки, кнопка «Повторить» работает.
- [ ] Смена темы: статус-бар и навбар непрозрачные, в цвет темы, иконки контрастные.
- [ ] Круг активной вкладки не перекрыт картой (см. `useTabBarSpace`).

---

## 9. Сборка: R8 и keep-правила

### Версия R8

Проект собирается **Kotlin 2.3.0**, а AGP 8.10.0 несёт внутри **R8 8.10.x**,
который читает метаданные Kotlin только до 2.2. Отсюда в релизе появлялось:

```
WARNING: R8: An error occurred when parsing kotlin metadata...
```

По [таблице совместимости Google](https://developer.android.com/build/kotlin-support)
для Kotlin 2.3 нужен **R8 8.13.19**. Он подменяется в `android/settings.gradle`
(способ официальный, из README R8):

```groovy
pluginManagement {
    buildscript {
        repositories { google(); mavenCentral() }
        dependencies { classpath("com.android.tools:r8:8.13.19") }
    }
    repositories { /* ... */ }
}
```

| Kotlin | Нужен AGP | Нужен R8 |
|---|---|---|
| 2.3 | 8.2.2 – 8.13 | **8.13.19** |
| 2.2 | 7.3.1 – 8.10 | 8.10.21 |
| 2.1 | 7.4.2 – 8.7.2 | 8.6.17 |

Альтернатива на будущее: перейти на **AGP 8.13.2** (он уже содержит R8 8.13.19)
и Gradle 8.13+ — тогда блок с подменой удаляется целиком.

Если сборка когда-нибудь упадёт внутри `minify*WithR8` — просто удалите блок
`buildscript` из `settings.gradle`: вернётся R8 из AGP, а предупреждения
безвредны (метаданные Kotlin нужны только для `kotlin-reflect`, здесь он
не используется).

### Keep-правила для моста

Методы моста вызываются **только из JavaScript** — в байткоде на них нет ни
одной ссылки, поэтому R8 вправе их удалить. В debug (minify выключен) всё
работает, а в release `window.AndroidBridge` молча оказывается пустым.

В `android/app/proguard-rules.pro`:

```proguard
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }
-keep class ru.wfllive.meteo.bridge.** { *; }
-keepnames class ru.wfllive.meteo.bridge.**
```

> Проверять мост нужно именно на **release**-сборке: `bridgeVersion()` должен
> вернуть `2`, а `window.AndroidBridge.mapUpdate` — существовать.
> Быстрая проверка из консоли (`?bridgeDebug=1` или Chrome DevTools):
> `AndroidBridge.version` и `AndroidBridge.supports('mapUpdate')`.

---

## 10. Release vs debug: почему был белый экран

Это самая коварная разница в проекте, стоит держать её в голове:

| | debug | release |
|---|---|---|
| Откуда грузится веб | `http://localhost:3000` (dev-сервер) | `file:///android_asset/dist/index.html` |
| Origin | обычный, http | **opaque (`null`)** |
| History API (`pushState`/`replaceState`) | работает | **запрещён** |
| WebView-отладка | включена | выключена |
| Логи | все | только `Log.w` / `Log.e` (R8) |

### Что сломалось

`BrowserRouter` на старте вызывает `replaceState` (маршрут
`file:///android_asset/dist/index.html` не совпадает ни с одним `path`, и
срабатывает `<Navigate to="/" replace />`). На origin `null` это исключение:

```
SecurityError: Failed to execute 'replaceState' on 'History':
A history state object with URL 'file:///' cannot be created
in a document with origin 'null'.
```

Исключение улетает наверх, React не монтирует дерево — **пустой экран**,
причём только в release.

### Что сделано

* `src/router.jsx` — на `file://` используется **HashRouter** (меняется только
  фрагмент `#/map`, это разрешено), на http — прежний `BrowserRouter`;
* `src/native/bootstrap.js` — импортируется первым: страхует `localStorage`
  (на opaque origin он тоже может бросать) и отправляет необработанные ошибки
  JS в Logcat через мост;
* `onConsoleMessage` в `MainActivity` пишет ошибки консоли в Logcat **и в
  release** (раньше только в debug);
* из `-assumenosideeffects` убраны `Log.w` и `Log.e` — иначе R8 вырезал
  единственный способ хоть что-то увидеть;
* `NativeBridgeManager` через 4 секунды после загрузки проверяет `#root`
  и при пустом дереве прямо пишет в Logcat «БЕЛЫЙ ЭКРАН».

### Смоук-тест перед релизом

```bash
npm i -D jsdom          # один раз
node scripts/release-smoke.mjs
```

Скрипт собирает приложение и запускает его в jsdom **с origin `file://`** и
моком моста — то есть ровно в условиях release-сборки. Проверяет, что React
смонтировался в `#root` и что на старте нет исключений. Именно этим тестом был
найден и подтверждён баг с `BrowserRouter`.

### Если белый экран повторится

```bash
adb logcat | grep -E "WebViewConsole|WebLog/js-error|NativeBridge"
```

В логе будет либо конкретная ошибка JS, либо строка «БЕЛЫЙ ЭКРАН: #root пуст».
