# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile


# Основные правила Android
-optimizationpasses 5
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-dontpreverify
-verbose
-optimizations !code/simplification/arithmetic,!field/*,!class/merging/*

# Сохраняем важные классы и методы
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Application
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.content.ContentProvider
-keep public class * extends android.app.backup.BackupAgentHelper
-keep public class * extends android.preference.Preference
-keep public class * extends androidx.fragment.app.Fragment

# Сохраняем ViewBinding
-keep class * implements androidx.viewbinding.ViewBinding {
    public static * bind(android.view.View);
    public static * inflate(android.view.LayoutInflater);
}

# Сохраняем Kotlin метаданные
-keep class kotlin.Metadata { *; }
-keepclassmembers class ** {
    @org.jetbrains.annotations.NotNull *;
    @org.jetbrains.annotations.Nullable *;
}

# Coroutines
-keepnames class kotlinx.coroutines.android.AndroidExceptionPreHandler
-keepnames class kotlinx.coroutines.android.AndroidDispatcherFactory

# Жизненный цикл и LiveData
-keep class androidx.lifecycle.** { *; }
-keep class * implements androidx.lifecycle.DefaultLifecycleObserver

# RuStore SDK
-keep class ru.rustore.sdk.appupdate.** { *; }
-keep class * implements ru.rustore.sdk.core.utils.provider.Provider

# Убираем из релиза только «болтливые» логи.
# Log.w и Log.e ОСТАВЛЯЕМ: без них белый экран или отвалившийся мост
# невозможно диагностировать — в release WebView-отладка выключена,
# и Logcat остаётся единственным источником информации.
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}

# Сохраняем сериализуемые классы
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# Kotlin Parcelize
-keep class * implements android.os.Parcelable {
  public static final android.os.Parcelable$Creator *;
}

# Рефлексия (если используется)
-keepattributes RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations

# Сохраняем нативные методы
-keepclasseswithmembernames class * {
    native <methods>;
}

# Сохраняем custom views
-keepclassmembers public class * extends android.view.View {
   void set*(***);
   *** get*();
}

# Сохраняем обработчики кликов
-keepclassmembers class * extends android.content.Context {
   public void *(android.view.View);
}





# ── JS ↔ Android мост ────────────────────────────────────────────────────────
#
# Методы моста вызываются ТОЛЬКО из JavaScript — в байткоде на них нет ни одной
# статической ссылки. Без keep-правил R8 имеет полное право их удалить: в debug
# (minify выключен) всё работает, а в release window.AndroidBridge молча
# оказывается пустым и карта/тема/реклама перестают отвечать.
#
# Правило по аннотации есть и в proguard-android-optimize.txt, но дублируем
# явно: слишком дорогая поломка, чтобы полагаться на дефолты.

-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Весь пакет моста целиком: NativeBridge / ThemeBridge / ApiBridge и их методы,
# а также классы, которые они возвращают в JS.
-keep class ru.wfllive.meteo.bridge.** { *; }
-keepnames class ru.wfllive.meteo.bridge.**

# WebView-клиенты карты (методы дёргает система через рефлексию/JNI).
-keepclassmembers class * extends android.webkit.WebViewClient {
    <methods>;
}
-keepclassmembers class * extends android.webkit.WebChromeClient {
    <methods>;
}

# org.json используется мостом для сериализации — на всякий случай.
-dontwarn org.json.**
