# Защита чувствительных данных
-keepclassmembers class * {
    private String API_KEY;
    private String SECRET;
}

# Защита от деобфускации
-useuniqueclassmembernames
-dontobfuscate

# Сохраняем R классы
-keep class **.R
-keep class **.R$* {
    <fields>;
}