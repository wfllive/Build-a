// ui/theme/Color.kt
package ru.wfllive.meteo.ui.theme

import androidx.compose.ui.graphics.Color

// Светлая тема
val LightBackground = Color(0xFFFFFFFF)
val LightStatusBar = Color(0xFFFFFFFF)
val LightNavigationBar = Color(0xFFF5F5F5)
val LightTextPrimary = Color(0xFF333333)
val LightSplashBackground = Color(0xFFFFFFFF)

// Тёмная тема
val DarkBackground = Color(0xFF111827)
val DarkStatusBar = Color(0xFF111827)
val DarkNavigationBar = Color(0xFF111827)
val DarkSurface = Color(0xFF111827)
val DarkTextPrimary = Color(0xFFFFFFFF)
val DarkSplashBackground = Color(0xFF111827)

// Общие цвета
val ColorPrimary = Color(0xFF2196F3)
val ColorAccent = Color(0xFF03DAC5)
val White = Color(0xFFFFFFFF)