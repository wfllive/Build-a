package ru.wfllive.meteo.bridge

import android.graphics.Rect
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Режим работы с системными отступами для нативной карты.
 */
enum class InsetsMode {
    /** Полный экран, отступы игнорируются (кроме реально «кликабельных» зон). */
    EDGE,

    /** Строго внутри безопасной зоны. */
    SAFE,

    /**
     * ХИТРОСТЬ (по умолчанию):
     *  • жестовая навигация → карту тянем до самого низа экрана (полоска прозрачная,
     *    ничего не перекрывает, карта выглядит edge-to-edge);
     *  • 3 кнопки → карта заканчивается ровно над кнопками (под них лезть нельзя).
     * То же самое по бокам в ландшафте (навбар/вырез).
     */
    AUTO;

    companion object {
        fun from(value: String?): InsetsMode = when (value?.lowercase()) {
            "edge", "edgetoedge", "edge-to-edge" -> EDGE
            "safe" -> SAFE
            else -> AUTO
        }
    }
}

/**
 * Запрос на раскладку карты, который прислал JS.
 *
 * ВАЖНО: [x]/[y]/[width]/[height] — это CSS-пиксели, полученные из
 * `element.getBoundingClientRect()` внутри ГЛАВНОГО WebView, а
 * [viewportWidth]/[viewportHeight] — размер того же вьюпорта (window.innerWidth/innerHeight).
 *
 * Именно наличие вьюпорта позволяет native посчитать масштаб честно:
 *      scaleX = hostWebView.width / viewportWidth
 * вместо угадывания через DisplayMetrics.density (старый код умножал CSS-px
 * на density и промахивался на устройствах с нестандартным зумом/шрифтом,
 * планшетах и в ландшафте).
 */
data class MapLayoutRequest(
    val url: String?,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val viewportWidth: Float,
    val viewportHeight: Float,
    val mode: InsetsMode = InsetsMode.AUTO,
    val visible: Boolean = true
) {
    companion object {
        fun fromJson(raw: String): MapLayoutRequest {
            val json = JSONObject(raw)
            val rect = json.optJSONObject("rect") ?: JSONObject()
            val viewport = json.optJSONObject("viewport") ?: JSONObject()
            return MapLayoutRequest(
                url = json.optString("url").ifEmpty { null },
                x = rect.optDouble("x", 0.0).toFloat(),
                y = rect.optDouble("y", 0.0).toFloat(),
                width = rect.optDouble("width", 0.0).toFloat(),
                height = rect.optDouble("height", 0.0).toFloat(),
                viewportWidth = viewport.optDouble("width", 0.0).toFloat(),
                viewportHeight = viewport.optDouble("height", 0.0).toFloat(),
                mode = InsetsMode.from(json.optString("insetsMode", "auto")),
                visible = json.optBoolean("visible", true)
            )
        }
    }
}

/**
 * Чистая математика раскладки — без View, легко проверяется и отлаживается.
 */
object MapViewportGeometry {

    /** Насколько близко к краю должен быть запрошенный прямоугольник, чтобы «прилипнуть» к нему. */
    private const val EDGE_SNAP_DP = 48f

    /** Минимальный размер, ниже которого карту показывать бессмысленно. */
    private const val MIN_SIZE_PX = 8

    /**
     * Переводит оконные отступы в систему координат контейнера карты.
     *
     * Контейнер обычно НЕ занимает всё окно: сверху — статус-бар и баннер,
     * поэтому «bottom = 120px» окна может означать «bottom = 120px» контейнера,
     * а может и «0», если контейнер и так заканчивается выше навбара.
     * Старый код сравнивал координаты веба с метриками ЭКРАНА — отсюда и разъезды.
     */
    fun localize(
        insets: SystemInsets,
        containerLeft: Int,
        containerTop: Int,
        containerWidth: Int,
        containerHeight: Int,
        windowWidth: Int,
        windowHeight: Int
    ): SystemInsets {
        if (containerWidth <= 0 || containerHeight <= 0) return insets

        val gapBottom = max(0, windowHeight - (containerTop + containerHeight))
        val gapRight = max(0, windowWidth - (containerLeft + containerWidth))

        fun localTop(value: Int) = max(0, value - containerTop).coerceAtMost(containerHeight)
        fun localBottom(value: Int) = max(0, value - gapBottom).coerceAtMost(containerHeight)
        fun localLeft(value: Int) = max(0, value - containerLeft).coerceAtMost(containerWidth)
        fun localRight(value: Int) = max(0, value - gapRight).coerceAtMost(containerWidth)

        return insets.copy(
            top = localTop(insets.top),
            bottom = localBottom(insets.bottom),
            left = localLeft(insets.left),
            right = localRight(insets.right),
            tappableBottom = localBottom(insets.tappableBottom),
            tappableLeft = localLeft(insets.tappableLeft),
            tappableRight = localRight(insets.tappableRight),
            imeBottom = localBottom(insets.imeBottom),
            cutoutTop = localTop(insets.cutoutTop),
            cutoutBottom = localBottom(insets.cutoutBottom)
        )
    }

    /**
     * @param hostWidth  ширина главного WebView в px устройства
     * @param hostHeight высота главного WebView в px устройства
     *
     * Контейнер нативной карты — сосед главного WebView в одном FrameLayout
     * с MATCH_PARENT, поэтому его система координат совпадает с вьюпортом веба.
     */
    fun resolve(
        request: MapLayoutRequest,
        hostWidth: Int,
        hostHeight: Int,
        insets: SystemInsets
    ): Rect {
        if (hostWidth <= 0 || hostHeight <= 0) return Rect(0, 0, 0, 0)

        val density = if (insets.density > 0f) insets.density else 1f

        // 1. Масштаб CSS-px → px устройства. Считаем по вьюпорту, а не по density.
        val scaleX = if (request.viewportWidth > 0f) hostWidth / request.viewportWidth else density
        val scaleY =
            if (request.viewportHeight > 0f) hostHeight / request.viewportHeight else density

        var left = (request.x * scaleX).roundToInt()
        var top = (request.y * scaleY).roundToInt()
        var right = ((request.x + request.width) * scaleX).roundToInt()
        var bottom = ((request.y + request.height) * scaleY).roundToInt()

        // 2. Никогда не выходим за пределы контейнера.
        left = left.coerceIn(0, hostWidth)
        right = right.coerceIn(0, hostWidth)
        top = top.coerceIn(0, hostHeight)
        bottom = bottom.coerceIn(0, hostHeight)

        // 3. Учитываем системные бары.
        val snap = (EDGE_SNAP_DP * density).roundToInt()

        when (request.mode) {
            InsetsMode.SAFE -> {
                top = max(top, insets.top)
                bottom = min(bottom, hostHeight - insets.bottom)
                left = max(left, insets.left)
                right = min(right, hostWidth - insets.right)
            }

            InsetsMode.EDGE -> {
                // Даже в edge-режиме не залезаем под РЕАЛЬНЫЕ кнопки навигации.
                bottom = min(bottom, hostHeight - insets.tappableBottom)
                left = max(left, insets.tappableLeft)
                right = min(right, hostWidth - insets.tappableRight)
            }

            InsetsMode.AUTO -> {
                // Низ: тянемся до края ТОЛЬКО если там ничего не кликается (жесты).
                val safeBottomLimit = hostHeight - insets.tappableBottom
                bottom = min(bottom, safeBottomLimit)
                if (insets.tappableBottom == 0 && bottom >= hostHeight - insets.bottom - snap) {
                    bottom = hostHeight
                }

                // Бока: в ландшафте навбар/вырез уезжает вбок.
                val safeLeftLimit = insets.tappableLeft
                val safeRightLimit = hostWidth - insets.tappableRight
                left = max(left, safeLeftLimit)
                right = min(right, safeRightLimit)
                if (insets.tappableLeft == 0 && left <= insets.left + snap) left = 0
                if (insets.tappableRight == 0 && right >= hostWidth - insets.right - snap) {
                    right = hostWidth
                }

                // Верх: под статус-бар не лезем, если веб этого явно не попросил
                // (веб уже добавил свой safe-area padding, поэтому просто страхуемся).
                top = max(top, min(insets.top, insets.cutoutTop))
            }
        }

        if (right - left < MIN_SIZE_PX || bottom - top < MIN_SIZE_PX) {
            return Rect(0, 0, 0, 0)
        }

        return Rect(left, top, right, bottom)
    }
}
