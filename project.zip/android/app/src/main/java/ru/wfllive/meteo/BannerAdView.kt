/*package ru.wfllive.meteo

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.yandex.mobile.ads.kmp.banner.Banner
import com.yandex.mobile.ads.kmp.banner.BannerAdSize
import com.yandex.mobile.ads.kmp.banner.rememberBannerAdState
import com.yandex.mobile.ads.kmp.common.AdRequest

private val BannerHeight = 50.dp

@Composable
fun BannerAdView(
    modifier: Modifier = Modifier,
    adUnitId: String = "demo-banner-yandex"
) {
    BoxWithConstraints(
        modifier = modifier.fillMaxWidth()
    ) {
        val bannerWidth = maxWidth

        val bannerState = rememberBannerAdState(
            adSize = BannerAdSize.Inline(bannerWidth, BannerHeight)
        )

        LaunchedEffect(adUnitId, bannerWidth) {
            bannerState.loadAd(AdRequest(adUnitId = adUnitId))
        }

        Banner(
            state = bannerState,
            modifier = Modifier
                .fillMaxWidth()
                .height(BannerHeight)
        )
    }
}*/

package ru.wfllive.meteo

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.yandex.mobile.ads.kmp.banner.Banner
import com.yandex.mobile.ads.kmp.banner.BannerAdSize
import com.yandex.mobile.ads.kmp.banner.rememberBannerAdState
import com.yandex.mobile.ads.kmp.common.AdRequest

private val BannerHeight = 50.dp

@Composable
fun BannerAdView(
    modifier: Modifier = Modifier,
    adUnitId: String = "R-M-19371636-1",
    refreshIntervalMillis: Long = 35_000L // 40 секунд
) {
    BoxWithConstraints(
        modifier = modifier.fillMaxWidth()
    ) {
        val bannerWidth = maxWidth

        val bannerState = rememberBannerAdState(
            adSize = BannerAdSize.Inline(bannerWidth, BannerHeight)
        )

        // Автообновление рекламы
        LaunchedEffect(adUnitId, bannerWidth) {
            while (true) {
                bannerState.loadAd(AdRequest(adUnitId = adUnitId))
                kotlinx.coroutines.delay(refreshIntervalMillis)
            }
        }

        Banner(
            state = bannerState,
            modifier = Modifier
                .fillMaxWidth()
                .height(BannerHeight)
        )
    }
}