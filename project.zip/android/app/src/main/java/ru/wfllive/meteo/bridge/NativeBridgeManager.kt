package ru.wfllive.meteo.bridge

import android.location.Location
import android.webkit.WebView
import android.widget.FrameLayout
import org.json.JSONObject

/**
 * Сборка всего моста в одном месте.
 *
 * MainActivity больше не занимается @JavascriptInterface-ами, геометрией карты
 * и системными отступами — она только создаёт менеджер и дёргает его на события
 * жизненного цикла:
 *
 *   private val bridge by lazy { NativeBridgeManager(this, apiKey) }
 *
 *   bridge.install(mainWebView, mapContainer, BuildConfig.DEBUG)   // один раз при создании view
 *   bridge.onWebAppReady()                                         // из onPageFinished
 *   bridge.onLocationPermissionResult(granted)                     // из onRequestPermissionsResult
 *   bridge.onLocationChanged(location)                             // из LocationListener
 *   bridge.onPause() / onResume() / onDestroy() / onConfigurationChanged()
 */
class NativeBridgeManager(
    private val host: BridgeHost,
    apiKey: String
) {

    val channel = BridgeChannel(host.hostActivity)
    val insets = SystemInsetsController(host.hostActivity, channel)
    val map = MapWebViewController(host.hostActivity, channel)
    val theme = ThemeBridge(host, channel)

    private val bridge = NativeBridge(host, channel, insets, map)
    private val api = ApiBridge(apiKey)

    private var installed = false
    private var mapContainer: FrameLayout? = null

    /**
     * @param mainWebView  главный WebView приложения (React)
     * @param mapContainer прозрачный FrameLayout поверх него — дом для карты
     */
    fun install(mainWebView: WebView, mapContainer: FrameLayout, verboseLogs: Boolean = false) {
        if (installed) return
        installed = true
        this.mapContainer = mapContainer

        BuildLog.VERBOSE = verboseLogs

        channel.attach(mainWebView)
        map.attach(mapContainer, mainWebView) { insets.current }

        insets.enableEdgeToEdge()
        insets.attach(mapContainer) { map.onInsetsChanged() }

        mainWebView.addJavascriptInterface(bridge, NativeBridge.JS_NAME)
        mainWebView.addJavascriptInterface(bridge, NativeBridge.JS_LEGACY_NAME)
        mainWebView.addJavascriptInterface(theme, ThemeBridge.JS_NAME)
        mainWebView.addJavascriptInterface(api, ApiBridge.JS_NAME)
    }

    /** Веб загрузился: отдаём стартовое состояние (версия, insets, тема). */
    fun onWebAppReady() {
        channel.emit(
            BridgeEvents.READY,
            JSONObject()
                .put("version", NativeBridge.BRIDGE_VERSION)
                .put("insets", insets.current.toJson())
        )
        insets.refresh()
        insets.resend()
        theme.notify()
    }

    fun onConfigurationChanged() {
        insets.refresh()
        map.onInsetsChanged()
        theme.notify()
    }

    fun onLocationPermissionResult(granted: Boolean) {
        map.onLocationPermissionResult(granted)

        channel.emit(
            BridgeEvents.LOCATION_PERMISSION,
            JSONObject().put("granted", granted)
        )
        // Legacy
        channel.callGlobal("onAndroidLocationPermissionResult", granted)
    }

    fun onLocationChanged(location: Location) {
        val payload = JSONObject()
            .put("granted", true)
            .put("latitude", location.latitude)
            .put("longitude", location.longitude)
            .put("accuracy", location.accuracy.toDouble())
            .put("timestamp", location.time)
            .put("source", "android")

        channel.emit(BridgeEvents.LOCATION, payload)
        // Legacy
        channel.callGlobal("onAndroidLocationData", payload)
    }

    fun notifyAdState(stateJson: String) {
        runCatching { JSONObject(stateJson) }
            .onSuccess { channel.emit(BridgeEvents.LEGACY_AD_FREE, it) }
    }

    fun notifyRewardedState(status: String, isReady: Boolean, stateJson: String) {
        val state = runCatching { JSONObject(stateJson) }.getOrDefault(JSONObject())
        channel.emit(
            BridgeEvents.LEGACY_REWARDED,
            JSONObject()
                .put("status", status)
                .put("isReady", isReady)
                .put("adState", state)
        )
    }

    fun onPause() = map.onPause()

    fun onResume() {
        map.onResume()
        insets.refresh()
    }

    fun onDestroy() {
        mapContainer?.let { insets.detach(it) }
        map.release()
        channel.detach()
        installed = false
    }
}
