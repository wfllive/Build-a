/*package ru.wfllive.meteo

import android.util.Log
import com.yandex.mobile.ads.kmp.common.AdError
import com.yandex.mobile.ads.kmp.common.AdRequest
import com.yandex.mobile.ads.kmp.common.ImpressionData
import com.yandex.mobile.ads.kmp.rewarded.Reward
import com.yandex.mobile.ads.kmp.rewarded.RewardedAd
import com.yandex.mobile.ads.kmp.rewarded.RewardedAdEventListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class RewardedAdManager(
    private val adUnitId: String,
    private val scope: CoroutineScope,
    // Принимаем suspend-функцию загрузки вместо конкретного типа loader
    private val loadAdFn: suspend (AdRequest) -> RewardedAd,
    private val onRewarded: () -> Unit,
    private val onDismissed: () -> Unit,
    private val onError: (String) -> Unit,
    private val onLoaded: () -> Unit
) {
    private var rewardedAd: RewardedAd? = null
    private var isLoading = false
    private var isRewarded = false
    private var loadJob: Job? = null

    companion object {
        private const val TAG = "RewardedAdManager"
    }

    fun load() {
        if (isLoading) {
            Log.d(TAG, "Already loading, skip")
            return
        }

        destroyAd()
        isLoading = true
        isRewarded = false

        Log.d(TAG, "Loading rewarded ad: $adUnitId")

        loadJob = scope.launch(Dispatchers.Main) {
            try {
                val ad = loadAdFn(AdRequest(adUnitId = adUnitId))
                rewardedAd = ad
                isLoading = false
                Log.d(TAG, "Rewarded ad loaded successfully")
                onLoaded()
            } catch (e: Exception) {
                isLoading = false
                Log.e(TAG, "Rewarded ad failed to load: ${e.message}")
                onError("load_error: ${e.message}")
            }
        }
    }

    fun show() {
        val ad = rewardedAd
        if (ad == null) {
            Log.w(TAG, "Rewarded ad not ready")
            onError("not_ready")
            return
        }

        ad.setAdEventListener(object : RewardedAdEventListener {
            override fun onAdShown() {
                Log.d(TAG, "Rewarded ad shown")
            }

            override fun onAdFailedToShow(adError: AdError) {
                Log.e(TAG, "Failed to show: ${adError.description}")
                onError("show_error: ${adError.description}")
                destroyAd()
            }

            override fun onAdDismissed() {
                Log.d(TAG, "Dismissed, rewarded=$isRewarded")
                val wasRewarded = isRewarded
                destroyAd()
                onDismissed()

                if (wasRewarded) {
                    onRewarded()
                }

                // Предзагружаем следующее
                scope.launch(Dispatchers.Main) {
                    delay(500)
                    load()
                }
            }

            override fun onAdClicked() {
                Log.d(TAG, "Rewarded ad clicked")
            }

            override fun onAdImpression(impressionData: ImpressionData?) {
                Log.d(TAG, "Rewarded ad impression")
            }

            override fun onRewarded(reward: Reward) {
                Log.d(TAG, "User rewarded: type=${reward.type}, amount=${reward.amount}")
                isRewarded = true
            }
        })

        ad.show()
    }

    fun isReady(): Boolean = rewardedAd != null && !isLoading

    fun isCurrentlyLoading(): Boolean = isLoading

    private fun destroyAd() {
        try {
            rewardedAd?.setAdEventListener(null)
            rewardedAd = null
        } catch (e: Exception) {
            Log.e(TAG, "Error destroying ad", e)
        }
    }

    fun destroy() {
        loadJob?.cancel()
        destroyAd()
        isLoading = false
    }
}*/


package ru.wfllive.meteo

import android.util.Log
import com.yandex.mobile.ads.kmp.common.AdError
import com.yandex.mobile.ads.kmp.common.AdRequest
import com.yandex.mobile.ads.kmp.common.ImpressionData
import com.yandex.mobile.ads.kmp.rewarded.Reward
import com.yandex.mobile.ads.kmp.rewarded.RewardedAd
import com.yandex.mobile.ads.kmp.rewarded.RewardedAdEventListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class RewardedAdManager(
    private val adUnitId: String,
    private val scope: CoroutineScope,
    private val loadAdFn: suspend (AdRequest) -> RewardedAd,
    private val onRewarded: () -> Unit,
    private val onDismissed: () -> Unit,
    private val onError: (String) -> Unit,
    private val onLoaded: () -> Unit
) {
    private var rewardedAd: RewardedAd? = null
    private var isLoading = false
    private var isRewarded = false
    private var isShowing = false      // ← защита от двойного показа
    private var isDestroyed = false    // ← защита от загрузки после destroy
    private var loadJob: Job? = null
    private var reloadJob: Job? = null // ← отдельный job для перезагрузки

    companion object {
        private const val TAG = "RewardedAdManager"
    }

    fun load() {
        // Не загружаем если уже уничтожены или загружаем
        if (isDestroyed) {
            Log.d(TAG, "Already destroyed, skip load")
            return
        }

        if (isLoading) {
            Log.d(TAG, "Already loading, skip")
            return
        }

        destroyAd()
        isLoading = true
        isRewarded = false
        isShowing = false

        Log.d(TAG, "Loading rewarded ad: $adUnitId")

        loadJob = scope.launch(Dispatchers.Main) {
            try {
                val ad = loadAdFn(AdRequest(adUnitId = adUnitId))

                // Проверяем, не уничтожены ли мы пока грузились
                if (isDestroyed) {
                    ad.setAdEventListener(null)
                    return@launch
                }

                rewardedAd = ad
                isLoading = false
                Log.d(TAG, "Rewarded ad loaded successfully")
                onLoaded()
            } catch (e: Exception) {
                if (isDestroyed) return@launch
                isLoading = false
                Log.e(TAG, "Rewarded ad failed to load: ${e.message}")
                onError("load_error: ${e.message}")
            }
        }
    }

    fun show() {
        // Защита от двойного показа
        if (isShowing) {
            Log.w(TAG, "Already showing, skip")
            return
        }

        if (isDestroyed) {
            Log.w(TAG, "Already destroyed, skip show")
            return
        }

        val ad = rewardedAd
        if (ad == null) {
            Log.w(TAG, "Rewarded ad not ready")
            onError("not_ready")
            return
        }

        isShowing = true

        ad.setAdEventListener(object : RewardedAdEventListener {
            override fun onAdShown() {
                Log.d(TAG, "Rewarded ad shown")
            }

            override fun onAdFailedToShow(adError: AdError) {
                Log.e(TAG, "Failed to show: ${adError.description}")
                isShowing = false
                onError("show_error: ${adError.description}")
                destroyAd()
            }

            override fun onAdDismissed() {
                Log.d(TAG, "Dismissed, rewarded=$isRewarded")
                val wasRewarded = isRewarded
                isShowing = false
                destroyAd()
                onDismissed()

                if (wasRewarded) {
                    onRewarded()
                }

                // Предзагружаем следующее только если не уничтожены
                reloadJob = scope.launch(Dispatchers.Main) {
                    delay(500)
                    if (!isDestroyed) {
                        load()
                    }
                }
            }

            override fun onAdClicked() {
                Log.d(TAG, "Rewarded ad clicked")
            }

            override fun onAdImpression(impressionData: ImpressionData?) {
                Log.d(TAG, "Rewarded ad impression")
            }

            override fun onRewarded(reward: Reward) {
                Log.d(TAG, "User rewarded: type=${reward.type}, amount=${reward.amount}")
                isRewarded = true
            }
        })

        ad.show()
    }

    fun isReady(): Boolean = rewardedAd != null && !isLoading && !isDestroyed

    fun isCurrentlyLoading(): Boolean = isLoading

    private fun destroyAd() {
        try {
            rewardedAd?.setAdEventListener(null)
            rewardedAd = null
        } catch (e: Exception) {
            Log.e(TAG, "Error destroying ad", e)
        }
    }

    fun destroy() {
        isDestroyed = true
        loadJob?.cancel()
        reloadJob?.cancel()
        destroyAd()
        isLoading = false
        isShowing = false
        Log.d(TAG, "RewardedAdManager destroyed")
    }
}