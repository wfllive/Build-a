

package ru.wfllive.meteo

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import androidx.appcompat.app.AlertDialog
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.rustore.sdk.remoteconfig.AppId
import ru.rustore.sdk.remoteconfig.AppVersion
import ru.rustore.sdk.remoteconfig.ConfigRequestParameter
import ru.rustore.sdk.remoteconfig.ConfigRequestParameterProvider
import ru.rustore.sdk.remoteconfig.Language
import ru.rustore.sdk.remoteconfig.RemoteConfigClient
import ru.rustore.sdk.remoteconfig.RemoteConfigClientBuilder
import ru.rustore.sdk.remoteconfig.RemoteConfigClientEventListener
import ru.rustore.sdk.remoteconfig.RemoteConfigException
import ru.rustore.sdk.remoteconfig.UpdateBehaviour
import java.util.Locale
import java.util.concurrent.CompletableFuture
import ru.wfllive.meteo.ui.theme.MeteoTheme

import androidx.compose.ui.graphics.toArgb
import ru.wfllive.meteo.ui.theme.DarkBackground

class ForceUpdateManager(private val context: Context) {

    private val TAG = "ForceUpdateManager"

    private lateinit var remoteConfigClient: RemoteConfigClient
    private var remoteConfig: RemoteConfig? = null

    private var dialogRef: AlertDialog? = null

    data class RemoteConfig(
        val technicalWorkActive: Boolean,
        val minVersion: String,
        val forceUpdate: Boolean,
        val technicalWorkMessage: Map<String, String> = emptyMap()
    )

    init {
        initializeRemoteConfig()
    }

    private fun initializeRemoteConfig() {
        try {
            val appId = AppId("301e387e-37e7-4f24-808d-453418e1b009")

            val parameterProvider = object : ConfigRequestParameterProvider {
                override fun getConfigRequestParameter(): ConfigRequestParameter {
                    return ConfigRequestParameter(
                        language = Language(Locale.getDefault().language),
                    )
                }
            }

            remoteConfigClient = RemoteConfigClientBuilder(
                appId = appId,
                context = context.applicationContext
            ).apply {
                setAppVersion(AppVersion(getCurrentVersionName()))
                setConfigRequestParameterProvider(parameterProvider)
                setUpdateBehaviour(UpdateBehaviour.Actual)
                setRemoteConfigClientEventListener(object : RemoteConfigClientEventListener {
                    override fun backgroundJobErrors(exception: RemoteConfigException.BackgroundConfigUpdateError) {}
                    override fun firstLoadComplete() {}
                    override fun initComplete() {}
                    override fun memoryCacheUpdated() {}
                    override fun persistentStorageUpdated() {}
                    override fun remoteConfigNetworkRequestFailure(throwable: Throwable) {}
                })
            }.build()

            remoteConfigClient.init()
            Log.d(TAG, "RemoteConfig client initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing RemoteConfig client", e)
        }
    }

    fun startForceUpdate(activity: Activity, updateManager: StoreUpdateInterface) {
    Log.i(TAG, "Starting force update flow via StoreUpdateInterface")

    // Устанавливаем тёмный фон, так как force update показывается в тёмной теме
    activity.window.setBackgroundDrawable(
        android.graphics.drawable.ColorDrawable(DarkBackground.toArgb())
    )

    updateManager.startImmediateUpdate(activity, object : UpdateCallback {
        override fun onResult(e: Exception?) {
            if (e != null) {
                Log.e(TAG, "Failed to start force update", e)
                activity.finish()
            }
        }
        override fun onProgress(progress: Int) {}
    })
}

    suspend fun checkForceUpdate(): Boolean = withContext(Dispatchers.IO) {
        try {
            remoteConfig = fetchRemoteConfig()

            if (remoteConfig == null) {
                return@withContext false
            }

            val config = remoteConfig!!

            if (config.technicalWorkActive) {
                return@withContext true
            }

            if (config.forceUpdate && isCurrentVersionOutdated(config.minVersion)) {
                return@withContext true
            }

            false
        } catch (e: Exception) {
            Log.e(TAG, "Error during force update check", e)
            false
        }
    }

    private suspend fun fetchRemoteConfig(): RemoteConfig? = withContext(Dispatchers.IO) {
        try {
            val task = remoteConfigClient.getRemoteConfig()
            val result = task.await()

            if (result != null) {
                val technicalWorkActive = try {
                    result.getBoolean("technicalWork_active")
                } catch (e: Exception) {
                    false
                }

                val minVersion = try {
                    result.getString("minVersion")
                } catch (e: Exception) {
                    "1.0.0"
                }

                val forceUpdate = try {
                    result.getBoolean("forceUpdate")
                } catch (e: Exception) {
                    false
                }

                val messages = mutableMapOf<String, String>()
                try {
                    val ruMessage = result.getString("technicalWork_message_ru")
                    val enMessage = result.getString("technicalWork_message_en")
                    if (ruMessage.isNotEmpty()) messages["ru"] = ruMessage
                    if (enMessage.isNotEmpty()) messages["en"] = enMessage
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to parse technical work messages", e)
                }

                return@withContext RemoteConfig(
                    technicalWorkActive = technicalWorkActive,
                    minVersion = minVersion,
                    forceUpdate = forceUpdate,
                    technicalWorkMessage = messages
                )
            }

            null
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch remote config", e)
            null
        }
    }

    private suspend fun <T> CompletableFuture<T>.await(): T? = withContext(Dispatchers.IO) {
        try {
            this@await.get()
        } catch (e: Exception) {
            null
        }
    }

    private fun isCurrentVersionOutdated(minVersion: String): Boolean {
        return try {
            val currentVersion = getCurrentVersionName()
            compareVersions(currentVersion, minVersion) < 0
        } catch (e: Exception) {
            false
        }
    }

    private fun getCurrentVersionName(): String {
        return try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "0.0.0"
        } catch (e: Exception) {
            "0.0.0"
        }
    }

    private fun compareVersions(version1: String, version2: String): Int {
        return try {
            val cleanVersion1 = version1.split(" ").first()
            val cleanVersion2 = version2.split(" ").first()

            val parts1 = cleanVersion1.split(".").map { it.toInt() }
            val parts2 = cleanVersion2.split(".").map { it.toInt() }

            val maxLength = maxOf(parts1.size, parts2.size)

            for (i in 0 until maxLength) {
                val part1 = parts1.getOrElse(i) { 0 }
                val part2 = parts2.getOrElse(i) { 0 }

                if (part1 < part2) return -1
                if (part1 > part2) return 1
            }

            0
        } catch (e: Exception) {
            -1
        }
    }

    fun showTechnicalWorkDialog(activity: Activity) {
        activity.runOnUiThread {
            val title = if (Locale.getDefault().language == "ru") {
                "Технические работы"
            } else {
                "Maintenance"
            }

            val message = getTechnicalWorkMessage(Locale.getDefault().language)

            val composeView = ComposeView(activity).apply {
                setContent {
                    MeteoTheme {                                              // ← ИСПРАВЛЕНО: MeteoTheme вместо MaterialTheme
                        TechnicalWorkDialogContent(
                            title = title,
                            message = message,
                            onExitClick = {
                                dialogRef?.dismiss()
                                activity.finish()
                            }
                        )
                    }
                }
            }

            val dialog = AlertDialog.Builder(activity)
                .setView(composeView)
                .setCancelable(false)
                .create()

            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            dialogRef = dialog
            dialog.show()
        }
    }

    @Composable
    fun MaintenanceIcon(
        modifier: Modifier = Modifier,
        tint: ComposeColor = ComposeColor.White
    ) {
        Canvas(modifier = modifier.size(48.dp)) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val centerX = canvasWidth / 2
            val centerY = canvasHeight / 2
            val radius = (canvasWidth.coerceAtMost(canvasHeight) / 2) * 0.9f

            // Outer circle
            drawCircle(
                color = tint,
                radius = radius,
                center = Offset(centerX, centerY)
            )

            // Exclamation mark - vertical bar (top part)
            val barWidth = radius * 0.15f
            val barHeight = radius * 0.45f
            val barTop = centerY - radius * 0.65f

            drawRect(
                color = ComposeColor.White,                                   // ← ИСПРАВЛЕНО: просто белый на синем фоне
                topLeft = Offset(centerX - barWidth / 2, barTop),
                size = Size(barWidth, barHeight)
            )

            // Exclamation mark - dot (bottom part)
            val dotRadius = radius * 0.12f
            val dotTop = centerY + radius * 0.15f

            drawCircle(
                color = ComposeColor.White,                                   // ← ИСПРАВЛЕНО: просто белый на синем фоне
                radius = dotRadius,
                center = Offset(centerX, dotTop)
            )
        }
    }

    @Composable
    private fun TechnicalWorkDialogContent(
        title: String,
        message: String,
        onExitClick: () -> Unit
    ) {
        Surface(
            modifier = Modifier.width(300.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.background
        ) {
            Column {

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    MaintenanceIcon(
                        tint = ComposeColor.White
                    )

                    Text(
                        text = title,
                        color = ComposeColor.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = message,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 16.sp,
                        lineHeight = 22.sp,
                        textAlign = TextAlign.Center
                    )

                    Button(
                        onClick = onExitClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 24.dp)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = ComposeColor.White
                        )
                    ) {
                        Text(
                            text = if (Locale.getDefault().language == "ru") "Выйти" else "Exit",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }

    fun getTechnicalWorkMessage(language: String): String {
        return remoteConfig?.technicalWorkMessage?.get(language)
            ?: remoteConfig?.technicalWorkMessage?.get("en")
            ?: "We are currently performing maintenance."
    }

    fun isTechnicalWorkActive(): Boolean = remoteConfig?.technicalWorkActive ?: false

    fun isForceUpdateEnabled(): Boolean = remoteConfig?.forceUpdate ?: false
}
