



package ru.wfllive.meteo

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import androidx.lifecycle.lifecycleScope




import kotlinx.coroutines.launch

class SplashActivity : ComponentActivity() {

    private var keepSplashOnScreen by mutableStateOf(true)
    private var statusText by mutableStateOf("Загрузка...")

    @SuppressLint("RestrictedApi")
    override fun onCreate(savedInstanceState: Bundle?) {
        
        val splashScreen = installSplashScreen()

        super.onCreate(savedInstanceState)

        splashScreen.setKeepOnScreenCondition {
            keepSplashOnScreen
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            splashScreen.setOnExitAnimationListener { splashScreenViewProvider ->
                splashScreenViewProvider.view.animate()
                    .alpha(0f)
                    .setDuration(300)
                    .withEndAction {
                        splashScreenViewProvider.remove()
                    }
                    .start()
            }
        }

        setupEdgeToEdge()

        setContent {
            MaterialTheme {
                SplashScreenContent()
            }
        }
    }

    private fun setupEdgeToEdge() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    @Composable
    private fun SplashScreenContent() {
        val isDarkTheme = isSystemInDarkTheme()

        val backgroundColor = if (isDarkTheme) {
            Color(0xFF111827)
        } else {
            Color(0xFFFFFFFF)
        }

        LaunchedEffect(Unit) {
            performSplashSequence()
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(backgroundColor),
            contentAlignment = Alignment.Center
        ) {
            AnimatedVisibility(
                visible = true,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.splash_logo),
                        contentDescription = "Логотип",
                        modifier = Modifier.size(120.dp)
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    CircularProgressIndicator(
                        modifier = Modifier.size(36.dp),
                        color = Color(0xFF2196F3),
                        strokeWidth = 3.dp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF808080)
                    )
                }
            }
        }
    }

    private suspend fun performSplashSequence() {
        statusText = "Инициализация..."

        try {
            delay(500)
            statusText = "Проверка соединения..."

            val isConnected = withTimeoutOrNull(3000) {
                withContext(Dispatchers.IO) {
                    NetworkUtils.isNetworkAvailable(this@SplashActivity)
                }
            } ?: false

            if (isConnected) {
                statusText = "Загрузка данных..."
                delay(300)

                val stillConnected = withContext(Dispatchers.IO) {
                    NetworkUtils.isNetworkAvailable(this@SplashActivity)
                }

                if (stillConnected) {
                    navigateToMain()
                } else {
                    navigateToOffline("Соединение нестабильно")
                }
            } else {
                navigateToOffline("Нет подключения к интернету")
            }
        } catch (e: Exception) {
            navigateToOffline("Ошибка проверки соединения")
        }
    }

    private fun navigateToMain() {
        lifecycleScope.launch {
            keepSplashOnScreen = false
            delay(300)
            startActivity(Intent(this@SplashActivity, MainActivity::class.java))
            finish()
        }
    }

    private fun navigateToOffline(message: String) {
        lifecycleScope.launch {
            statusText = message
            keepSplashOnScreen = false
            delay(800)
            startActivity(Intent(this@SplashActivity, OfflineActivity::class.java))
            finish()
        }
    }
}