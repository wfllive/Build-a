package ru.wfllive.meteo

import android.app.Activity

interface UpdateCallback {
    fun onResult(e: Exception?)
    fun onProgress(progress: Int)
}

interface StoreUpdateInterface {
    fun checkForUpdates(callback: UpdateCallback)
    fun startFlexibleUpdate(callback: UpdateCallback)
    fun startImmediateUpdate(activity: Activity, callback: UpdateCallback)
    fun completeUpdate(callback: UpdateCallback)
    fun checkIsLatestVersion(callback: UpdateCallback)
    fun unregisterListener()
    fun isDownloading(): Boolean
    fun isDownloaded(): Boolean
    
    // НОВЫЙ МЕТОД: Для проверки зависших обновлений (требование Google)
    fun onResume()
}