
/*
package ru.wfllive.meteo

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.location.Criteria
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.ok.tracer.crash.report.TracerCrashReport
import java.net.HttpURLConnection
import java.net.URL

import androidx.compose.ui.graphics.toArgb
import ru.wfllive.meteo.ui.theme.DarkBackground
import ru.wfllive.meteo.ui.theme.LightBackground


import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth



class MainActivity : AppCompatActivity() {

    private lateinit var storeUpdateManager: StoreUpdateManager

    private val forceUpdateManager: ForceUpdateManager by lazy {
        (application as MyApp).forceUpdateManager
    }

    private lateinit var webView: WebView
    private lateinit var contentContainer: FrameLayout
    private var rootContainer: FrameLayout? = null

    private lateinit var locationManager: LocationManager
    private var locationListener: LocationListener? = null
    private var isLocationRequested = false

    private val apiKey = "3fea683678784107a07174534221506"

    private val localFileUrl = "file:///android_asset/dist/index.html"
    private val devServerUrl = BuildConfig.DEV_SERVER_URL

    private var devRetryJob: Job? = null
    private var isMainPageLoaded = false

    private var isAppInitialized by mutableStateOf(false)
    private var isCheckingAppStatus by mutableStateOf(true)
    private var isLoading by mutableStateOf(false)

    // Храним текущую тему для Compose без пересоздания Activity
    private var isDarkThemeActive by mutableStateOf(false)

    companion object {
        const val LOCATION_PERMISSION_REQUEST_CODE = 1001
        private const val TAG = "MainActivity"
        private const val LOCATION_UPDATE_MIN_TIME = 1000L
        private const val LOCATION_UPDATE_MIN_DISTANCE = 10f
        const val THEME_LIGHT = "light"
        const val THEME_DARK = "dark"
        const val THEME_SYSTEM = "auto"

        private const val DEV_SERVER_CHECK_TIMEOUT_MS = 1500
        private const val DEV_SERVER_RETRY_DELAY_MS = 1200L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        restoreSavedTheme()

        // Определяем начальное состояние темы
        isDarkThemeActive = isCurrentlyDark()

        storeUpdateManager = StoreUpdateManager(this)
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        setupLocationListener()

        setContent {
            MainScreen()
        }

        checkAppStatus()
    }

    /**
     * Вызывается при изменении конфигурации (uiMode, orientation и т.д.)
     * Activity НЕ пересоздаётся, WebView остаётся живым
     */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)

        val nowDark = (newConfig.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES

        isDarkThemeActive = nowDark
        updateStatusBarColors()
    }
    
    
    
   
    
    @Composable
private fun MainScreen() {
    val backgroundColor = if (isDarkThemeActive) {
        ComposeColor(0xFF111827)
    } else {
        ComposeColor(0xFFFFFFFF)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .windowInsetsPadding(WindowInsets.systemBars)
    ) {
        if (isAppInitialized) {
            BannerAdView(
                modifier = Modifier.fillMaxWidth(),
                adUnitId = "R-M-19371636-1"
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { createWebViewContainer() },
                    update = { }
                )

                if (isLoading) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = ComposeColor(0xFF2196F3))
                    }
                }
            }
        }

        if (isCheckingAppStatus) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = ComposeColor(0xFF2196F3))
            }
        }
    }
}
    
    
    
/*
    @Composable
    private fun MainScreen() {
        val backgroundColor = if (isDarkThemeActive) {
            ComposeColor(0xFF111827)
        } else {
            ComposeColor(0xFFFFFFFF)
        }
        
        

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(backgroundColor)
        ) {
            if (isAppInitialized) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .windowInsetsPadding(WindowInsets.systemBars)
                ) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = {
                            createWebViewContainer()
                        },
                        update = {
                            // ничего не делаем
                        }
                    )

                    if (isLoading) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                color = ComposeColor(0xFF2196F3)
                            )
                        }
                    }
                }
            }

            if (isCheckingAppStatus) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = ComposeColor(0xFF2196F3)
                    )
                }
            }
        }
    }*/

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebViewContainer(): FrameLayout {
        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
           // setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.screen_background))
           
           setBackgroundColor(
    if (isDarkThemeActive) {
        DarkBackground.toArgb()
    } else {
        LightBackground.toArgb()
    }
)
           
           
            clipToPadding = false
        }

        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            setPadding(0, 0, 0, 0)
        }

        contentContainer = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setPadding(0, 0, 0, 0)
            clipToPadding = false
        }

        root.addView(webView)
        root.addView(contentContainer)

        rootContainer = root

        setupWebView()

        return root
    }

    override fun onResume() {
        super.onResume()

        if (::storeUpdateManager.isInitialized) {
            storeUpdateManager.onResume()
        }

        try {
            if (::webView.isInitialized) {
                webView.onResume()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in WebView onResume", e)
        }
    }

    override fun onPause() {
        try {
            if (::webView.isInitialized) {
                webView.onPause()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in WebView onPause", e)
        }
        super.onPause()
    }

    private fun checkAppStatus() {
        lifecycleScope.launch {
            try {
                val needsBlocking = withContext(Dispatchers.IO) {
                    forceUpdateManager.checkForceUpdate()
                }

                if (needsBlocking) {
                    if (forceUpdateManager.isTechnicalWorkActive()) {
                        Log.d(TAG, "Technical work active, showing dialog")
                        forceUpdateManager.showTechnicalWorkDialog(this@MainActivity)
                        return@launch
                    } else if (forceUpdateManager.isForceUpdateEnabled()) {
                        Log.d(TAG, "Force update required, starting update flow")
                        forceUpdateManager.startForceUpdate(this@MainActivity, storeUpdateManager)
                        return@launch
                    }
                }

                continueAppInitialization()
            } catch (e: CancellationException) {
                Log.d(TAG, "Job cancelled")
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Error checking app status", e)
                continueAppInitialization()
                TracerCrashReport.report(e, "ошибка init")
            }
        }
    }

    private fun continueAppInitialization() {
        Log.d(TAG, "Continuing app initialization")
        isCheckingAppStatus = false
        isAppInitialized = true
        updateStatusBarColors()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val apiInterface = ApiInterface(apiKey)
        val webAppInterface = WebAppInterface(this, storeUpdateManager)

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true

            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = true

            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = true

            loadWithOverviewMode = true
            useWideViewPort = true
            setGeolocationEnabled(true)

            @Suppress("DEPRECATION")
            setGeolocationDatabasePath(filesDir.path)
        }

        if (BuildConfig.DEBUG) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        webView.addJavascriptInterface(apiInterface, "AndroidApi")
        webView.addJavascriptInterface(webAppInterface, "Android")
        webView.addJavascriptInterface(ThemeInterface(), "AndroidTheme")
        webView.setBackgroundColor(Color.TRANSPARENT)

        webView.webViewClient = object : WebViewClient() {
            private var pageLoadStartTime = 0L
            private val minSplashDisplayTime = 500L

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val uri = request.url

                if (isInternalUrl(uri)) {
                    return false
                }

                if (uri.scheme == "http" || uri.scheme == "https") {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    return true
                }

                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                pageLoadStartTime = System.currentTimeMillis()
                isLoading = true
                Log.d(TAG, "Page started: $url")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)

                val loadTime = System.currentTimeMillis() - pageLoadStartTime
                if (loadTime < minSplashDisplayTime) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        isLoading = false
                    }, minSplashDisplayTime - loadTime)
                } else {
                    isLoading = false
                }

                if (url != null && isAppEntryUrl(url)) {
                    isMainPageLoaded = true
                    devRetryJob?.cancel()
                    sendCurrentThemeToWebView()
                }

                Log.d(TAG, "Page finished: $url")
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)

                if (request?.isForMainFrame == true) {
                    Log.e(
                        TAG,
                        "Main frame error: code=${error?.errorCode}, desc=${error?.description}, url=${request.url}"
                    )

                    if (BuildConfig.USE_DEV_SERVER) {
                        showWaitingForDevServer()
                        startDevServerRetryLoop()
                    }
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(
                origin: String,
                callback: GeolocationPermissions.Callback
            ) {
                if (ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ) == PackageManager.PERMISSION_GRANTED
                ) {
                    callback.invoke(origin, true, false)
                } else {
                    ActivityCompat.requestPermissions(
                        this@MainActivity,
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                        LOCATION_PERMISSION_REQUEST_CODE
                    )
                }
            }

            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                if (BuildConfig.DEBUG) {
                    Log.d(
                        "WebViewConsole",
                        "${consoleMessage?.messageLevel()}: ${consoleMessage?.message()} " +
                                "(${consoleMessage?.sourceId()}:${consoleMessage?.lineNumber()})"
                    )
                }
                return true
            }
        }

        webAppInterface.setMainWebView(webView)
        webAppInterface.setContentContainer(contentContainer)

        if (BuildConfig.USE_DEV_SERVER) {
            loadDevServerOnly()
        } else {
            webView.loadUrl(localFileUrl)
        }
    }

    private fun isInternalUrl(uri: Uri): Boolean {
        if (uri.scheme == "file") return true

        if (BuildConfig.USE_DEV_SERVER) {
            val devUri = runCatching { Uri.parse(devServerUrl) }.getOrNull()
            if (devUri != null &&
                uri.scheme == devUri.scheme &&
                uri.host == devUri.host &&
                uri.port == devUri.port
            ) {
                return true
            }
        }

        return false
    }

    private fun isAppEntryUrl(url: String): Boolean {
        return if (BuildConfig.USE_DEV_SERVER) {
            url.startsWith(devServerUrl)
        } else {
            url.startsWith(localFileUrl)
        }
    }

    private fun loadDevServerOnly() {
        isMainPageLoaded = false
        showWaitingForDevServer()
        startDevServerRetryLoop()
    }

    private fun showWaitingForDevServer() {
        runOnUiThread {
            if (!::webView.isInitialized) return@runOnUiThread

            isLoading = true

            val waitingHtml = """
                <!doctype html>
                <html>
                <head>
                    <meta charset="utf-8" />
                    <meta name="viewport" content="width=device-width, initial-scale=1" />
                    <title>Waiting for dev server</title>
                    <style>
                        html, body {
                            margin: 0;
                            padding: 0;
                            width: 100%;
                            height: 100%;
                            background: #101114;
                            color: #ffffff;
                            font-family: sans-serif;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                        }
                        .wrap {
                            text-align: center;
                            padding: 24px;
                        }
                        .title {
                            font-size: 20px;
                            font-weight: 700;
                            margin-bottom: 12px;
                        }
                        .text {
                            opacity: 0.8;
                            line-height: 1.5;
                            margin-bottom: 12px;
                        }
                        .url {
                            color: #7dd3fc;
                            word-break: break-all;
                        }
                    </style>
                </head>
                <body>
                    <div class="wrap">
                        <div class="title">Ожидание dev server</div>
                        <div class="text">Приложение работает в debug режиме и ждёт запуск фронтенда.</div>
                        <div class="text">Нужно поднять сервер по адресу:</div>
                        <div class="url">$devServerUrl</div>
                    </div>
                </body>
                </html>
            """.trimIndent()

            webView.loadDataWithBaseURL(null, waitingHtml, "text/html", "utf-8", null)
        }
    }

    private fun startDevServerRetryLoop() {
        if (!BuildConfig.USE_DEV_SERVER) return
        if (devRetryJob?.isActive == true) return

        devRetryJob = lifecycleScope.launch {
            while (!isMainPageLoaded) {
                val available = isDevServerAvailable(devServerUrl)
                Log.d(TAG, "Dev server check: $devServerUrl -> $available")

                if (available) {
                    withContext(Dispatchers.Main) {
                        if (::webView.isInitialized) {
                            Log.d(TAG, "Dev server available, loading: $devServerUrl")
                            webView.loadUrl(devServerUrl)
                        }
                    }
                    break
                }

                delay(DEV_SERVER_RETRY_DELAY_MS)
            }
        }
    }

    private suspend fun isDevServerAvailable(url: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.connectTimeout = DEV_SERVER_CHECK_TIMEOUT_MS
            connection.readTimeout = DEV_SERVER_CHECK_TIMEOUT_MS
            connection.requestMethod = "GET"
            connection.instanceFollowRedirects = true
            connection.connect()

            val code = connection.responseCode
            connection.disconnect()

            code in 200..399
        } catch (e: Exception) {
            false
        }
    }

    private fun restoreSavedTheme() {
        val sharedPreferences = getSharedPreferences("app_settings", Context.MODE_PRIVATE)
        val savedTheme = sharedPreferences.getString("theme", THEME_SYSTEM) ?: THEME_SYSTEM
        applyTheme(savedTheme, false)
    }

    /**
     * Применяет тему БЕЗ пересоздания Activity.
     *
     * Вместо AppCompatDelegate (который триггерит recreate),
     * мы вручную применяем ночной режим через UiModeManager
     * и сами обновляем состояние.
     */
    private fun applyTheme(theme: String, save: Boolean = true) {
        if (save) {
            getSharedPreferences("app_settings", Context.MODE_PRIVATE)
                .edit()
                .putString("theme", theme)
                .apply()
        }

        // Меняем режим через AppCompatDelegate.
        // Чтобы Activity НЕ пересоздавалась — в манифесте у MainActivity
        // должно быть: android:configChanges="uiMode|..."
        when (theme) {
            THEME_LIGHT -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                isDarkThemeActive = false
            }
            THEME_DARK -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                isDarkThemeActive = true
            }
            THEME_SYSTEM -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
                isDarkThemeActive = isCurrentlyDark()
            }
        }

        updateStatusBarColors()
    }

    /**
     * Возвращает true, если сейчас активна тёмная тема
     * (на основе текущей конфигурации системы)
     */
    private fun isCurrentlyDark(): Boolean {
        val nightMode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return nightMode == Configuration.UI_MODE_NIGHT_YES
    }

 /*   private fun updateStatusBarColors() {
        runOnUiThread {
            val isDark = isDarkThemeActive

            if (isDark) {
                window.statusBarColor = ContextCompat.getColor(this, R.color.darkBackground)
            } else {
                window.statusBarColor = Color.WHITE
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                @Suppress("DEPRECATION")
                val flags = window.decorView.systemUiVisibility

                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = if (isDark) {
                    flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
                } else {
                    flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                }
            }
        }
    }*/
    
    
    

private fun updateStatusBarColors() {
    runOnUiThread {
        val isDark = isDarkThemeActive

        window.statusBarColor = if (isDark) {
            DarkBackground.toArgb()
        } else {
            LightBackground.toArgb()
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            @Suppress("DEPRECATION")
            val flags = window.decorView.systemUiVisibility

            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (isDark) {
                flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            } else {
                flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            }
        }
    }
}

    private fun sendCurrentThemeToWebView() {
        if (!::webView.isInitialized) return

        val currentTheme = getSharedPreferences("app_settings", Context.MODE_PRIVATE)
            .getString("theme", THEME_SYSTEM) ?: THEME_SYSTEM

        runOnUiThread {
            webView.evaluateJavascript(
                "if (window.receiveAndroidTheme) { window.receiveAndroidTheme('$currentTheme'); }",
                null
            )
        }
    }

    inner class ThemeInterface {
        @JavascriptInterface
        fun setTheme(theme: String) {
            runOnUiThread {
                applyTheme(theme)
                // Отправляем тему обратно в WebView
                if (::webView.isInitialized) {
                    webView.evaluateJavascript(
                        "if (window.receiveAndroidTheme) { window.receiveAndroidTheme('$theme'); }",
                        null
                    )
                }
            }
        }

        @JavascriptInterface
        fun getCurrentTheme(): String {
            return getSharedPreferences("app_settings", Context.MODE_PRIVATE)
                .getString("theme", THEME_SYSTEM) ?: THEME_SYSTEM
        }
    }

    inner class ApiInterface(private val apiKey: String) {
        @JavascriptInterface
        fun getApiKey(): String = apiKey
    }

    private fun setupLocationListener() {
        locationListener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                val locationData = """
                    {
                        "granted": true,
                        "latitude": ${location.latitude},
                        "longitude": ${location.longitude},
                        "accuracy": ${location.accuracy},
                        "timestamp": ${location.time},
                        "source": "android"
                    }
                """.trimIndent()

                runOnUiThread {
                    if (::webView.isInitialized) {
                        webView.evaluateJavascript(
                            "if (typeof window.onAndroidLocationData === 'function') { window.onAndroidLocationData($locationData); }",
                            null
                        )
                    }
                }

                if (isLocationRequested) stopLocationUpdates()
            }

            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
    }

    fun startLocationUpdates() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) return

        try {
            val provider = locationManager.getBestProvider(Criteria(), true)
            if (provider != null && locationListener != null) {
                locationManager.requestLocationUpdates(
                    provider,
                    LOCATION_UPDATE_MIN_TIME,
                    LOCATION_UPDATE_MIN_DISTANCE,
                    locationListener!!
                )
                isLocationRequested = true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error starting location updates", e)
        }
    }

    private fun stopLocationUpdates() {
        try {
            locationListener?.let { locationManager.removeUpdates(it) }
            isLocationRequested = false
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping location updates", e)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            val granted = grantResults.isNotEmpty() &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED

            runOnUiThread {
                if (::webView.isInitialized) {
                    webView.evaluateJavascript(
                        "if (typeof window.onAndroidLocationPermissionResult === 'function') { window.onAndroidLocationPermissionResult($granted); }",
                        null
                    )
                }
            }

            if (granted) startLocationUpdates()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 2400) {
            if (resultCode != RESULT_OK) {
                Log.w(TAG, "Update flow failed or canceled! Result code: $resultCode")
                finish()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        devRetryJob?.cancel()
        stopLocationUpdates()

        try {
            if (::webView.isInitialized) {
                (webView.parent as? ViewGroup)?.removeView(webView)
                webView.stopLoading()
                webView.loadUrl("about:blank")
                webView.onPause()
                webView.clearHistory()
                webView.removeAllViews()
                webView.destroy()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error destroying WebView", e)
        }

        rootContainer = null

        if (::storeUpdateManager.isInitialized) {
            storeUpdateManager.unregisterListener()
        }

        super.onDestroy()
    }
}*/


package ru.wfllive.meteo

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.location.Criteria
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import ru.wfllive.meteo.bridge.BridgeHost
import ru.wfllive.meteo.bridge.NativeBridgeManager
import ru.wfllive.meteo.ota.MeteoOsUpdateManager
import com.yandex.mobile.ads.kmp.common.AdRequest
import com.yandex.mobile.ads.kmp.compose.rememberRewardedAdLoader
import com.yandex.mobile.ads.kmp.rewarded.RewardedAd
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.ok.tracer.crash.report.TracerCrashReport
import ru.wfllive.meteo.ui.theme.DarkBackground
import ru.wfllive.meteo.ui.theme.LightBackground
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity(), BridgeHost {

    // ── JS ↔ Android мост ─────────────────────────────────────────────────────
    //
    // Вся связь с вебом (карта, insets, тема, геолокация, реклама, обновления)
    // живёт в пакете ru.wfllive.meteo.bridge. Здесь — только подключение.

    private val nativeBridge: NativeBridgeManager by lazy {
        NativeBridgeManager(this, apiKey)
    }

    override val hostActivity: AppCompatActivity get() = this

    override val updateManager: StoreUpdateInterface get() = storeUpdateManager

    override val meteoOsManager: MeteoOsUpdateManager get() = meteoOsUpdateManager

    /**
     * Применение / откат / сброс Meteo OS: перезагрузить главный WebView.
     * Вызывается мостом ТОЛЬКО на UI-потоке.
     */
    override fun reloadWebApp(url: String) {
        if (!::webView.isInitialized) return
        isMainPageLoaded = false
        webView.loadUrl(url)
    }

    // ── Managers ──────────────────────────────────────────────────────────────

    private lateinit var storeUpdateManager: StoreUpdateManager

    /** Meteo OS: OTA-обновления веб-бандла (React-интерфейса) без магазина. */
    private val meteoOsUpdateManager: MeteoOsUpdateManager by lazy {
        MeteoOsUpdateManager(applicationContext, localFileUrl)
    }

    private val forceUpdateManager: ForceUpdateManager by lazy {
        (application as MyApp).forceUpdateManager
    }

    // ── Views ─────────────────────────────────────────────────────────────────

    private lateinit var webView: WebView
    private lateinit var contentContainer: FrameLayout
    private var rootContainer: FrameLayout? = null

    // ── Location ──────────────────────────────────────────────────────────────

    private lateinit var locationManager: LocationManager
    private var locationListener: LocationListener? = null
    private var isLocationRequested = false

    // ── Config ────────────────────────────────────────────────────────────────

    private val apiKey = "3fea683678784107a07174534221506"
    private val localFileUrl = "file:///android_asset/dist/index.html"
    private val devServerUrl = BuildConfig.DEV_SERVER_URL

    // ── State ─────────────────────────────────────────────────────────────────

    private var devRetryJob: Job? = null
    private var isMainPageLoaded = false

    private var isAppInitialized by mutableStateOf(false)
    private var isCheckingAppStatus by mutableStateOf(true)
    private var isLoading by mutableStateOf(false)
    private var isDarkThemeActive by mutableStateOf(false)

    // ── Ad Banner State ───────────────────────────────────────────────────────

    private var isBannerVisible by mutableStateOf(true)
    private var adsDisabledUntilMs: Long = 0L
    private var rewardCooldownUntilMs: Long = 0L
    private var adControlJob: Job? = null

    // ── Rewarded Ad ───────────────────────────────────────────────────────────

    var rewardedAdManager: RewardedAdManager? = null
    private var isRewardedAdLoading by mutableStateOf(false)

    // ── Companion ─────────────────────────────────────────────────────────────

    companion object {
        const val LOCATION_PERMISSION_REQUEST_CODE = 1001
        private const val TAG = "MainActivity"
        private const val LOCATION_UPDATE_MIN_TIME = 1000L
        private const val LOCATION_UPDATE_MIN_DISTANCE = 10f

        const val THEME_LIGHT = "light"
        const val THEME_DARK = "dark"
        const val THEME_SYSTEM = "auto"

        private const val DEV_SERVER_CHECK_TIMEOUT_MS = 1500
        private const val DEV_SERVER_RETRY_DELAY_MS = 1200L

        // Реклама
        const val BANNER_AD_UNIT_ID = "R-M-19371636-1"
        const val REWARDED_AD_UNIT_ID = "R-M-19371636-2"

        // Ad Control
        private const val ADS_PREFS = "ad_control_prefs"
        private const val KEY_ADS_DISABLED_UNTIL = "ads_disabled_until"
        private const val KEY_REWARD_COOLDOWN_UNTIL = "reward_cooldown_until"
        private const val ADS_DISABLE_DURATION_MS = 5 * 60 * 1000L
        private const val REWARD_COOLDOWN_DURATION_MS = 24 * 60 * 60 * 1000L
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-edge: окно рисуется под системными барами, а безопасные отступы
        // уезжают в веб через мост (CSS-переменные --safe-area-*).
        // На Android 15+ (targetSdk 35+) это поведение включено принудительно,
        // поэтому лучше управлять им явно, чем бороться с ним.
        WindowCompat.setDecorFitsSystemWindows(window, false)

        restoreSavedTheme()
        isDarkThemeActive = isCurrentlyDark()

        storeUpdateManager = StoreUpdateManager(this)
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        setupLocationListener()

        restoreAdControlState()

        setContent {
            MainScreen()
        }

        checkAppStatus()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val nowDark = (newConfig.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        isDarkThemeActive = nowDark
        updateStatusBarColors()
        // Поворот / split-screen / смена темы → пересчитать insets и геометрию карты.
        nativeBridge.onConfigurationChanged()
    }

    override fun onResume() {
        super.onResume()
        if (::storeUpdateManager.isInitialized) {
            storeUpdateManager.onResume()
        }
        try {
            if (::webView.isInitialized) {
                webView.onResume()
                nativeBridge.onResume()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in WebView onResume", e)
        }
    }

    override fun onPause() {
        try {
            if (::webView.isInitialized) {
                webView.onPause()
                nativeBridge.onPause()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in WebView onPause", e)
        }
        super.onPause()
    }

    override fun onDestroy() {
        devRetryJob?.cancel()
        adControlJob?.cancel()
        rewardedAdManager?.destroy()
        stopLocationUpdates()

        try {
            nativeBridge.onDestroy()
        } catch (e: Exception) {
            Log.e(TAG, "Error destroying bridge", e)
        }

        try {
            if (::webView.isInitialized) {
                (webView.parent as? ViewGroup)?.removeView(webView)
                webView.stopLoading()
                webView.loadUrl("about:blank")
                webView.onPause()
                webView.clearHistory()
                webView.removeAllViews()
                webView.destroy()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error destroying WebView", e)
        }

        rootContainer = null

        if (::storeUpdateManager.isInitialized) {
            storeUpdateManager.unregisterListener()
        }

        super.onDestroy()
    }

    // ── Compose UI ────────────────────────────────────────────────────────────

    @Composable
    private fun MainScreen() {
        // Создаём loader здесь — он доступен только в Composable
        val rewardedLoader = rememberRewardedAdLoader()

        val backgroundColor = if (isDarkThemeActive) {
            ComposeColor(0xFF111827)
        } else {
            ComposeColor(0xFFFFFFFF)
        }

        // Инициализируем RewardedAdManager когда приложение готово
        LaunchedEffect(isAppInitialized) {
            if (isAppInitialized && rewardedAdManager == null) {
                initRewardedAd { request ->
                    rewardedLoader.loadAd(request)
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(backgroundColor)
                // Системные бары НЕПРОЗРАЧНЫЕ: background() рисуется на всю площадь,
                // а padding отодвигает контент — значит зоны статус-бара и навбара
                // залиты фоном темы, кнопки «назад/домой/недавние» на своём фоне.
                //
                // Мост при этом отдаёт вебу отступы, пересчитанные под контейнер
                // (см. SystemInsetsController.contentInsets), поэтому веб НЕ добавляет
                // их второй раз, а нативная карта ровно вписывается в контейнер и
                // никуда не залезает.
                .windowInsetsPadding(WindowInsets.systemBars)
        ) {
            if (isAppInitialized) {

                // Баннер — только если реклама включена
                if (isBannerVisible) {
                    BannerAdView(
                        modifier = Modifier.fillMaxWidth(),
                        adUnitId = BANNER_AD_UNIT_ID
                    )
                }

                // WebView
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { createWebViewContainer() },
                        update = { }
                    )

                    if (isLoading) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                color = ComposeColor(0xFF2196F3)
                            )
                        }
                    }
                }
            }

            if (isCheckingAppStatus) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = ComposeColor(0xFF2196F3)
                    )
                }
            }
        }
    }

    // ── App Status ────────────────────────────────────────────────────────────

    private fun checkAppStatus() {
        lifecycleScope.launch {
            try {
                val needsBlocking = withContext(Dispatchers.IO) {
                    forceUpdateManager.checkForceUpdate()
                }

                if (needsBlocking) {
                    if (forceUpdateManager.isTechnicalWorkActive()) {
                        Log.d(TAG, "Technical work active")
                        forceUpdateManager.showTechnicalWorkDialog(this@MainActivity)
                        return@launch
                    } else if (forceUpdateManager.isForceUpdateEnabled()) {
                        Log.d(TAG, "Force update required")
                        forceUpdateManager.startForceUpdate(
                            this@MainActivity,
                            storeUpdateManager
                        )
                        return@launch
                    }
                }

                continueAppInitialization()

            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Error checking app status", e)
                continueAppInitialization()
                TracerCrashReport.report(e, "ошибка init")
            }
        }
    }

    private fun continueAppInitialization() {
        Log.d(TAG, "Continuing app initialization")
        isCheckingAppStatus = false
        isAppInitialized = true
        updateStatusBarColors()
        // initRewardedAd вызывается в LaunchedEffect в MainScreen
    }

    // ── Ad Control ────────────────────────────────────────────────────────────

    private fun restoreAdControlState() {
        val prefs = getSharedPreferences(ADS_PREFS, Context.MODE_PRIVATE)
        adsDisabledUntilMs = prefs.getLong(KEY_ADS_DISABLED_UNTIL, 0L)
        rewardCooldownUntilMs = prefs.getLong(KEY_REWARD_COOLDOWN_UNTIL, 0L)
        syncAdControlState(notifyWeb = false)
    }

    private fun saveAdControlState() {
        getSharedPreferences(ADS_PREFS, Context.MODE_PRIVATE)
            .edit()
            .putLong(KEY_ADS_DISABLED_UNTIL, adsDisabledUntilMs)
            .putLong(KEY_REWARD_COOLDOWN_UNTIL, rewardCooldownUntilMs)
            .apply()
    }

    private fun syncAdControlState(notifyWeb: Boolean = true) {
        val now = System.currentTimeMillis()

        if (now >= adsDisabledUntilMs) adsDisabledUntilMs = 0L
        if (now >= rewardCooldownUntilMs) rewardCooldownUntilMs = 0L

        isBannerVisible = (adsDisabledUntilMs == 0L)
        saveAdControlState()

        adControlJob?.cancel()

        val nextWakeUp = listOf(adsDisabledUntilMs, rewardCooldownUntilMs)
            .filter { it > now }
            .minOrNull()

        if (nextWakeUp != null) {
            adControlJob = lifecycleScope.launch {
                delay(nextWakeUp - now + 100L)
                syncAdControlState(notifyWeb = true)
            }
        }

        if (notifyWeb) notifyAdStateToWeb()
    }

    override fun activateAdFreeFor5Minutes(): Boolean {
        val now = System.currentTimeMillis()

        if (now < rewardCooldownUntilMs) {
            Log.d(TAG, "AdFree: cooldown active")
            notifyAdStateToWeb()
            return false
        }

        adsDisabledUntilMs = now + ADS_DISABLE_DURATION_MS
        rewardCooldownUntilMs = now + REWARD_COOLDOWN_DURATION_MS

        Log.d(TAG, "AdFree: activated! 5 min no ads, 24h cooldown")
        syncAdControlState(notifyWeb = true)
        return true
    }

    override fun getAdControlStateJson(): String {
        val now = System.currentTimeMillis()
        val adsRemainingMs = maxOf(0L, adsDisabledUntilMs - now)
        val cooldownRemainingMs = maxOf(0L, rewardCooldownUntilMs - now)

        return """
            {
                "adsDisabled": ${adsRemainingMs > 0},
                "adsRemainingMs": $adsRemainingMs,
                "cooldownRemainingMs": $cooldownRemainingMs,
                "canActivate": ${cooldownRemainingMs == 0L}
            }
        """.trimIndent()
    }

    fun notifyAdStateToWeb() {
        if (!::webView.isInitialized) return
        nativeBridge.notifyAdState(getAdControlStateJson())
    }

    // ── Rewarded Ad ───────────────────────────────────────────────────────────

    private fun initRewardedAd(loadAdFn: suspend (AdRequest) -> RewardedAd) {
        rewardedAdManager = RewardedAdManager(
            adUnitId = REWARDED_AD_UNIT_ID,
            scope = lifecycleScope,
            loadAdFn = loadAdFn,

            onRewarded = {
                Log.d(TAG, "Rewarded: user got reward")
                runOnUiThread {
                    activateAdFreeFor5Minutes()
                }
            },

            onDismissed = {
                Log.d(TAG, "Rewarded: dismissed")
                runOnUiThread {
                    isRewardedAdLoading = false
                    notifyRewardedStateToWeb("dismissed")
                }
            },

            onError = { error ->
                Log.e(TAG, "Rewarded error: $error")
                runOnUiThread {
                    isRewardedAdLoading = false
                    notifyRewardedStateToWeb("error")
                }
            },

            onLoaded = {
                Log.d(TAG, "Rewarded: loaded and ready")
                runOnUiThread {
                    isRewardedAdLoading = false
                    notifyRewardedStateToWeb("ready")
                }
            }
        )

        rewardedAdManager?.load()
    }

    override fun showRewardedAd(): String {
        val now = System.currentTimeMillis()

        if (now < rewardCooldownUntilMs) {
            val remaining = rewardCooldownUntilMs - now
            Log.d(TAG, "Rewarded: cooldown active, remaining=${remaining}ms")
            return """{"success": false, "reason": "cooldown", "cooldownRemainingMs": $remaining}"""
        }

        val manager = rewardedAdManager
            ?: return """{"success": false, "reason": "not_initialized"}"""

        if (manager.isCurrentlyLoading()) {
            return """{"success": false, "reason": "loading"}"""
        }

        if (!manager.isReady()) {
            isRewardedAdLoading = true
            manager.load()
            return """{"success": false, "reason": "not_ready"}"""
        }

        isRewardedAdLoading = true
        manager.show()
        return """{"success": true}"""
    }

    fun notifyRewardedStateToWeb(status: String) {
        if (!::webView.isInitialized) return
        nativeBridge.notifyRewardedState(
            status = status,
            isReady = rewardedAdManager?.isReady() ?: false,
            stateJson = getAdControlStateJson()
        )
    }

    // ── WebView Container ─────────────────────────────────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebViewContainer(): FrameLayout {
        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(
                if (isDarkThemeActive) DarkBackground.toArgb() else LightBackground.toArgb()
            )
            clipToPadding = false
        }

        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            setPadding(0, 0, 0, 0)
        }

        contentContainer = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setPadding(0, 0, 0, 0)
            clipToPadding = false
        }

        root.addView(webView)
        root.addView(contentContainer)
        rootContainer = root

        setupWebView()

        return root
    }

    // ── WebView Setup ─────────────────────────────────────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true

            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = true

            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = true

            loadWithOverviewMode = true
            useWideViewPort = true
            setGeolocationEnabled(true)

            @Suppress("DEPRECATION")
            setGeolocationDatabasePath(filesDir.path)
        }

        if (BuildConfig.DEBUG) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        // Один вызов регистрирует ВЕСЬ мост:
        // window.AndroidBridge (v2), window.Android (legacy), window.AndroidTheme,
        // window.AndroidApi + edge-to-edge + слежение за insets + контроллер карты.
        nativeBridge.install(
            mainWebView = webView,
            mapContainer = contentContainer,
            verboseLogs = BuildConfig.DEBUG
        )

        webView.setBackgroundColor(Color.TRANSPARENT)

        webView.webViewClient = object : WebViewClient() {
            private var pageLoadStartTime = 0L
            private val minSplashDisplayTime = 500L

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val uri = request.url
                if (isInternalUrl(uri)) return false
                if (uri.scheme == "http" || uri.scheme == "https") {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    return true
                }
                return false
            }

            override fun onPageStarted(
                view: WebView?,
                url: String?,
                favicon: Bitmap?
            ) {
                super.onPageStarted(view, url, favicon)
                pageLoadStartTime = System.currentTimeMillis()
                isLoading = true
                Log.d(TAG, "Page started: $url")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)

                val loadTime = System.currentTimeMillis() - pageLoadStartTime
                if (loadTime < minSplashDisplayTime) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        isLoading = false
                    }, minSplashDisplayTime - loadTime)
                } else {
                    isLoading = false
                }

                if (url != null && isAppEntryUrl(url)) {
                    isMainPageLoaded = true
                    devRetryJob?.cancel()
                    // Отдаём вебу стартовое состояние: версия моста, insets, тема.
                    nativeBridge.onWebAppReady()
                    notifyAdStateToWeb()
                    notifyRewardedStateToWeb("ready")
                }

                Log.d(TAG, "Page finished: $url")
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    Log.e(
                        TAG,
                        "Main frame error: code=${error?.errorCode}, " +
                                "desc=${error?.description}, url=${request.url}"
                    )
                    if (BuildConfig.USE_DEV_SERVER) {
                        showWaitingForDevServer()
                        startDevServerRetryLoop()
                    }
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(
                origin: String,
                callback: GeolocationPermissions.Callback
            ) {
                if (ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ) == PackageManager.PERMISSION_GRANTED
                ) {
                    callback.invoke(origin, true, false)
                } else {
                    ActivityCompat.requestPermissions(
                        this@MainActivity,
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                        LOCATION_PERMISSION_REQUEST_CODE
                    )
                }
            }

            /**
             * В release WebView-отладка выключена, поэтому ошибки JS видны
             * только здесь. Ошибки логируем ВСЕГДА (Log.e переживает R8),
             * остальное — только в debug.
             */
            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                val text = "${consoleMessage?.message()} " +
                        "(${consoleMessage?.sourceId()}:${consoleMessage?.lineNumber()})"

                if (consoleMessage?.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                    Log.e("WebViewConsole", text)
                } else if (BuildConfig.DEBUG) {
                    Log.d("WebViewConsole", "${consoleMessage?.messageLevel()}: $text")
                }
                return true
            }
        }

        if (BuildConfig.USE_DEV_SERVER) {
            loadDevServerOnly()
        } else {
            // Meteo OS: если применена OTA-версия интерфейса — стартуем с неё.
            // resolveStartUrl() сам выполнит авто-откат, если прошлый запуск
            // новой версии не подтвердил работоспособность (белый экран).
            webView.loadUrl(meteoOsUpdateManager.resolveStartUrl())
        }
    }

    // ── Dev Server ────────────────────────────────────────────────────────────

    private fun isInternalUrl(uri: Uri): Boolean {
        if (uri.scheme == "file") return true
        if (BuildConfig.USE_DEV_SERVER) {
            val devUri = runCatching { Uri.parse(devServerUrl) }.getOrNull()
            if (devUri != null &&
                uri.scheme == devUri.scheme &&
                uri.host == devUri.host &&
                uri.port == devUri.port
            ) return true
        }
        return false
    }

    private fun isAppEntryUrl(url: String): Boolean {
        return if (BuildConfig.USE_DEV_SERVER) {
            url.startsWith(devServerUrl)
        } else {
            // Встроенный бандл ИЛИ распакованная OTA-версия Meteo OS.
            url.startsWith(localFileUrl) || meteoOsUpdateManager.isOtaUrl(url)
        }
    }

    private fun loadDevServerOnly() {
        isMainPageLoaded = false
        showWaitingForDevServer()
        startDevServerRetryLoop()
    }

    private fun showWaitingForDevServer() {
        runOnUiThread {
            if (!::webView.isInitialized) return@runOnUiThread
            isLoading = true
            val waitingHtml = """
                <!doctype html><html>
                <head>
                <meta charset="utf-8"/>
                <meta name="viewport" content="width=device-width, initial-scale=1"/>
                <style>
                html,body{margin:0;padding:0;width:100%;height:100%;
                background:#101114;color:#fff;font-family:sans-serif;
                display:flex;align-items:center;justify-content:center;}
                .wrap{text-align:center;padding:24px;}
                .title{font-size:20px;font-weight:700;margin-bottom:12px;}
                .text{opacity:.8;line-height:1.5;margin-bottom:12px;}
                .url{color:#7dd3fc;word-break:break-all;}
                </style></head>
                <body><div class="wrap">
                <div class="title">Ожидание dev server</div>
                <div class="text">Нужно поднять сервер по адресу:</div>
                <div class="url">$devServerUrl</div>
                </div></body></html>
            """.trimIndent()
            webView.loadDataWithBaseURL(null, waitingHtml, "text/html", "utf-8", null)
        }
    }

    private fun startDevServerRetryLoop() {
        if (!BuildConfig.USE_DEV_SERVER) return
        if (devRetryJob?.isActive == true) return

        devRetryJob = lifecycleScope.launch {
            while (!isMainPageLoaded) {
                val available = isDevServerAvailable(devServerUrl)
                Log.d(TAG, "Dev server check: $devServerUrl -> $available")
                if (available) {
                    withContext(Dispatchers.Main) {
                        if (::webView.isInitialized) {
                            Log.d(TAG, "Dev server available, loading")
                            webView.loadUrl(devServerUrl)
                        }
                    }
                    break
                }
                delay(DEV_SERVER_RETRY_DELAY_MS)
            }
        }
    }

    private suspend fun isDevServerAvailable(url: String): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.connectTimeout = DEV_SERVER_CHECK_TIMEOUT_MS
                connection.readTimeout = DEV_SERVER_CHECK_TIMEOUT_MS
                connection.requestMethod = "GET"
                connection.instanceFollowRedirects = true
                connection.connect()
                val code = connection.responseCode
                connection.disconnect()
                code in 200..399
            } catch (e: Exception) {
                false
            }
        }

    // ── Theme ─────────────────────────────────────────────────────────────────

    private fun restoreSavedTheme() {
        val sharedPreferences = getSharedPreferences("app_settings", Context.MODE_PRIVATE)
        val savedTheme = sharedPreferences.getString("theme", THEME_SYSTEM) ?: THEME_SYSTEM
        applyTheme(savedTheme, false)
    }

    private fun applyTheme(theme: String, save: Boolean = true) {
        if (save) {
            getSharedPreferences("app_settings", Context.MODE_PRIVATE)
                .edit()
                .putString("theme", theme)
                .apply()
        }

        when (theme) {
            THEME_LIGHT -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                isDarkThemeActive = false
            }
            THEME_DARK -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                isDarkThemeActive = true
            }
            THEME_SYSTEM -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
                isDarkThemeActive = isCurrentlyDark()
            }
        }

        updateStatusBarColors()
    }

    private fun isCurrentlyDark(): Boolean {
        val nightMode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return nightMode == Configuration.UI_MODE_NIGHT_YES
    }

    /**
     * Бары непрозрачные и в цвет темы.
     *
     * До Android 15 цвет задаётся напрямую (statusBarColor / navigationBarColor).
     * Начиная с Android 15 эти свойства — no-op, поэтому фон под барами рисует
     * сам Compose: у Column есть background() на всю площадь + windowInsetsPadding.
     * Визуально результат одинаковый на всех версиях.
     */
    @Suppress("DEPRECATION")
    private fun updateStatusBarColors() {
        runOnUiThread {
            val isDark = isDarkThemeActive
            val barColor = if (isDark) DarkBackground.toArgb() else LightBackground.toArgb()

            if (Build.VERSION.SDK_INT < 35) {
                window.statusBarColor = barColor
                window.navigationBarColor = barColor
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    window.isNavigationBarContrastEnforced = false
                }
            }

            // Контраст иконок: тёмная тема → светлые иконки, и наоборот.
            WindowCompat.getInsetsController(window, window.decorView).apply {
                isAppearanceLightStatusBars = !isDark
                isAppearanceLightNavigationBars = !isDark
            }
        }
    }

    // ── BridgeHost: тема / геолокация / реклама ───────────────────────────────
    //
    // Реализация контракта ru.wfllive.meteo.bridge.BridgeHost.
    // Сами @JavascriptInterface-методы живут в пакете bridge, здесь только логика.

    override fun applyThemePreference(theme: String) {
        applyTheme(theme)
    }

    override fun currentThemePreference(): String =
        getSharedPreferences("app_settings", Context.MODE_PRIVATE)
            .getString("theme", THEME_SYSTEM) ?: THEME_SYSTEM

    override fun isDarkThemeNow(): Boolean = isDarkThemeActive

    override fun isRewardedAdReady(): Boolean = rewardedAdManager?.isReady() ?: false

    /**
     * Запрос геолокации из веба (window.AndroidBridge.requestLocationPermission()).
     * Раньше этого метода в мосте не было вовсе — веб звал его впустую.
     */
    override fun requestLocationPermissionFromWeb() {
        val granted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (granted) {
            nativeBridge.onLocationPermissionResult(true)
            startLocationUpdates()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        }
    }

    // ── Location ──────────────────────────────────────────────────────────────

    private fun setupLocationListener() {
        locationListener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                nativeBridge.onLocationChanged(location)
                if (isLocationRequested) stopLocationUpdates()
            }

            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
    }

    fun startLocationUpdates() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) return

        try {
            val provider = locationManager.getBestProvider(Criteria(), true)
            if (provider != null && locationListener != null) {
                locationManager.requestLocationUpdates(
                    provider,
                    LOCATION_UPDATE_MIN_TIME,
                    LOCATION_UPDATE_MIN_DISTANCE,
                    locationListener!!
                )
                isLocationRequested = true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error starting location updates", e)
        }
    }

    private fun stopLocationUpdates() {
        try {
            locationListener?.let { locationManager.removeUpdates(it) }
            isLocationRequested = false
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping location updates", e)
        }
    }

    // ── Permission Results ────────────────────────────────────────────────────

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            val granted = grantResults.isNotEmpty() &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED

            // Мост сам разошлёт событие и в новое API, и в legacy-колбэк,
            // а заодно ответит нативной карте на её geolocation-запрос.
            nativeBridge.onLocationPermissionResult(granted)

            if (granted) startLocationUpdates()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2400) {
            if (resultCode != RESULT_OK) {
                Log.w(TAG, "Update flow failed or canceled! Result code: $resultCode")
                finish()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }
}


