package ru.wfllive.meteo.bridge

import androidx.appcompat.app.AppCompatActivity
import ru.wfllive.meteo.StoreUpdateInterface
import ru.wfllive.meteo.ota.MeteoOsUpdateManager

/**
 * Контракт «хоста» для JS-моста.
 *
 * Мост (см. [NativeBridge]) НИЧЕГО не знает про MainActivity напрямую —
 * он работает только через этот интерфейс. Благодаря этому:
 *   • мост можно тестировать/переиспользовать отдельно;
 *   • видно ровно тот минимум, который native отдаёт вебу;
 *   • MainActivity не превращается в свалку @JavascriptInterface-методов.
 *
 * MainActivity реализует этот интерфейс.
 */
interface BridgeHost {

    /** Activity, в которой живёт мост (нужна для runOnUiThread / permissions). */
    val hostActivity: AppCompatActivity

    /** Менеджер обновлений магазина (RuStore / Google Play / universal). */
    val updateManager: StoreUpdateInterface

    /** Meteo OS: OTA-обновления веб-бандла (не путать с обновлениями APK). */
    val meteoOsManager: MeteoOsUpdateManager

    /** Перезагрузить главный WebView по указанному URL (применение/откат Meteo OS). */
    fun reloadWebApp(url: String)

    // ── Тема ──────────────────────────────────────────────────────────────────

    /** Применить тему: "light" | "dark" | "auto". */
    fun applyThemePreference(theme: String)

    /** Текущее сохранённое предпочтение темы: "light" | "dark" | "auto". */
    fun currentThemePreference(): String

    /** Активна ли сейчас тёмная тема (по факту, а не по предпочтению). */
    fun isDarkThemeNow(): Boolean

    // ── Геолокация ────────────────────────────────────────────────────────────

    /** Запросить у пользователя разрешение на геолокацию (или сразу отдать статус). */
    fun requestLocationPermissionFromWeb()

    // ── Реклама ───────────────────────────────────────────────────────────────

    fun getAdControlStateJson(): String
    fun showRewardedAd(): String
    fun activateAdFreeFor5Minutes(): Boolean
    fun isRewardedAdReady(): Boolean
}
