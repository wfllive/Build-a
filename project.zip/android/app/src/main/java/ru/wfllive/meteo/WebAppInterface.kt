package ru.wfllive.meteo

/*
 * ─────────────────────────────────────────────────────────────────────────────
 *  WebAppInterface БОЛЬШЕ НЕ ИСПОЛЬЗУЕТСЯ.
 *
 *  Старый класс совмещал в себе всё сразу: @JavascriptInterface-методы,
 *  создание и позиционирование WebView карты, расчёт размеров по
 *  DisplayMetrics + «магическим» процентам, обработку ошибок и рекламу.
 *  Именно из-за этой смеси карта разъезжалась по разным устройствам.
 *
 *  Теперь всё разложено по слоям в пакете ru.wfllive.meteo.bridge:
 *
 *    BridgeHost.kt             — что native обязан дать вебу (контракт)
 *    BridgeChannel.kt          — канал native → JS (события, JSON-safe)
 *    SystemInsetsController.kt — edge-to-edge и системные отступы
 *    MapViewportGeometry.kt    — чистая математика раскладки карты
 *    MapWebViewController.kt   — сам WebView карты и его жизненный цикл
 *    NativeBridge.kt           — window.AndroidBridge / window.Android (JS → native)
 *    ThemeBridge.kt            — window.AndroidTheme + window.AndroidApi
 *    NativeBridgeManager.kt    — сборка всего вместе (её и зовёт MainActivity)
 *
 *  JS-зеркало: src/native/**   Документация: docs/native-bridge.md
 *
 *  Файл оставлен пустым намеренно — история старой реализации есть в git.
 * ─────────────────────────────────────────────────────────────────────────────
 */
