
/*
package ru.wfllive.meteo

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.http.SslError
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.View
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import android.Manifest
import android.os.Build
import androidx.annotation.RequiresApi
import kotlin.math.min
import kotlin.math.max
import androidx.core.app.ActivityCompat

class WebAppInterface(
    private val context: Context,
    private val updateManager: StoreUpdateInterface
) {
    private var contentWebView: WebView? = null
    private lateinit var contentContainer: FrameLayout
    private lateinit var mainWebView: WebView
    private var geolocationCallback: GeolocationPermissions.Callback? = null
    private var geolocationOrigin: String? = null
    private var currentUrl: String? = null
    private var isWebViewVisible: Boolean = true

    companion object {
        private const val TAG = "WebAppInterface"
    }

    fun setContentContainer(container: FrameLayout) {
        this.contentContainer = container
    }

    fun setMainWebView(webView: WebView) {
        this.mainWebView = webView
    }

    fun setGeolocationCallback(origin: String, callback: GeolocationPermissions.Callback) {
        this.geolocationOrigin = origin
        this.geolocationCallback = callback
    }

    // ── Уведомления для React ───────────────────────────────────────────────

    private fun notifyLoading() {
        (context as MainActivity).runOnUiThread {
            mainWebView.evaluateJavascript(
                "window.onWebViewLoading && window.onWebViewLoading()",
                null
            )
            Log.d(TAG, "Notified React: onWebViewLoading")
        }
    }

    private fun notifyLoaded() {
        (context as MainActivity).runOnUiThread {
            mainWebView.evaluateJavascript(
                "window.onWebViewLoaded && window.onWebViewLoaded()",
                null
            )
            Log.d(TAG, "Notified React: onWebViewLoaded")
        }
    }

    private fun notifyError(errorCode: String) {
        (context as MainActivity).runOnUiThread {
            val safeCode = errorCode.replace("'", "\\'").replace("\n", " ")
            mainWebView.evaluateJavascript(
                "window.onWebViewError && window.onWebViewError('$safeCode')",
                null
            )
            Log.d(TAG, "Notified React: onWebViewError($safeCode)")
        }
    }

    private fun notifyOffline() {
        (context as MainActivity).runOnUiThread {
            mainWebView.evaluateJavascript(
                "window.onWebViewOffline && window.onWebViewOffline()",
                null
            )
            Log.d(TAG, "Notified React: onWebViewOffline")
        }
    }

    // ── Жизненный цикл ────────────────────────────────────────────────────────

    fun cleanup() {
        contentWebView?.let { webView ->
            safeDestroyWebView(webView)
            contentContainer.removeView(webView)
            contentWebView = null
        }
        currentUrl = null
        geolocationCallback = null
        geolocationOrigin = null
    }

    private fun safeDestroyWebView(webView: WebView) {
        try {
            (webView.parent as? android.view.ViewGroup)?.removeView(webView)
            webView.stopLoading()
            webView.onPause()
            webView.clearHistory()
            webView.loadUrl("about:blank")
            webView.removeAllViews()
            webView.destroy()
        } catch (e: Exception) {
            Log.e(TAG, "Error safely destroying WebView", e)
        }
    }

    @JavascriptInterface
    fun softCleanup() {
        (context as MainActivity).runOnUiThread {
            contentWebView?.let {
                it.stopLoading()
                it.visibility = View.GONE
            }
        }
    }

    // ── System Information ─────────────────────────────────────────────────────

    @JavascriptInterface
    fun isDarkMode(): Boolean = ThemeUtils.isSystemDarkMode(context)

    @JavascriptInterface
    fun getAppVersion(): String? {
        return try {
            val pInfo: PackageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            pInfo.versionName
        } catch (e: PackageManager.NameNotFoundException) {
            Log.e(TAG, "Package name not found", e)
            "7.0.0"
        }
    }

    @JavascriptInterface
    fun getDeviceInfo(): String {
        return """
        {
            "manufacturer": "${Build.MANUFACTURER}",
            "model": "${Build.MODEL}",
            "androidVersion": "${Build.VERSION.RELEASE}",
            "sdkVersion": ${Build.VERSION.SDK_INT}
        }
        """.trimIndent()
    }

    // ── WebView Management ─────────────────────────────────────────────────────

    @JavascriptInterface
    fun updateWebView(
        url: String,
        left: Int,
        top: Int,
        width: Int,
        height: Int,
        marginTopPercent: Float,
        marginBottomPercent: Float,
        isTablet: Boolean
    ) {
        (context as MainActivity).runOnUiThread {
            try {
                if (contentWebView == null) {
                    currentUrl = url
                    createAndSetupWebView(url, left, top, width, height, marginTopPercent, marginBottomPercent, isTablet)
                } else if (currentUrl != url) {
                    currentUrl = url
                    Log.d(TAG, "Loading new URL in existing WebView: $url")
                    notifyLoading()
                    contentWebView?.visibility = if (isWebViewVisible) View.VISIBLE else View.GONE
                    contentWebView?.loadUrl(url)
                }
                updateWebViewPosition(left, top, width, height, marginTopPercent, marginBottomPercent, isTablet)
            } catch (e: Exception) {
                Log.e(TAG, "Error updating WebView", e)
                notifyError("setup_error")
            }
        }
    }

    @JavascriptInterface
    fun updateUrl(newUrl: String) {
        (context as MainActivity).runOnUiThread {
            if (currentUrl != newUrl && contentWebView != null) {
                currentUrl = newUrl
                Log.d(TAG, "Updating URL only: $newUrl")
                notifyLoading()
                contentWebView?.visibility = if (isWebViewVisible) View.VISIBLE else View.GONE
                contentWebView?.loadUrl(newUrl)
            }
        }
    }

    private fun createAndSetupWebView(
        url: String,
        left: Int,
        top: Int,
        width: Int,
        height: Int,
        marginTopPercent: Float,
        marginBottomPercent: Float,
        isTablet: Boolean
    ) {
        val (calculatedWidth, calculatedHeight, calculatedLeft, calculatedTop) =
            calculateWebViewDimensions(left, top, width, height, marginTopPercent, marginBottomPercent, isTablet)

        val webView = WebView(context).apply {
            layoutParams = FrameLayout.LayoutParams(calculatedWidth, calculatedHeight).apply {
                this.leftMargin = calculatedLeft
                this.topMargin = calculatedTop
            }

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                builtInZoomControls = true
                displayZoomControls = false
                loadWithOverviewMode = true
                useWideViewPort = true
                setGeolocationEnabled(true)
                setGeolocationDatabasePath(context.filesDir.path)
                allowFileAccessFromFileURLs = false
                allowUniversalAccessFromFileURLs = false

                if (isTablet) {
                    minimumFontSize = 12
                    defaultFontSize = 16
                } else {
                    minimumFontSize = 10
                    defaultFontSize = 14
                }
            }

            setBackgroundColor(Color.WHITE)

            webViewClient = object : WebViewClient() {

                @RequiresApi(Build.VERSION_CODES.M)
                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest,
                    error: WebResourceError
                ) {
                    if (request.isForMainFrame) {
                        val errorCode = error.description?.toString() ?: "unknown_error"
                        Log.e(TAG, "Main frame error: $errorCode, url: ${request.url}")

                        view?.stopLoading()
                        view?.visibility = View.GONE
                        view?.loadUrl("about:blank")

                        view?.postDelayed({
                            notifyError(errorCode)
                        }, 100)
                    }
                }

                @Suppress("DEPRECATION")
                override fun onReceivedError(
                    view: WebView?,
                    errorCode: Int,
                    description: String?,
                    failingUrl: String?
                ) {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                        Log.e(TAG, "Legacy error: $errorCode, $description, $failingUrl")
                        view?.stopLoading()
                        view?.visibility = View.GONE
                        view?.loadUrl("about:blank")

                        view?.postDelayed({
                            notifyError(description ?: "error_$errorCode")
                        }, 100)
                    }
                }

                @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
                override fun onReceivedHttpError(
                    view: WebView?,
                    request: WebResourceRequest,
                    errorResponse: WebResourceResponse
                ) {
                    if (request.isForMainFrame) {
                        val statusCode = errorResponse.statusCode
                        if (statusCode >= 400) {
                            Log.e(TAG, "HTTP error: $statusCode, url: ${request.url}")
                            view?.stopLoading()
                            view?.visibility = View.GONE
                            view?.loadUrl("about:blank")

                            view?.postDelayed({
                                notifyError("HTTP $statusCode")
                            }, 100)
                        }
                    }
                }

                override fun onReceivedSslError(
                    view: WebView?,
                    handler: SslErrorHandler,
                    error: SslError
                ) {
                    Log.w(TAG, "SSL error: ${error.url}, code: ${error.primaryError}")
                    handler.cancel()
                    view?.visibility = View.GONE
                    view?.loadUrl("about:blank")

                    view?.postDelayed({
                        notifyError("SSL_ERROR")
                    }, 100)
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    if (url != null && url != "about:blank") {
                        Log.d(TAG, "Page started: $url")
                        notifyLoading()
                    }
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (url != null && url != "about:blank") {
                        Log.d(TAG, "Page finished: $url")
                        view?.visibility = if (isWebViewVisible) View.VISIBLE else View.GONE
                        notifyLoaded()
                    }
                }

                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    return false
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onGeolocationPermissionsShowPrompt(
                    origin: String?,
                    callback: GeolocationPermissions.Callback?
                ) {
                    Log.d(TAG, "Geolocation requested: $origin")
                    geolocationCallback = callback
                    geolocationOrigin = origin

                    if (ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.ACCESS_FINE_LOCATION
                        ) == PackageManager.PERMISSION_GRANTED
                    ) {
                        callback?.invoke(origin, true, false)
                    } else {
                        (context as MainActivity).requestPermissions(
                            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                            MainActivity.LOCATION_PERMISSION_REQUEST_CODE
                        )
                    }
                }
            }
        }

        contentWebView = webView
        contentContainer.addView(webView)

        Log.d(TAG, "Loading URL: $url")
        notifyLoading()
        webView.loadUrl(url)
    }

    private fun calculateWebViewDimensions(
        left: Int, top: Int, width: Int, height: Int,
        marginTopPercent: Float, marginBottomPercent: Float, isTablet: Boolean
    ): WebViewDimensions {
        val displayMetrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (context as MainActivity).windowManager.defaultDisplay.getMetrics(displayMetrics)
        val screenWidth = displayMetrics.widthPixels
        val screenHeight = displayMetrics.heightPixels
        val density = displayMetrics.density
        val isLandscape = screenWidth > screenHeight

        val widthPx = (width * density).toInt()
        val heightPx = (height * density).toInt()

        val finalWidth = if (isLandscape) screenWidth else minOf(widthPx, screenWidth)

        val marginTopPx = (screenHeight * marginTopPercent).toInt()
        val marginBottomPx = (screenHeight * marginBottomPercent).toInt()
        val availableHeight = screenHeight - marginTopPx - marginBottomPx
        val finalHeight = minOf(heightPx, availableHeight)

        val finalLeft = if (isLandscape) 0 else max(0, (screenWidth - finalWidth) / 2)
        val finalTop = if (isLandscape) marginTopPx else top

        Log.d(TAG, "Dimensions - Landscape: $isLandscape, Screen: ${screenWidth}x$screenHeight, Final: ${finalWidth}x${finalHeight} at ($finalLeft, $finalTop)")

        return WebViewDimensions(finalWidth, finalHeight, finalLeft, finalTop)
    }

    private fun updateWebViewPosition(
        left: Int, top: Int, width: Int, height: Int,
        marginTopPercent: Float, marginBottomPercent: Float, isTablet: Boolean
    ) {
        contentWebView?.let { webView ->
            val (calculatedWidth, calculatedHeight, calculatedLeft, calculatedTop) =
                calculateWebViewDimensions(left, top, width, height, marginTopPercent, marginBottomPercent, isTablet)

            webView.layoutParams = FrameLayout.LayoutParams(calculatedWidth, calculatedHeight).apply {
                this.leftMargin = calculatedLeft
                this.topMargin = calculatedTop
            }
        }
    }

    // ── Retry ─────────────────────────────────────────────────────────────────

    @JavascriptInterface
    fun retryLoading() {
        (context as MainActivity).runOnUiThread {
            Log.d(TAG, "Retry loading: $currentUrl")
            currentUrl?.let { url ->
                notifyLoading()
                contentWebView?.visibility = if (isWebViewVisible) View.VISIBLE else View.GONE
                contentWebView?.loadUrl(url)
            }
        }
    }

    // ── Permissions ───────────────────────────────────────────────────────────

    fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == MainActivity.LOCATION_PERMISSION_REQUEST_CODE) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            geolocationCallback?.invoke(geolocationOrigin, granted, false)
            Log.d(TAG, "Geolocation permission ${if (granted) "granted" else "denied"}: $geolocationOrigin")
            geolocationCallback = null
            geolocationOrigin = null
        }
    }

    // ── Visibility ────────────────────────────────────────────────────────────

    @JavascriptInterface
    fun hideWebView() {
        (context as MainActivity).runOnUiThread {
            isWebViewVisible = false
            contentWebView?.visibility = View.GONE
        }
    }

    @JavascriptInterface
    fun showWebView() {
        (context as MainActivity).runOnUiThread {
            isWebViewVisible = true
            contentWebView?.visibility = View.VISIBLE
        }
    }

    @JavascriptInterface
    fun onTabChanged(tabId: String) {
        (context as MainActivity).runOnUiThread {
            if (tabId != "map") {
                hideWebView()
                softCleanup()
            } else {
                showWebView()
            }
        }
    }

    @JavascriptInterface
    fun getLocationStatus(): String {
        return try {
            val permission = Manifest.permission.ACCESS_FINE_LOCATION
            when {
                ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED -> "granted"
                ActivityCompat.shouldShowRequestPermissionRationale(context as MainActivity, permission) -> "should_show_rationale"
                else -> "denied"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting location status", e)
            "unknown"
        }
    }

    // ── Update Management ─────────────────────────────────────────────────────

    @JavascriptInterface
    fun checkForUpdates() {
        updateManager.checkForUpdates(object : UpdateCallback {
            override fun onResult(e: Exception?) {
                val message = e?.message ?: ""
                when {
                    e == null -> postEvent("updateAvailable", "{ alreadyDownloaded: true }")
                    message == "Обновление доступно" -> postEvent("updateAvailable")
                    message == "Update Available" -> postEvent("updateAvailable")
                    message == "Уже скачивается" -> postUpdateError("Обновление уже скачивается")
                    else -> postUpdateError(message.ifEmpty { "Неизвестная ошибка" })
                }
            }
            override fun onProgress(progress: Int) {}
        })
    }

    @JavascriptInterface
    fun startFlexibleUpdate() {
        updateManager.startFlexibleUpdate(object : UpdateCallback {
            override fun onResult(e: Exception?) {
                if (e == null) {
                    if (updateManager.isDownloaded()) postEvent("updateDownloaded")
                    else postEvent("updateStarted")
                } else {
                    postUpdateError(e.message ?: "Неизвестная ошибка")
                }
            }
            override fun onProgress(progress: Int) {
                postEvent("updateProgress", progress.toString())
            }
        })
    }

    @JavascriptInterface
    fun installUpdate() {
        updateManager.completeUpdate(object : UpdateCallback {
            override fun onResult(e: Exception?) {
                e?.let { postUpdateError(it.message ?: "Ошибка при установке") }
            }
            override fun onProgress(progress: Int) {}
        })
    }

    @JavascriptInterface
    fun checkIsLatestVersion() {
        updateManager.checkIsLatestVersion(object : UpdateCallback {
            override fun onResult(e: Exception?) {
                if (e == null) postEvent("isLatestVersion")
                else postEvent("updateAvailable")
            }
            override fun onProgress(progress: Int) {}
        })
    }

    private fun postEvent(eventName: String, detail: String = "") {
        (context as MainActivity).runOnUiThread {
            mainWebView.evaluateJavascript(
                "window.dispatchEvent(new CustomEvent('$eventName'" +
                        (if (detail.isNotEmpty()) ", { detail: $detail }" else "") + "));",
                null
            )
        }
    }

    private fun postUpdateError(message: String) {
        postEvent("updateError", "'$message'")
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    fun onPause() { contentWebView?.onPause() }
    fun onResume() { contentWebView?.onResume() }

    private data class WebViewDimensions(
        val width: Int, val height: Int, val left: Int, val top: Int
    )
}*/

package ru.wfllive.meteo

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.http.SslError
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.Manifest
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.math.min
import kotlin.math.max

class WebAppInterface(
    private val context: Context,
    private val updateManager: StoreUpdateInterface
) {
    private var contentWebView: WebView? = null
    private lateinit var contentContainer: FrameLayout
    private lateinit var mainWebView: WebView
    private var geolocationCallback: GeolocationPermissions.Callback? = null
    private var geolocationOrigin: String? = null
    private var currentUrl: String? = null
    private var isWebViewVisible: Boolean = true

    companion object {
        private const val TAG = "WebAppInterface"
    }

    fun setContentContainer(container: FrameLayout) {
        this.contentContainer = container
    }

    fun setMainWebView(webView: WebView) {
        this.mainWebView = webView
    }

    fun setGeolocationCallback(origin: String, callback: GeolocationPermissions.Callback) {
        this.geolocationOrigin = origin
        this.geolocationCallback = callback
    }

    // ── Уведомления для React ───────────────────────────────────────────────

    private fun notifyLoading() {
        (context as MainActivity).runOnUiThread {
            mainWebView.evaluateJavascript(
                "window.onWebViewLoading && window.onWebViewLoading()",
                null
            )
            Log.d(TAG, "Notified React: onWebViewLoading")
        }
    }

    private fun notifyLoaded() {
        (context as MainActivity).runOnUiThread {
            mainWebView.evaluateJavascript(
                "window.onWebViewLoaded && window.onWebViewLoaded()",
                null
            )
            Log.d(TAG, "Notified React: onWebViewLoaded")
        }
    }

    private fun notifyError(errorCode: String) {
        (context as MainActivity).runOnUiThread {
            val safeCode = errorCode.replace("'", "\\'").replace("\n", " ")
            mainWebView.evaluateJavascript(
                "window.onWebViewError && window.onWebViewError('$safeCode')",
                null
            )
            Log.d(TAG, "Notified React: onWebViewError($safeCode)")
        }
    }

    private fun notifyOffline() {
        (context as MainActivity).runOnUiThread {
            mainWebView.evaluateJavascript(
                "window.onWebViewOffline && window.onWebViewOffline()",
                null
            )
            Log.d(TAG, "Notified React: onWebViewOffline")
        }
    }

    // ── Жизненный цикл ────────────────────────────────────────────────────────

    fun cleanup() {
        contentWebView?.let { webView ->
            safeDestroyWebView(webView)
            contentContainer.removeView(webView)
            contentWebView = null
        }
        currentUrl = null
        geolocationCallback = null
        geolocationOrigin = null
    }

    private fun safeDestroyWebView(webView: WebView) {
        try {
            (webView.parent as? android.view.ViewGroup)?.removeView(webView)
            webView.stopLoading()
            webView.onPause()
            webView.clearHistory()
            webView.loadUrl("about:blank")
            webView.removeAllViews()
            webView.destroy()
        } catch (e: Exception) {
            Log.e(TAG, "Error safely destroying WebView", e)
        }
    }

    @JavascriptInterface
    fun softCleanup() {
        (context as MainActivity).runOnUiThread {
            contentWebView?.let {
                it.stopLoading()
                it.visibility = View.GONE
            }
        }
    }

    // ── System Information ─────────────────────────────────────────────────────

    @JavascriptInterface
    fun isDarkMode(): Boolean = ThemeUtils.isSystemDarkMode(context)

    @JavascriptInterface
    fun getAppVersion(): String? {
        return try {
            val pInfo: PackageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            pInfo.versionName
        } catch (e: PackageManager.NameNotFoundException) {
            Log.e(TAG, "Package name not found", e)
            "7.0.0"
        }
    }

    @JavascriptInterface
    fun getDeviceInfo(): String {
        return """
        {
            "manufacturer": "${Build.MANUFACTURER}",
            "model": "${Build.MODEL}",
            "androidVersion": "${Build.VERSION.RELEASE}",
            "sdkVersion": ${Build.VERSION.SDK_INT}
        }
        """.trimIndent()
    }

    // ── WebView Management ─────────────────────────────────────────────────────

    @JavascriptInterface
    fun updateWebView(
        url: String,
        left: Int,
        top: Int,
        width: Int,
        height: Int,
        marginTopPercent: Float,
        marginBottomPercent: Float,
        isTablet: Boolean
    ) {
        (context as MainActivity).runOnUiThread {
            try {
                if (contentWebView == null) {
                    currentUrl = url
                    createAndSetupWebView(url, left, top, width, height, marginTopPercent, marginBottomPercent, isTablet)
                } else if (currentUrl != url) {
                    currentUrl = url
                    Log.d(TAG, "Loading new URL in existing WebView: $url")
                    notifyLoading()
                    contentWebView?.visibility = if (isWebViewVisible) View.VISIBLE else View.GONE
                    contentWebView?.loadUrl(url)
                }
                updateWebViewPosition(left, top, width, height, marginTopPercent, marginBottomPercent, isTablet)
            } catch (e: Exception) {
                Log.e(TAG, "Error updating WebView", e)
                notifyError("setup_error")
            }
        }
    }

    @JavascriptInterface
    fun updateUrl(newUrl: String) {
        (context as MainActivity).runOnUiThread {
            if (currentUrl != newUrl && contentWebView != null) {
                currentUrl = newUrl
                Log.d(TAG, "Updating URL only: $newUrl")
                notifyLoading()
                contentWebView?.visibility = if (isWebViewVisible) View.VISIBLE else View.GONE
                contentWebView?.loadUrl(newUrl)
            }
        }
    }

    private fun createAndSetupWebView(
        url: String,
        left: Int,
        top: Int,
        width: Int,
        height: Int,
        marginTopPercent: Float,
        marginBottomPercent: Float,
        isTablet: Boolean
    ) {
        val (calculatedWidth, calculatedHeight, calculatedLeft, calculatedTop) =
            calculateWebViewDimensions(left, top, width, height, marginTopPercent, marginBottomPercent, isTablet)

        val webView = WebView(context).apply {
            layoutParams = FrameLayout.LayoutParams(calculatedWidth, calculatedHeight).apply {
                this.leftMargin = calculatedLeft
                this.topMargin = calculatedTop
            }

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                builtInZoomControls = true
                displayZoomControls = false
                loadWithOverviewMode = true
                useWideViewPort = true
                setGeolocationEnabled(true)
                setGeolocationDatabasePath(context.filesDir.path)
                allowFileAccessFromFileURLs = false
                allowUniversalAccessFromFileURLs = false

                if (isTablet) {
                    minimumFontSize = 12
                    defaultFontSize = 16
                } else {
                    minimumFontSize = 10
                    defaultFontSize = 14
                }
            }

            setBackgroundColor(Color.WHITE)

            webViewClient = object : WebViewClient() {

                @RequiresApi(Build.VERSION_CODES.M)
                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest,
                    error: WebResourceError
                ) {
                    if (request.isForMainFrame) {
                        val errorCode = error.description?.toString() ?: "unknown_error"
                        Log.e(TAG, "Main frame error: $errorCode, url: ${request.url}")

                        view?.stopLoading()
                        view?.visibility = View.GONE
                        view?.loadUrl("about:blank")

                        view?.postDelayed({
                            notifyError(errorCode)
                        }, 100)
                    }
                }

                @Suppress("DEPRECATION")
                override fun onReceivedError(
                    view: WebView?,
                    errorCode: Int,
                    description: String?,
                    failingUrl: String?
                ) {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                        Log.e(TAG, "Legacy error: $errorCode, $description, $failingUrl")
                        view?.stopLoading()
                        view?.visibility = View.GONE
                        view?.loadUrl("about:blank")

                        view?.postDelayed({
                            notifyError(description ?: "error_$errorCode")
                        }, 100)
                    }
                }

                @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
                override fun onReceivedHttpError(
                    view: WebView?,
                    request: WebResourceRequest,
                    errorResponse: WebResourceResponse
                ) {
                    if (request.isForMainFrame) {
                        val statusCode = errorResponse.statusCode
                        if (statusCode >= 400) {
                            Log.e(TAG, "HTTP error: $statusCode, url: ${request.url}")
                            view?.stopLoading()
                            view?.visibility = View.GONE
                            view?.loadUrl("about:blank")

                            view?.postDelayed({
                                notifyError("HTTP $statusCode")
                            }, 100)
                        }
                    }
                }

                override fun onReceivedSslError(
                    view: WebView?,
                    handler: SslErrorHandler,
                    error: SslError
                ) {
                    Log.w(TAG, "SSL error: ${error.url}, code: ${error.primaryError}")
                    handler.cancel()
                    view?.visibility = View.GONE
                    view?.loadUrl("about:blank")

                    view?.postDelayed({
                        notifyError("SSL_ERROR")
                    }, 100)
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    if (url != null && url != "about:blank") {
                        Log.d(TAG, "Page started: $url")
                        notifyLoading()
                    }
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (url != null && url != "about:blank") {
                        Log.d(TAG, "Page finished: $url")
                        view?.visibility = if (isWebViewVisible) View.VISIBLE else View.GONE
                        notifyLoaded()
                    }
                }

                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    return false
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onGeolocationPermissionsShowPrompt(
                    origin: String?,
                    callback: GeolocationPermissions.Callback?
                ) {
                    Log.d(TAG, "Geolocation requested: $origin")
                    geolocationCallback = callback
                    geolocationOrigin = origin

                    if (ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.ACCESS_FINE_LOCATION
                        ) == PackageManager.PERMISSION_GRANTED
                    ) {
                        callback?.invoke(origin, true, false)
                    } else {
                        (context as MainActivity).requestPermissions(
                            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                            MainActivity.LOCATION_PERMISSION_REQUEST_CODE
                        )
                    }
                }
            }
        }

        contentWebView = webView
        contentContainer.addView(webView)

        Log.d(TAG, "Loading URL: $url")
        notifyLoading()
        webView.loadUrl(url)
    }

    private fun calculateWebViewDimensions(
        left: Int, top: Int, width: Int, height: Int,
        marginTopPercent: Float, marginBottomPercent: Float, isTablet: Boolean
    ): WebViewDimensions {
        val displayMetrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (context as MainActivity).windowManager.defaultDisplay.getMetrics(displayMetrics)
        val screenWidth = displayMetrics.widthPixels
        val screenHeight = displayMetrics.heightPixels
        val density = displayMetrics.density
        val isLandscape = screenWidth > screenHeight

        val widthPx = (width * density).toInt()
        val heightPx = (height * density).toInt()

        val finalWidth = if (isLandscape) screenWidth else minOf(widthPx, screenWidth)

        val marginTopPx = (screenHeight * marginTopPercent).toInt()
        val marginBottomPx = (screenHeight * marginBottomPercent).toInt()
        val availableHeight = screenHeight - marginTopPx - marginBottomPx
        val finalHeight = minOf(heightPx, availableHeight)

        val finalLeft = if (isLandscape) 0 else max(0, (screenWidth - finalWidth) / 2)
        val finalTop = if (isLandscape) marginTopPx else top

        Log.d(TAG, "Dimensions - Landscape: $isLandscape, Screen: ${screenWidth}x$screenHeight, Final: ${finalWidth}x${finalHeight} at ($finalLeft, $finalTop)")

        return WebViewDimensions(finalWidth, finalHeight, finalLeft, finalTop)
    }

    private fun updateWebViewPosition(
        left: Int, top: Int, width: Int, height: Int,
        marginTopPercent: Float, marginBottomPercent: Float, isTablet: Boolean
    ) {
        contentWebView?.let { webView ->
            val (calculatedWidth, calculatedHeight, calculatedLeft, calculatedTop) =
                calculateWebViewDimensions(left, top, width, height, marginTopPercent, marginBottomPercent, isTablet)

            webView.layoutParams = FrameLayout.LayoutParams(calculatedWidth, calculatedHeight).apply {
                this.leftMargin = calculatedLeft
                this.topMargin = calculatedTop
            }
        }
    }

    // ── Retry ─────────────────────────────────────────────────────────────────

    @JavascriptInterface
    fun retryLoading() {
        (context as MainActivity).runOnUiThread {
            Log.d(TAG, "Retry loading: $currentUrl")
            currentUrl?.let { url ->
                notifyLoading()
                contentWebView?.visibility = if (isWebViewVisible) View.VISIBLE else View.GONE
                contentWebView?.loadUrl(url)
            }
        }
    }

    // ── Permissions ───────────────────────────────────────────────────────────

    fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == MainActivity.LOCATION_PERMISSION_REQUEST_CODE) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            geolocationCallback?.invoke(geolocationOrigin, granted, false)
            Log.d(TAG, "Geolocation permission ${if (granted) "granted" else "denied"}: $geolocationOrigin")
            geolocationCallback = null
            geolocationOrigin = null
        }
    }

    // ── Visibility ────────────────────────────────────────────────────────────

    @JavascriptInterface
    fun hideWebView() {
        (context as MainActivity).runOnUiThread {
            isWebViewVisible = false
            contentWebView?.visibility = View.GONE
        }
    }

    @JavascriptInterface
    fun showWebView() {
        (context as MainActivity).runOnUiThread {
            isWebViewVisible = true
            contentWebView?.visibility = View.VISIBLE
        }
    }

    @JavascriptInterface
    fun onTabChanged(tabId: String) {
        (context as MainActivity).runOnUiThread {
            if (tabId != "map") {
                hideWebView()
                softCleanup()
            } else {
                showWebView()
            }
        }
    }

    @JavascriptInterface
    fun getLocationStatus(): String {
        return try {
            val permission = Manifest.permission.ACCESS_FINE_LOCATION
            when {
                ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED -> "granted"
                ActivityCompat.shouldShowRequestPermissionRationale(context as MainActivity, permission) -> "should_show_rationale"
                else -> "denied"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting location status", e)
            "unknown"
        }
    }

    // ── Update Management ─────────────────────────────────────────────────────

    @JavascriptInterface
    fun checkForUpdates() {
        updateManager.checkForUpdates(object : UpdateCallback {
            override fun onResult(e: Exception?) {
                val message = e?.message ?: ""
                when {
                    e == null -> postEvent("updateAvailable", "{ alreadyDownloaded: true }")
                    message == "Обновление доступно" -> postEvent("updateAvailable")
                    message == "Update Available" -> postEvent("updateAvailable")
                    message == "Уже скачивается" -> postUpdateError("Обновление уже скачивается")
                    else -> postUpdateError(message.ifEmpty { "Неизвестная ошибка" })
                }
            }
            override fun onProgress(progress: Int) {}
        })
    }

    @JavascriptInterface
    fun startFlexibleUpdate() {
        updateManager.startFlexibleUpdate(object : UpdateCallback {
            override fun onResult(e: Exception?) {
                if (e == null) {
                    if (updateManager.isDownloaded()) postEvent("updateDownloaded")
                    else postEvent("updateStarted")
                } else {
                    postUpdateError(e.message ?: "Неизвестная ошибка")
                }
            }
            override fun onProgress(progress: Int) {
                postEvent("updateProgress", progress.toString())
            }
        })
    }

    @JavascriptInterface
    fun installUpdate() {
        updateManager.completeUpdate(object : UpdateCallback {
            override fun onResult(e: Exception?) {
                e?.let { postUpdateError(it.message ?: "Ошибка при установке") }
            }
            override fun onProgress(progress: Int) {}
        })
    }

    @JavascriptInterface
    fun checkIsLatestVersion() {
        updateManager.checkIsLatestVersion(object : UpdateCallback {
            override fun onResult(e: Exception?) {
                if (e == null) postEvent("isLatestVersion")
                else postEvent("updateAvailable")
            }
            override fun onProgress(progress: Int) {}
        })
    }

    private fun postEvent(eventName: String, detail: String = "") {
        (context as MainActivity).runOnUiThread {
            mainWebView.evaluateJavascript(
                "window.dispatchEvent(new CustomEvent('$eventName'" +
                        (if (detail.isNotEmpty()) ", { detail: $detail }" else "") + "));",
                null
            )
        }
    }

    private fun postUpdateError(message: String) {
        postEvent("updateError", "'$message'")
    }

    // ── Ad Free Control ───────────────────────────────────────────────────────

    /**
     * Возвращает текущее состояние рекламного контроля.
     * Вызывается из React: window.Android.getAdFreeState()
     */
    @JavascriptInterface
    fun getAdFreeState(): String {
        return (context as MainActivity).getAdControlStateJson()
    }

    /**
     * Показывает rewarded рекламу.
     * После просмотра — баннер выключается на 5 минут.
     * Кнопка доступна раз в 24 часа.
     * Вызывается из React: window.Android.showRewardedAd()
     */
    @JavascriptInterface
    fun showRewardedAd(): String {
        return (context as MainActivity).showRewardedAd()
    }

    /**
     * Проверяет готова ли rewarded реклама к показу.
     * Вызывается из React: window.Android.isRewardedAdReady()
     */
    @JavascriptInterface
    fun isRewardedAdReady(): Boolean {
        return (context as MainActivity).rewardedAdManager?.isReady() ?: false
    }

    /**
     * Активирует режим "без рекламы" на 5 минут напрямую (без видео).
     * Кулдаун — 24 часа.
     * Вызывается из React: window.Android.activateAdFreeFor5Minutes()
     */
    @JavascriptInterface
    fun activateAdFreeFor5Minutes(): String {
        val success = (context as MainActivity).activateAdFreeFor5Minutes()
        return if (success) {
            """{"success": true}"""
        } else {
            val state = (context as MainActivity).getAdControlStateJson()
            """{"success": false, "state": $state}"""
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    fun onPause() { contentWebView?.onPause() }
    fun onResume() { contentWebView?.onResume() }

    private data class WebViewDimensions(
        val width: Int, val height: Int, val left: Int, val top: Int
    )
}