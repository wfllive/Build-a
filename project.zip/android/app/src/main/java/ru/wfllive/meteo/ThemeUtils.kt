package ru.wfllive.meteo

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.provider.Settings

/**
 * Утилиты для работы с системной темой, которые:
 * 1. Определяют, включена ли темная тема на устройстве
 * 2. Поддерживают различные версии Android
 */
object ThemeUtils {
    /**
     * Проверяет, включена ли темная тема на устройстве
     * @param context Контекст приложения
     * @return true если темная тема включена, false в противном случае
     */
    fun isSystemDarkMode(context: Context): Boolean {
        return when {
            // Android 10+ (Q)
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> {
                val nightModeFlags = context.resources.configuration.uiMode and 
                    Configuration.UI_MODE_NIGHT_MASK
                nightModeFlags == Configuration.UI_MODE_NIGHT_YES
            }
            // Android 9 (P)
            Build.VERSION.SDK_INT == Build.VERSION_CODES.P -> {
                try {
                    // Проверяем системную настройку ночного режима
                    val uiNightMode = Settings.Secure.getInt(
                        context.contentResolver,
                        "ui_night_mode"
                    )
                    uiNightMode == 2 // 2 означает "включено ночью" (темная тема)
                } catch (e: Settings.SettingNotFoundException) {
                    // Если настройка не найдена, проверяем стандартным способом
                    (context.resources.configuration.uiMode and 
                        Configuration.UI_MODE_NIGHT_YES) != 0
                }
            }
            // Более старые версии Android
            else -> false
        }
    }
}