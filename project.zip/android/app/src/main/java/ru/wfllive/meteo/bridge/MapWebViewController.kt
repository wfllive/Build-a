package ru.wfllive.meteo.bridge

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.net.http.SslError
import android.os.Build
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.webkit.GeolocationPermissions
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import org.json.JSONObject

/**
 * Нативный WebView карты (Blitzortung / Windy / ...), который лежит ПОВЕРХ
 * главного WebView приложения.
 *
 * Зачем вообще нативный WebView, а не <iframe>: большинство погодных карт
 * запрещают встраивание (X-Frame-Options / CSP frame-ancestors), плюс им нужна
 * настоящая геолокация и свой zoom.
 *
 * Что здесь исправлено по сравнению со старым WebAppInterface:
 *  1) Геометрия приходит одним JSON-ом: реальный rect слота + размер вьюпорта,
 *     без «магических» marginTopPercent/360dp/isTablet.
 *  2) Масштаб CSS→px считается от размеров хост-WebView, а не от DisplayMetrics.
 *  3) Отступы системы применяются в координатах КОНТЕЙНЕРА (см. localize()).
 *  4) При смене insets/поворота/размера контейнера раскладка пересчитывается
 *     нативно и мгновенно — не ждём round-trip в JS.
 *  5) Все события уходят через единый [BridgeChannel] (+ legacy-колбэки).
 */
class MapWebViewController(
    private val activity: Activity,
    private val channel: BridgeChannel
) {

    private var container: FrameLayout? = null
    private var hostWebView: WebView? = null
    private var mapWebView: WebView? = null

    private var lastRequest: MapLayoutRequest? = null
    private var lastRect: Rect? = null
    private var currentUrl: String? = null
    private var visible: Boolean = true
    private var status: String = STATUS_IDLE

    private var insetsProvider: () -> SystemInsets = { SystemInsets() }

    private var geolocationCallback: GeolocationPermissions.Callback? = null
    private var geolocationOrigin: String? = null

    // ── Подключение ───────────────────────────────────────────────────────────

    fun attach(container: FrameLayout, hostWebView: WebView, insets: () -> SystemInsets) {
        this.container = container
        this.hostWebView = hostWebView
        this.insetsProvider = insets

        // Контейнер сам пересчитывает раскладку при любом изменении размеров
        // (поворот, разделённый экран, свёрнутый баннер, клавиатура и т.д.).
        container.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, or_, ob ->
            if (l != ol || t != ot || r != or_ || b != ob) {
                relayout()
            }
        }
    }

    /** Вызывается, когда системные отступы изменились. */
    fun onInsetsChanged() = relayout()

    // ── Публичное API (дёргается из NativeBridge) ─────────────────────────────

    fun applyLayout(request: MapLayoutRequest) {
        activity.runOnUiThread {
            lastRequest = request
            val url = request.url

            if (url != null && url != currentUrl) {
                currentUrl = url
                ensureWebView()?.let { web ->
                    setStatus(STATUS_LOADING, url)
                    web.loadUrl(url)
                }
            } else {
                ensureWebView()
            }

            setVisibleInternal(request.visible)
            relayout()
        }
    }

    fun setUrl(url: String) {
        activity.runOnUiThread {
            if (url.isBlank() || url == currentUrl) return@runOnUiThread
            currentUrl = url
            lastRequest = lastRequest?.copy(url = url)
            val web = ensureWebView() ?: return@runOnUiThread
            setStatus(STATUS_LOADING, url)
            web.visibility = if (visible) View.VISIBLE else View.GONE
            web.loadUrl(url)
        }
    }

    fun reload() {
        activity.runOnUiThread {
            val url = currentUrl ?: return@runOnUiThread
            val web = ensureWebView() ?: return@runOnUiThread
            setStatus(STATUS_LOADING, url)
            web.visibility = if (visible) View.VISIBLE else View.GONE
            web.loadUrl(url)
        }
    }

    fun show() = activity.runOnUiThread { setVisibleInternal(true) }

    fun hide() = activity.runOnUiThread { setVisibleInternal(false) }

    /** Мягкая остановка: карта скрыта и не грузит трафик, но WebView жив. */
    fun suspendMap() {
        activity.runOnUiThread {
            mapWebView?.let {
                it.stopLoading()
                it.onPause()
                it.visibility = View.GONE
            }
            visible = false
        }
    }

    /** Полностью убить WebView карты (например, при уходе с вкладки надолго). */
    fun release() {
        activity.runOnUiThread {
            mapWebView?.let { web ->
                try {
                    (web.parent as? ViewGroup)?.removeView(web)
                    web.stopLoading()
                    web.onPause()
                    web.clearHistory()
                    web.loadUrl("about:blank")
                    web.removeAllViews()
                    web.destroy()
                } catch (e: Exception) {
                    Log.e(TAG, "release() failed", e)
                }
            }
            mapWebView = null
            currentUrl = null
            lastRect = null
            setStatus(STATUS_RELEASED, null)
        }
    }

    fun onPause() {
        mapWebView?.onPause()
    }

    fun onResume() {
        if (visible) mapWebView?.onResume()
    }

    fun statusJson(): String = JSONObject()
        .put("status", status)
        .put("url", currentUrl ?: JSONObject.NULL)
        .put("visible", visible)
        .put("attached", mapWebView != null)
        .put("rect", lastRect?.let {
            JSONObject()
                .put("left", it.left)
                .put("top", it.top)
                .put("width", it.width())
                .put("height", it.height())
        } ?: JSONObject.NULL)
        .toString()

    // ── Геолокация ────────────────────────────────────────────────────────────

    fun onLocationPermissionResult(granted: Boolean) {
        geolocationCallback?.invoke(geolocationOrigin, granted, false)
        geolocationCallback = null
        geolocationOrigin = null
    }

    // ── Раскладка ─────────────────────────────────────────────────────────────

    private fun relayout() {
        val web = mapWebView ?: return
        val box = container ?: return
        val host = hostWebView ?: return
        val request = lastRequest ?: return

        val hostWidth = if (host.width > 0) host.width else box.width
        val hostHeight = if (host.height > 0) host.height else box.height
        if (hostWidth <= 0 || hostHeight <= 0) return

        val decor = activity.window.decorView
        val location = IntArray(2)
        box.getLocationInWindow(location)

        val localInsets = MapViewportGeometry.localize(
            insets = insetsProvider(),
            containerLeft = location[0],
            containerTop = location[1],
            containerWidth = box.width,
            containerHeight = box.height,
            windowWidth = if (decor.width > 0) decor.width else box.width,
            windowHeight = if (decor.height > 0) decor.height else box.height
        )

        val rect = MapViewportGeometry.resolve(request, hostWidth, hostHeight, localInsets)

        if (rect.isEmpty) {
            web.visibility = View.GONE
            lastRect = rect
            return
        }

        if (rect != lastRect) {
            lastRect = rect
            web.layoutParams = FrameLayout.LayoutParams(rect.width(), rect.height()).apply {
                leftMargin = rect.left
                topMargin = rect.top
            }
            web.requestLayout()
            if (BuildLog.VERBOSE) {
                Log.d(
                    TAG,
                    "layout -> ${rect.width()}x${rect.height()} @(${rect.left},${rect.top}) " +
                        "host=${hostWidth}x$hostHeight mode=${request.mode} " +
                        "nav=${localInsets.navigationMode} tappableBottom=${localInsets.tappableBottom}"
                )
            }
        }

        web.visibility = if (visible) View.VISIBLE else View.GONE
    }

    private fun setVisibleInternal(value: Boolean) {
        visible = value
        val web = mapWebView ?: return
        web.visibility = if (value) View.VISIBLE else View.GONE
        if (value) web.onResume() else web.onPause()
    }

    // ── Создание WebView ──────────────────────────────────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureWebView(): WebView? {
        mapWebView?.let { return it }
        val box = container ?: return null

        val web = WebView(activity).apply {
            layoutParams = FrameLayout.LayoutParams(0, 0)
            setBackgroundColor(Color.TRANSPARENT)
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                builtInZoomControls = true
                displayZoomControls = false
                // useWideViewPort + loadWithOverviewMode: сайт сам решает свой вьюпорт,
                // масштаб не «прыгает» между устройствами.
                useWideViewPort = true
                loadWithOverviewMode = true
                setSupportZoom(true)
                setGeolocationEnabled(true)
                allowFileAccess = false
                allowContentAccess = false
                @Suppress("DEPRECATION")
                allowFileAccessFromFileURLs = false
                @Suppress("DEPRECATION")
                allowUniversalAccessFromFileURLs = false
                mediaPlaybackRequiresUserGesture = true
                cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
            }

            webViewClient = MapClient()
            webChromeClient = MapChromeClient()
        }

        box.addView(web)
        mapWebView = web
        return web
    }

    // ── Клиенты ───────────────────────────────────────────────────────────────

    private inner class MapClient : WebViewClient() {

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)
            if (url != null && url != BLANK) setStatus(STATUS_LOADING, url)
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            if (url != null && url != BLANK) {
                view?.visibility = if (visible) View.VISIBLE else View.GONE
                setStatus(STATUS_LOADED, url)
                relayout()
            }
        }

        override fun onReceivedError(
            view: WebView?,
            request: WebResourceRequest?,
            error: WebResourceError?
        ) {
            super.onReceivedError(view, request, error)
            if (request?.isForMainFrame != true) return
            val description = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                error?.description?.toString() ?: "unknown_error"
            } else {
                "unknown_error"
            }
            failWith(view, description)
        }

        override fun onReceivedHttpError(
            view: WebView?,
            request: WebResourceRequest?,
            errorResponse: WebResourceResponse?
        ) {
            super.onReceivedHttpError(view, request, errorResponse)
            if (request?.isForMainFrame != true) return
            val code = errorResponse?.statusCode ?: 0
            if (code >= 400) failWith(view, "HTTP $code")
        }

        override fun onReceivedSslError(
            view: WebView?,
            handler: SslErrorHandler,
            error: SslError?
        ) {
            handler.cancel()
            failWith(view, "SSL_ERROR")
        }

        private fun failWith(view: WebView?, description: String) {
            Log.e(TAG, "map load error: $description ($currentUrl)")
            view?.stopLoading()
            view?.visibility = View.GONE
            view?.loadUrl(BLANK)
            val offline = !ru.wfllive.meteo.NetworkUtils.isNetworkAvailable(activity)
            view?.postDelayed({
                setStatus(if (offline) STATUS_OFFLINE else STATUS_ERROR, currentUrl, description)
            }, 100)
        }
    }

    private inner class MapChromeClient : WebChromeClient() {
        override fun onGeolocationPermissionsShowPrompt(
            origin: String?,
            callback: GeolocationPermissions.Callback?
        ) {
            geolocationOrigin = origin
            geolocationCallback = callback

            val granted = ContextCompat.checkSelfPermission(
                activity,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED

            if (granted) {
                callback?.invoke(origin, true, false)
                geolocationCallback = null
                geolocationOrigin = null
            } else {
                activity.requestPermissions(
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                    LOCATION_PERMISSION_REQUEST_CODE
                )
            }
        }
    }

    // ── События ───────────────────────────────────────────────────────────────

    private fun setStatus(newStatus: String, url: String?, description: String? = null) {
        status = newStatus

        val payload = JSONObject()
            .put("status", newStatus)
            .put("url", url ?: JSONObject.NULL)
            .put("description", description ?: JSONObject.NULL)
            .put("visible", visible)

        channel.emit(BridgeEvents.MAP, payload)

        // Legacy-колбэки старого UI — чтобы ничего не сломалось при обновлении.
        when (newStatus) {
            STATUS_LOADING -> channel.callGlobal("onWebViewLoading")
            STATUS_LOADED -> channel.callGlobal("onWebViewLoaded")
            STATUS_ERROR -> channel.callGlobal("onWebViewError", description ?: "error")
            STATUS_OFFLINE -> channel.callGlobal("onWebViewOffline")
        }
    }

    companion object {
        private const val TAG = "MapWebViewController"
        private const val BLANK = "about:blank"

        const val LOCATION_PERMISSION_REQUEST_CODE = 1001

        const val STATUS_IDLE = "idle"
        const val STATUS_LOADING = "loading"
        const val STATUS_LOADED = "loaded"
        const val STATUS_ERROR = "error"
        const val STATUS_OFFLINE = "offline"
        const val STATUS_RELEASED = "released"
    }
}

/** Мини-обёртка, чтобы не тянуть BuildConfig в чистые классы. */
internal object BuildLog {
    var VERBOSE: Boolean = false
}
