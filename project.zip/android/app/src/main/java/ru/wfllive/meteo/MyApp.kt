/*package ru.wfllive.meteo

import android.app.Application
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.PrintWriter
import java.io.StringWriter

class MyApp : Application() {
 
    override fun onCreate() {
        super.onCreate()
        
        // Set up your custom uncaught exception handler
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            // Format the error stack trace
            val sw = StringWriter()
            throwable.printStackTrace(PrintWriter(sw))
            val errorStack = sw.toString()
            Log.e("CRASH", errorStack)
        }
    }
    
}*/



package ru.wfllive.meteo

import android.app.Application
import android.util.Log
import java.io.PrintWriter
import java.io.StringWriter

class MyApp : Application() {

    // ДОБАВЛЕНО: Создаем экземпляр менеджера здесь
    lateinit var forceUpdateManager: ForceUpdateManager
        private set // Делаем сеттер приватным, чтобы его нельзя было изменить извне

    override fun onCreate() {
        super.onCreate()

        // ДОБАВЛЕНО: Инициализируем менеджер один раз при старте приложения
        forceUpdateManager = ForceUpdateManager(this)

        // Ваш код для отслеживания крэшей остается
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            val sw = StringWriter()
            throwable.printStackTrace(PrintWriter(sw))
            val errorStack = sw.toString()
            Log.e("CRASH", "Uncaught exception: $errorStack")
        }
    }
}


