package ru.wfllive.meteo.bridge

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import android.webkit.JavascriptInterface
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import ru.wfllive.meteo.UpdateCallback

/**
 * ЕДИНАЯ точка входа «JS → native».
 *
 * Регистрируется в WebView как:
 *   • window.AndroidBridge — новый API (v2, всё через JSON);
 *   • window.Android       — тот же объект под старым именем (обратная совместимость).
 *
 * Правила этого класса:
 *   • только приём вызовов и делегирование — никакой логики UI;
 *   • всё, что возвращается в JS, — строка JSON (WebView умеет отдавать
 *     из @JavascriptInterface только примитивы);
 *   • ни одного падения наружу: любое исключение логируется и возвращается как
 *     {"ok":false,"error":"..."} — иначе JS-поток молча умирает.
 *
 * JS-зеркало этого файла: src/native/bridge/androidBridge.js
 * Документация контракта:  docs/native-bridge.md
 */
class NativeBridge(
    private val host: BridgeHost,
    private val channel: BridgeChannel,
    private val insets: SystemInsetsController,
    private val map: MapWebViewController
) {

    private val activity get() = host.hostActivity

    // ── Служебное ─────────────────────────────────────────────────────────────

    /** Версия контракта. JS проверяет её, чтобы понять, что доступен новый API. */
    @JavascriptInterface
    fun bridgeVersion(): Int = BRIDGE_VERSION

    @JavascriptInterface
    fun ping(): String = ok(JSONObject().put("version", BRIDGE_VERSION))

    /**
     * Лог из JS в Logcat.
     *
     * Тег "js-error" пишется через Log.e — он переживает R8 в release-сборке
     * (см. -assumenosideeffects в proguard-rules.pro), поэтому необработанные
     * ошибки веба видно в `adb logcat | grep WebLog`.
     */
    @JavascriptInterface
    fun log(tag: String?, message: String?) {
        val safeTag = "WebLog/${tag ?: "app"}"
        val text = message ?: ""
        if (tag == "js-error") Log.e(safeTag, text) else Log.d(safeTag, text)
    }

    // ── Система ───────────────────────────────────────────────────────────────

    @JavascriptInterface
    fun getAppVersion(): String = safeString("0.0.0") {
        activity.packageManager.getPackageInfo(activity.packageName, 0).versionName ?: "0.0.0"
    }

    @JavascriptInterface
    fun getDeviceInfo(): String = safeString("{}") {
        JSONObject()
            .put("manufacturer", Build.MANUFACTURER)
            .put("model", Build.MODEL)
            .put("androidVersion", Build.VERSION.RELEASE)
            .put("sdkVersion", Build.VERSION.SDK_INT)
            .put("density", activity.resources.displayMetrics.density.toDouble())
            .put("widthPx", activity.resources.displayMetrics.widthPixels)
            .put("heightPx", activity.resources.displayMetrics.heightPixels)
            .put("smallestWidthDp", activity.resources.configuration.smallestScreenWidthDp)
            .put("isTablet", activity.resources.configuration.smallestScreenWidthDp >= 600)
            .toString()
    }

    /** Безопасные отступы (status bar / nav bar / вырез / клавиатура) в px и CSS-px. */
    @JavascriptInterface
    fun getInsets(): String = safeString("{}") { insets.currentJson() }

    /** Попросить native ещё раз прислать insets (например, после reload страницы). */
    @JavascriptInterface
    fun requestInsets() {
        activity.runOnUiThread { insets.resend() }
    }

    @JavascriptInterface
    fun isDarkMode(): Boolean = safeBoolean(false) { host.isDarkThemeNow() }

    // ── Геолокация ────────────────────────────────────────────────────────────

    @JavascriptInterface
    fun getLocationStatus(): String = safeString("unknown") {
        val permission = Manifest.permission.ACCESS_FINE_LOCATION
        when {
            ContextCompat.checkSelfPermission(activity, permission) ==
                PackageManager.PERMISSION_GRANTED -> "granted"

            ActivityCompat.shouldShowRequestPermissionRationale(activity, permission) ->
                "should_show_rationale"

            else -> "denied"
        }
    }

    /**
     * Раньше этого метода не существовало, хотя веб его вызывал
     * (LocationPermission.jsx, useWeatherData.jsx) — поэтому запрос прав
     * из веба просто молча не работал.
     */
    @JavascriptInterface
    fun requestLocationPermission() {
        activity.runOnUiThread { host.requestLocationPermissionFromWeb() }
    }

    // ── Карта: новый API ──────────────────────────────────────────────────────

    /**
     * Основной метод раскладки карты.
     *
     * Формат payload:
     * {
     *   "url": "https://map.blitzortung.org",
     *   "rect":     { "x": 0, "y": 96, "width": 412, "height": 620 },  // CSS-px, getBoundingClientRect()
     *   "viewport": { "width": 412, "height": 915 },                   // window.innerWidth/innerHeight
     *   "insetsMode": "auto" | "safe" | "edge",
     *   "visible": true
     * }
     */
    @JavascriptInterface
    fun mapUpdate(payload: String?): String = safeString(fail("empty payload")) {
        val request = MapLayoutRequest.fromJson(payload ?: "{}")
        map.applyLayout(request)
        ok()
    }

    @JavascriptInterface
    fun mapSetUrl(url: String?) {
        if (!url.isNullOrBlank()) map.setUrl(url)
    }

    @JavascriptInterface
    fun mapShow() = map.show()

    @JavascriptInterface
    fun mapHide() = map.hide()

    @JavascriptInterface
    fun mapReload() = map.reload()

    /** Скрыть и остановить, но не уничтожать (быстрый возврат на вкладку). */
    @JavascriptInterface
    fun mapSuspend() = map.suspendMap()

    /** Полностью уничтожить WebView карты. */
    @JavascriptInterface
    fun mapRelease() = map.release()

    @JavascriptInterface
    fun mapStatus(): String = safeString("{}") { map.statusJson() }

    // ── Карта: старый API (оставлен, чтобы старый бандл не сломался) ──────────

    @Deprecated("Используйте mapUpdate(json)")
    @JavascriptInterface
    fun updateWebView(
        url: String,
        left: Int,
        top: Int,
        width: Int,
        height: Int,
        marginTopPercent: Float,
        marginBottomPercent: Float,
        isTablet: Boolean
    ) {
        map.applyLayout(
            MapLayoutRequest(
                url = url,
                x = left.toFloat(),
                y = top.toFloat(),
                width = width.toFloat(),
                height = height.toFloat(),
                viewportWidth = 0f,   // старый API вьюпорт не присылал → масштаб по density
                viewportHeight = 0f,
                mode = InsetsMode.AUTO,
                visible = true
            )
        )
    }

    @Deprecated("Используйте mapSetUrl(url)")
    @JavascriptInterface
    fun updateUrl(newUrl: String) = map.setUrl(newUrl)

    @Deprecated("Используйте mapShow()")
    @JavascriptInterface
    fun showWebView() = map.show()

    @Deprecated("Используйте mapHide()")
    @JavascriptInterface
    fun hideWebView() = map.hide()

    @Deprecated("Используйте mapReload()")
    @JavascriptInterface
    fun retryLoading() = map.reload()

    @Deprecated("Используйте mapSuspend()")
    @JavascriptInterface
    fun softCleanup() = map.suspendMap()

    @JavascriptInterface
    fun onTabChanged(tabId: String?) {
        if (tabId == "map") map.show() else map.suspendMap()
    }

    // ── Реклама ───────────────────────────────────────────────────────────────

    @JavascriptInterface
    fun getAdFreeState(): String = safeString("{}") { host.getAdControlStateJson() }

    @JavascriptInterface
    fun showRewardedAd(): String = safeString(fail("rewarded failed")) { host.showRewardedAd() }

    @JavascriptInterface
    fun isRewardedAdReady(): Boolean = safeBoolean(false) { host.isRewardedAdReady() }

    @JavascriptInterface
    fun activateAdFreeFor5Minutes(): String = safeString(fail("ad free failed")) {
        val success = host.activateAdFreeFor5Minutes()
        if (success) {
            ok()
        } else {
            JSONObject()
                .put("ok", false)
                .put("success", false)
                .put("state", JSONObject(host.getAdControlStateJson()))
                .toString()
        }
    }

    // ── Обновления ────────────────────────────────────────────────────────────

    @JavascriptInterface
    fun checkForUpdates() {
        host.updateManager.checkForUpdates(object : UpdateCallback {
            override fun onResult(e: Exception?) {
                val message = e?.message ?: ""
                when {
                    e == null -> channel.emit(
                        "updateAvailable",
                        JSONObject().put("alreadyDownloaded", true)
                    )

                    message == "Обновление доступно" || message == "Update Available" ->
                        channel.emit("updateAvailable")

                    message == "Уже скачивается" ->
                        channel.emit("updateError", "Обновление уже скачивается")

                    else -> channel.emit("updateError", message.ifEmpty { "Неизвестная ошибка" })
                }
            }

            override fun onProgress(progress: Int) = Unit
        })
    }

    @JavascriptInterface
    fun startFlexibleUpdate() {
        host.updateManager.startFlexibleUpdate(object : UpdateCallback {
            override fun onResult(e: Exception?) {
                if (e == null) {
                    if (host.updateManager.isDownloaded()) channel.emit("updateDownloaded")
                    else channel.emit("updateStarted")
                } else {
                    channel.emit("updateError", e.message ?: "Неизвестная ошибка")
                }
            }

            override fun onProgress(progress: Int) {
                channel.emit("updateProgress", progress)
            }
        })
    }

    @JavascriptInterface
    fun installUpdate() {
        host.updateManager.completeUpdate(object : UpdateCallback {
            override fun onResult(e: Exception?) {
                e?.let { channel.emit("updateError", it.message ?: "Ошибка при установке") }
            }

            override fun onProgress(progress: Int) = Unit
        })
    }

    @JavascriptInterface
    fun checkIsLatestVersion() {
        host.updateManager.checkIsLatestVersion(object : UpdateCallback {
            override fun onResult(e: Exception?) {
                if (e == null) channel.emit("isLatestVersion") else channel.emit("updateAvailable")
            }

            override fun onProgress(progress: Int) = Unit
        })
    }

    // ── Утилиты ───────────────────────────────────────────────────────────────

    private fun ok(payload: JSONObject = JSONObject()): String =
        payload.put("ok", true).toString()

    private fun fail(reason: String): String =
        JSONObject().put("ok", false).put("error", reason).toString()

    private inline fun safeString(fallback: String, block: () -> String): String = try {
        block()
    } catch (e: Exception) {
        Log.e(TAG, "bridge call failed", e)
        fallback
    }

    private inline fun safeBoolean(fallback: Boolean, block: () -> Boolean): Boolean = try {
        block()
    } catch (e: Exception) {
        Log.e(TAG, "bridge call failed", e)
        fallback
    }

    companion object {
        private const val TAG = "NativeBridge"

        /** Имя объекта в window для нового API. */
        const val JS_NAME = "AndroidBridge"

        /** Старое имя — оставляем, чтобы существующий UI продолжал работать. */
        const val JS_LEGACY_NAME = "Android"

        const val BRIDGE_VERSION = 2
    }
}
