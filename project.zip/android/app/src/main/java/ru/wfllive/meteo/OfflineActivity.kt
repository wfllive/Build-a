


package ru.wfllive.meteo

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import ru.wfllive.meteo.ui.theme.MeteoTheme

class OfflineActivity : AppCompatActivity() {

    private var statusText by mutableStateOf("Проверьте подключение")
    private var showRetryButton by mutableStateOf(true)
    private var showProgressBar by mutableStateOf(false)
    private var isCheckingConnection by mutableStateOf(false)

    private var autoCheckJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, true)

        setContent {
            MeteoTheme {                            // ← ОБЯЗАТЕЛЬНО обернуть в вашу тему!
                OfflineScreen()
                DisposableEffect(Unit) {
                    startAutoChecking()
                    onDispose {
                        autoCheckJob?.cancel()
                    }
                }
            }
        }
    }

    @Composable
    private fun OfflineIcon(
        modifier: Modifier = Modifier,
        tint: Color = Color(0xFF1565C0)
    ) {
        Canvas(modifier = modifier.size(120.dp)) {
            val strokeWidth = 12.dp.toPx()
            val centerX = size.width / 2
            val centerY = size.height / 2
            val radius = (size.minDimension - strokeWidth) / 2

            // Внешний круг (оборванный - показывает офлайн)
            val startAngle = 45f
            val sweepAngle = 270f

            drawArc(
                color = tint,
                startAngle = startAngle,
                sweepAngle = sweepAngle,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                topLeft = Offset(
                    centerX - radius,
                    centerY - radius
                ),
                size = androidx.compose.ui.geometry.Size(
                    radius * 2,
                    radius * 2
                )
            )

            // Левая дуга
            val leftArcRadius = radius * 0.6f
            val leftCenterX = centerX - radius * 0.5f
            val leftCenterY = centerY - radius * 0.7f

            drawArc(
                color = tint.copy(alpha = 0.3f),
                startAngle = 180f,
                sweepAngle = 120f,
                useCenter = false,
                style = Stroke(width = strokeWidth * 0.8f, cap = StrokeCap.Round),
                topLeft = Offset(
                    leftCenterX - leftArcRadius,
                    leftCenterY - leftArcRadius
                ),
                size = androidx.compose.ui.geometry.Size(
                    leftArcRadius * 2,
                    leftArcRadius * 2
                )
            )

            // Точки разрыва
            val dotRadius = strokeWidth * 0.4f
            val dotY = centerY - radius * 0.85f

            drawCircle(
                color = tint,
                radius = dotRadius,
                center = Offset(centerX - 15.dp.toPx(), dotY)
            )

            drawCircle(
                color = tint,
                radius = dotRadius,
                center = Offset(centerX + 15.dp.toPx(), dotY)
            )
        }
    }

    @Composable
    private fun OfflineScreen() {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)   // ← ИСПРАВЛЕНО: убрана лишняя )
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            OfflineIcon(
                tint = Color(0xFF2196F3)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Нет подключения к интернету",
                color = MaterialTheme.colorScheme.onBackground,     // ← ИСПРАВЛЕНО: вместо Color.White
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = statusText,
                color = MaterialTheme.colorScheme.onBackground,     // ← ИСПРАВЛЕНО
                fontSize = 16.sp
            )

            if (showRetryButton && !isCheckingConnection) {
                Spacer(modifier = Modifier.height(32.dp))

                Button(
                    onClick = { checkConnection() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1565C0),
                        contentColor = Color.White
                    )
                ) {
                    Text(text = "Повторить попытку")
                }
            }

            if (showProgressBar || isCheckingConnection) {
                Spacer(modifier = Modifier.height(32.dp))

                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }

    private fun startAutoChecking() {
        autoCheckJob?.cancel()
        autoCheckJob = lifecycleScope.launch {
            while (isActive && !isFinishing) {
                delay(5000)
                if (!isFinishing && !isDestroyed) {
                    checkConnection(auto = true)
                }
            }
        }
    }

    private fun checkConnection(auto: Boolean = false) {
        if (isCheckingConnection) return

        if (!auto) {
            statusText = "Проверяем соединение..."
            showRetryButton = false
            showProgressBar = true
        }

        isCheckingConnection = true

        lifecycleScope.launch {
            try {
                val isOnline = withContext(Dispatchers.IO) {
                    withTimeoutOrNull(5000) {
                        NetworkUtils.isNetworkAvailable(this@OfflineActivity)
                    } ?: false
                }

                if (isOnline) {
                    delay(1000)

                    if (isFinishing) return@launch

                    val stillOnline = withContext(Dispatchers.IO) {
                        withTimeoutOrNull(5000) {
                            NetworkUtils.isNetworkAvailable(this@OfflineActivity)
                        } ?: false
                    }

                    if (stillOnline) {
                        startActivity(
                            Intent(this@OfflineActivity, MainActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                        )
                        finish()
                        return@launch
                    }
                }

                if (!auto) {
                    statusText = "Соединение отсутствует"
                    showRetryButton = true
                    showProgressBar = false
                }
            } catch (e: CancellationException) {
                // Игнорируем отмену
            } catch (e: Exception) {
                if (!auto) {
                    statusText = "Ошибка проверки соединения"
                    showRetryButton = true
                    showProgressBar = false
                }
            } finally {
                isCheckingConnection = false
            }
        }
    }

    override fun onDestroy() {
        autoCheckJob?.cancel()
        super.onDestroy()
    }
}
