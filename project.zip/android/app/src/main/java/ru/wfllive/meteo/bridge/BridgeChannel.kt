package ru.wfllive.meteo.bridge

import android.app.Activity
import android.util.Log
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

/**
 * ЕДИНЫЙ канал «native → JS».
 *
 * Раньше события в веб уходили десятком мест через ручную склейку строк
 * ("window.onWebViewError('$code')"), что ломалось на кавычках/переносах строк
 * и было размазано по MainActivity и WebAppInterface.
 *
 * Теперь ЛЮБОЕ событие уходит через [emit]:
 *   1) в шину моста      -> window.__nativeBridgeEmit(name, detail)
 *   2) в window-событие  -> window.dispatchEvent(new CustomEvent(name, {detail}))
 *
 * Payload всегда сериализуется через org.json → экранирование корректное.
 */
class BridgeChannel(private val activity: Activity) {

    private var host: WebView? = null

    val isAttached: Boolean get() = host != null

    fun attach(webView: WebView) {
        host = webView
    }

    fun detach() {
        host = null
    }

    /**
     * Отправить событие в веб.
     *
     * @param event имя события, напр. [BridgeEvents.MAP]
     * @param payload JSONObject / JSONArray / String / Number / Boolean / null
     */
    fun emit(event: String, payload: Any? = null) {
        val detail = toJsLiteral(payload)
        val name = JSONObject.quote(event)

        val script = """
            (function () {
              var __d = $detail;
              try { if (typeof window.__nativeBridgeEmit === 'function') window.__nativeBridgeEmit($name, __d); } catch (e) {}
              try { window.dispatchEvent(new CustomEvent($name, { detail: __d })); } catch (e) {}
            })();
        """.trimIndent()

        evaluate(script)
    }

    /**
     * Legacy-совместимость: вызвать глобальную функцию, если она объявлена.
     * Используется для старых колбэков (window.onWebViewLoaded и т.п.).
     */
    fun callGlobal(fnName: String, vararg args: Any?) {
        val argList = args.joinToString(", ") { toJsLiteral(it) }
        val script = """
            (function () {
              try { if (typeof window.$fnName === 'function') window.$fnName($argList); } catch (e) {}
            })();
        """.trimIndent()
        evaluate(script)
    }

    /** Выполнить JS и получить результат (нужно для диагностики белого экрана). */
    fun evaluateForResult(script: String, onResult: (String?) -> Unit) {
        val webView = host ?: return
        activity.runOnUiThread {
            try {
                webView.evaluateJavascript(script) { value -> onResult(value) }
            } catch (e: Exception) {
                Log.e(TAG, "evaluateJavascript failed", e)
            }
        }
    }

    fun evaluate(script: String) {
        val webView = host ?: return
        activity.runOnUiThread {
            try {
                webView.evaluateJavascript(script, null)
            } catch (e: Exception) {
                Log.e(TAG, "evaluateJavascript failed", e)
            }
        }
    }

    private fun toJsLiteral(value: Any?): String = when (value) {
        null -> "null"
        is JSONObject -> value.toString()
        is JSONArray -> value.toString()
        is Boolean -> value.toString()
        is Number -> value.toString()
        is String -> JSONObject.quote(value)
        else -> JSONObject.quote(value.toString())
    }

    companion object {
        private const val TAG = "BridgeChannel"
    }
}

/** Имена событий native → JS. Дублируются в JS: src/native/bridge/events.js */
object BridgeEvents {
    /** Безопасные отступы системы (status bar / navigation bar / вырез / клавиатура). */
    const val INSETS = "native:insets"

    /** Состояние нативной карты: loading | loaded | error | offline | released. */
    const val MAP = "native:map"

    /** Тема изменилась. */
    const val THEME = "native:theme"

    /** Пришли координаты. */
    const val LOCATION = "native:location"

    /** Результат запроса разрешения на геолокацию. */
    const val LOCATION_PERMISSION = "native:locationPermission"

    /** Мост готов (native подключился к WebView). */
    const val READY = "native:ready"

    // ── Legacy-события (оставлены ради обратной совместимости UI) ─────────────
    const val LEGACY_THEME = "androidThemeChanged"
    const val LEGACY_LOCATION = "androidLocationUpdate"
    const val LEGACY_LOCATION_PERMISSION = "androidLocationPermissionResult"
    const val LEGACY_AD_FREE = "adFreeStateChanged"
    const val LEGACY_REWARDED = "rewardedAdStateChanged"
}
