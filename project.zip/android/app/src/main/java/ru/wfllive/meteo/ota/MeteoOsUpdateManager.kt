package ru.wfllive.meteo.ota

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.util.Base64
import android.util.Log
import org.json.JSONObject
import ru.wfllive.meteo.BuildConfig
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.PublicKey
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

/**
 * Meteo OS — система OTA-обновлений ВЕБ-БАНДЛА (React-интерфейса).
 *
 * Идея: APK несёт «заводскую» версию интерфейса в assets/dist. Поверх неё
 * можно доставлять новые версии без публикации в магазине:
 *
 *   1. `checkForUpdates()`  — качаем манифест meteo-os.json с GitHub;
 *   2. `downloadUpdate()`   — качаем zip, проверяем SHA-256 и RSA-подпись,
 *                             распаковываем в files/meteo-os/versions/<v>/;
 *   3. `applyPendingUpdate()` — активируем версию, WebView перезагружается
 *                             с file:///data/.../index.html;
 *   4. веб после успешного старта зовёт `reportHealthy()` — версия
 *                             закрепляется как «последняя рабочая»;
 *   5. если подтверждения не было (белый экран / краш JS) — авто-откат на
 *                             последнюю рабочую или на встроенную в APK.
 *
 * Обновления APK (RuStore / Google Play / universal) этим классом НЕ
 * затрагиваются — они по-прежнему живут в StoreUpdateManager.
 *
 * Защита:
 *   • SHA-256 архива обязан совпасть с манифестом;
 *   • если в assets лежит meteo_os_public.pem — манифест обязан быть подписан
 *     (SHA256withRSA по строке "version\nsha256\nsize"), иначе обновление
 *     отклоняется;
 *   • zip-slip guard при распаковке + лимит размера;
 *   • `minVersionCode` в манифесте отсекает слишком старые APK.
 *
 * JS-зеркало: src/native/bridge/androidBridge.js (раздел meteoOs)
 * Документация: docs/meteo-os-updates.md
 */
class MeteoOsUpdateManager(
    private val context: Context,
    /** URL встроенного бандла: file:///android_asset/dist/index.html */
    private val builtinUrl: String,
) {

    // ── Модель манифеста ──────────────────────────────────────────────────────

    data class RemoteManifest(
        val version: String,
        val url: String,
        val sha256: String,
        val size: Long,
        val minVersionCode: Long,
        val notes: String,
        val signature: String?,
    ) {
        fun toJson(): JSONObject = JSONObject()
            .put("version", version)
            .put("url", url)
            .put("sha256", sha256)
            .put("size", size)
            .put("minVersionCode", minVersionCode)
            .put("notes", notes)
            .put("signature", signature ?: "")

        companion object {
            fun fromJson(o: JSONObject): RemoteManifest = RemoteManifest(
                version = o.optString("version").trim(),
                url = o.optString("url").trim(),
                sha256 = o.optString("sha256").trim().lowercase(),
                size = o.optLong("size", -1L),
                minVersionCode = o.optLong("minVersionCode", 0L),
                notes = o.optString("notes", ""),
                signature = o.optString("signature", "").ifEmpty { null },
            )
        }
    }

    sealed class CheckResult {
        data class Available(val manifest: RemoteManifest) : CheckResult()

        /**
         * Обновление Meteo OS существует, но требует более новый APK
         * (manifest.minVersionCode > versionCode установленного приложения).
         * UI в этом случае НЕ качает бандл, а рекомендует обновить
         * основное приложение через магазин.
         */
        data class RequiresAppUpdate(val manifest: RemoteManifest) : CheckResult()

        object UpToDate : CheckResult()
        data class Failure(val message: String) : CheckResult()
    }

    // ── Состояние ─────────────────────────────────────────────────────────────

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val executor: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread(r, "MeteoOsUpdate").apply { isDaemon = true }
    }

    private val rootDir: File get() = File(context.filesDir, "meteo-os")
    private val versionsRoot: File get() = File(rootDir, "versions")

    @Volatile
    private var lastManifest: RemoteManifest? = null

    // ── Публичное API ─────────────────────────────────────────────────────────

    /** Текущая версия интерфейса (активная OTA или встроенная в APK). */
    fun currentVersion(): String =
        prefs.getString(KEY_ACTIVE, null) ?: BuildConfig.METEO_OS_VERSION

    fun isTrialActive(): Boolean = prefs.getBoolean(KEY_TRIAL, false)

    /** Принадлежит ли URL каталогу OTA-версий (для isAppEntryUrl). */
    fun isOtaUrl(url: String): Boolean =
        url.startsWith("file://${versionsRoot.absolutePath}")

    /** Полное состояние для UI. */
    fun getStateJson(): JSONObject {
        val active = prefs.getString(KEY_ACTIVE, null)
        return JSONObject()
            .put("builtinVersion", BuildConfig.METEO_OS_VERSION)
            .put("activeVersion", active ?: JSONObject.NULL)
            .put("currentVersion", currentVersion())
            .put("source", if (active != null) "ota" else "builtin")
            .put("pendingVersion", prefs.getString(KEY_PENDING, null) ?: JSONObject.NULL)
            .put("lastGoodVersion", prefs.getString(KEY_LAST_GOOD, null) ?: JSONObject.NULL)
            .put("availableVersion", lastManifest?.version ?: JSONObject.NULL)
            .put("trialActive", isTrialActive())
            .put("lastError", prefs.getString(KEY_LAST_ERROR, null) ?: JSONObject.NULL)
            .put("manifestUrl", BuildConfig.METEO_OS_MANIFEST_URL)
    }

    /**
     * URL, с которого надо стартовать WebView.
     *
     * Если прошлый запуск применил OTA-версию, но она так и не подтвердила
     * работоспособность (`reportHealthy`) — откатываемся ПРЯМО ЗДЕСЬ,
     * до загрузки страницы. Так сломанный бандл не может «закирпичить»
     * приложение: максимум один неудачный старт.
     */
    fun resolveStartUrl(): String {
        if (isTrialActive()) {
            Log.e(TAG, "Предыдущий запуск Meteo OS не подтвердился — выполняю откат")
            return rollbackAfterFailure()
        }
        val active = prefs.getString(KEY_ACTIVE, null) ?: return builtinUrl
        val index = File(versionDir(active), "index.html")
        if (!index.isFile) {
            Log.e(TAG, "Файлы версии $active повреждены — возврат на встроенную")
            prefs.edit().remove(KEY_ACTIVE).apply()
            return builtinUrl
        }
        return "file://${index.absolutePath}"
    }

    /** Проверка обновлений (сеть — в фоновом потоке). */
    fun checkForUpdates(onResult: (CheckResult) -> Unit) {
        executor.execute {
            val result = try {
                doCheck()
            } catch (e: Exception) {
                Log.e(TAG, "Проверка обновлений Meteo OS упала", e)
                CheckResult.Failure(e.message ?: "Не удалось проверить обновления")
            }
            if (result is CheckResult.Failure) setLastError(result.message)
            onResult(result)
        }
    }

    /**
     * Скачать и подготовить обновление (после успешного checkForUpdates).
     * По завершении версия лежит распакованной и помечена как pending —
     * применение отдельным шагом, по кнопке пользователя.
     */
    fun downloadUpdate(onProgress: (Int) -> Unit, onDone: (String?) -> Unit) {
        executor.execute {
            try {
                val manifest = lastManifest ?: loadSavedManifest()
                    ?: throw IOException("Сначала выполните проверку обновлений")

                verifySignature(manifest)

                val tmp = File(rootDir.apply { mkdirs() }, "download.tmp")
                try {
                    downloadWithDigest(manifest, tmp, onProgress)
                    installZip(manifest, tmp)
                } finally {
                    tmp.delete()
                }

                prefs.edit().putString(KEY_PENDING, manifest.version).apply()
                setLastError(null)
                Log.i(TAG, "Meteo OS ${manifest.version} скачана и проверена")
                onDone(null)
            } catch (e: Exception) {
                Log.e(TAG, "Загрузка обновления Meteo OS упала", e)
                val message = e.message ?: "Не удалось загрузить обновление"
                setLastError(message)
                onDone(message)
            }
        }
    }

    /**
     * Применить скачанное обновление.
     * @return URL новой версии для перезагрузки WebView или null при ошибке.
     */
    fun applyPendingUpdate(): String? {
        val pending = prefs.getString(KEY_PENDING, null) ?: run {
            setLastError("Нет загруженного обновления")
            return null
        }
        val index = File(versionDir(pending), "index.html")
        if (!index.isFile) {
            prefs.edit().remove(KEY_PENDING).apply()
            setLastError("Файлы обновления повреждены — скачайте заново")
            return null
        }
        prefs.edit()
            .putString(KEY_ACTIVE, pending)
            .remove(KEY_PENDING)
            .putBoolean(KEY_TRIAL, true) // ждём подтверждения от веба
            .apply()
        Log.i(TAG, "Meteo OS $pending активирована (ожидает подтверждения)")
        return "file://${index.absolutePath}"
    }

    /**
     * Веб успешно стартовал — закрепляем активную версию как рабочую.
     * Зовётся из JS: AndroidBridge.meteoOs.reportHealthy().
     */
    fun reportHealthy() {
        val wasTrial = isTrialActive()
        val active = prefs.getString(KEY_ACTIVE, null)
        val editor = prefs.edit().putBoolean(KEY_TRIAL, false)
        if (active != null) editor.putString(KEY_LAST_GOOD, active)
        editor.apply()
        if (wasTrial) Log.i(TAG, "Meteo OS ${active ?: "builtin"} подтвердила работоспособность")
        executor.execute { pruneOldVersions() }
    }

    /**
     * Авто-откат: активная версия не подтвердила запуск.
     * Возврат на последнюю рабочую OTA-версию, иначе — на встроенную.
     * @return URL, который надо загрузить в WebView.
     */
    fun rollbackAfterFailure(): String {
        val failed = prefs.getString(KEY_ACTIVE, null)
        val lastGood = prefs.getString(KEY_LAST_GOOD, null)

        val target = lastGood?.takeIf {
            it != failed && File(versionDir(it), "index.html").isFile
        }

        val editor = prefs.edit()
            .putBoolean(KEY_TRIAL, false)
            .putString(
                KEY_LAST_ERROR,
                "Версия ${failed ?: "?"} не запустилась — выполнен автоматический откат"
            )
        if (target != null) editor.putString(KEY_ACTIVE, target) else editor.remove(KEY_ACTIVE)
        editor.apply()

        // Сломанную версию удаляем, чтобы не предлагать её повторно.
        failed?.let { versionDir(it).deleteRecursively() }

        return if (target != null) {
            Log.e(TAG, "Откат Meteo OS: $failed → $target")
            "file://${File(versionDir(target), "index.html").absolutePath}"
        } else {
            Log.e(TAG, "Откат Meteo OS: $failed → встроенная версия")
            builtinUrl
        }
    }

    /**
     * Ручной сброс до встроенной в APK версии (кнопка в диалоге обновлений).
     * @return URL встроенного бандла.
     */
    fun resetToBuiltin(): String {
        prefs.edit()
            .remove(KEY_ACTIVE)
            .remove(KEY_PENDING)
            .remove(KEY_LAST_GOOD)
            .remove(KEY_LAST_ERROR)
            .putBoolean(KEY_TRIAL, false)
            .apply()
        executor.execute { versionsRoot.deleteRecursively() }
        Log.i(TAG, "Meteo OS сброшена до встроенной версии ${BuildConfig.METEO_OS_VERSION}")
        return builtinUrl
    }

    // ── Проверка обновлений ───────────────────────────────────────────────────

    private fun doCheck(): CheckResult {
        val raw = httpGetText(BuildConfig.METEO_OS_MANIFEST_URL)
        val manifest = RemoteManifest.fromJson(JSONObject(raw))

        if (manifest.version.isBlank() || manifest.url.isBlank() || manifest.sha256.length != 64) {
            return CheckResult.Failure("Манифест обновления некорректен")
        }
        if (!manifest.url.startsWith("https://")) {
            return CheckResult.Failure("Манифест указывает на небезопасный URL")
        }
        if (!isNewer(manifest.version, currentVersion())) {
            return CheckResult.UpToDate
        }
        if (manifest.minVersionCode > appVersionCode()) {
            // Новая Meteo OS есть, но текущий APK слишком старый: не качаем,
            // а сообщаем UI — тот порекомендует обновить основное приложение.
            return CheckResult.RequiresAppUpdate(manifest)
        }

        lastManifest = manifest
        prefs.edit().putString(KEY_LAST_MANIFEST, manifest.toJson().toString()).apply()
        return CheckResult.Available(manifest)
    }

    private fun loadSavedManifest(): RemoteManifest? = try {
        prefs.getString(KEY_LAST_MANIFEST, null)
            ?.let { RemoteManifest.fromJson(JSONObject(it)) }
            ?.also { lastManifest = it }
    } catch (e: Exception) {
        null
    }

    // ── Загрузка и проверка целостности ───────────────────────────────────────

    private fun downloadWithDigest(manifest: RemoteManifest, target: File, onProgress: (Int) -> Unit) {
        val connection = openConnection(manifest.url)
        try {
            if (connection.responseCode !in 200..299) {
                throw IOException("Сервер обновлений ответил ${connection.responseCode}")
            }

            val total = if (manifest.size > 0) manifest.size else connection.contentLengthLong
            if (total > MAX_BUNDLE_BYTES) throw IOException("Обновление слишком большое")

            val digest = MessageDigest.getInstance("SHA-256")
            var received = 0L
            var lastPercent = -1

            connection.inputStream.use { input ->
                FileOutputStream(target).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        received += read
                        if (received > MAX_BUNDLE_BYTES) {
                            throw IOException("Обновление превысило допустимый размер")
                        }
                        digest.update(buffer, 0, read)
                        output.write(buffer, 0, read)

                        if (total > 0) {
                            val percent = ((received * 100) / total).toInt().coerceIn(0, 100)
                            if (percent != lastPercent) {
                                lastPercent = percent
                                onProgress(percent)
                            }
                        }
                    }
                }
            }

            if (manifest.size > 0 && received != manifest.size) {
                throw IOException("Размер файла не совпадает с манифестом")
            }
            val actual = digest.digest().joinToString("") { "%02x".format(it) }
            if (actual != manifest.sha256) {
                throw IOException("Контрольная сумма SHA-256 не совпадает — файл повреждён или подменён")
            }
            onProgress(100)
        } finally {
            connection.disconnect()
        }
    }

    /**
     * Проверка RSA-подписи манифеста.
     *
     * Подписывается каноничная строка "version\nsha256\nsize" приватным ключом
     * издателя (scripts/meteo-os/pack.mjs). Публичный ключ вшит в APK:
     * assets/meteo_os_public.pem. Если ключа в APK нет (ещё не сгенерирован) —
     * пишем предупреждение и ограничиваемся SHA-256.
     */
    private fun verifySignature(manifest: RemoteManifest) {
        val publicKey = loadPublicKey()
        if (publicKey == null) {
            Log.w(TAG, "meteo_os_public.pem не найден в assets — проверка подписи пропущена")
            return
        }
        val signature = manifest.signature
            ?: throw SecurityException("Обновление не подписано — отклонено")

        val payload = "${manifest.version}\n${manifest.sha256}\n${manifest.size}"
        val verifier = Signature.getInstance("SHA256withRSA")
        verifier.initVerify(publicKey)
        verifier.update(payload.toByteArray(Charsets.UTF_8))

        val valid = try {
            verifier.verify(Base64.decode(signature, Base64.DEFAULT))
        } catch (e: Exception) {
            false
        }
        if (!valid) throw SecurityException("Подпись обновления недействительна — отклонено")
    }

    private fun loadPublicKey(): PublicKey? = try {
        val pem = context.assets.open(PUBLIC_KEY_ASSET).bufferedReader().use { it.readText() }
        val body = pem
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .replace(Regex("\\s"), "")
        val bytes = Base64.decode(body, Base64.DEFAULT)
        KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(bytes))
    } catch (e: IOException) {
        null // файла нет — допустимо
    } catch (e: Exception) {
        Log.e(TAG, "Не удалось разобрать meteo_os_public.pem", e)
        null
    }

    // ── Распаковка ────────────────────────────────────────────────────────────

    private fun installZip(manifest: RemoteManifest, zip: File) {
        val staging = File(versionsRoot.apply { mkdirs() }, "${manifest.version}.tmp")
        staging.deleteRecursively()
        staging.mkdirs()

        val stagingPath = staging.canonicalPath + File.separator
        var entries = 0
        var totalBytes = 0L

        ZipInputStream(zip.inputStream().buffered()).use { input ->
            while (true) {
                val entry = input.nextEntry ?: break
                entries++
                if (entries > MAX_ZIP_ENTRIES) throw IOException("Слишком много файлов в архиве")

                val out = File(staging, entry.name)
                // Zip-slip guard: файл обязан остаться внутри staging.
                if (!out.canonicalPath.startsWith(stagingPath) && out.canonicalPath != staging.canonicalPath) {
                    throw SecurityException("Архив содержит недопустимый путь: ${entry.name}")
                }

                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read < 0) break
                            totalBytes += read
                            if (totalBytes > MAX_UNPACKED_BYTES) {
                                throw IOException("Распакованный размер превысил лимит")
                            }
                            output.write(buffer, 0, read)
                        }
                    }
                }
                input.closeEntry()
            }
        }

        if (!File(staging, "index.html").isFile) {
            staging.deleteRecursively()
            throw IOException("В обновлении нет index.html — архив некорректен")
        }

        val target = versionDir(manifest.version)
        target.deleteRecursively()
        if (!staging.renameTo(target)) {
            staging.deleteRecursively()
            throw IOException("Не удалось установить файлы обновления")
        }
    }

    /** Оставляем на диске только активную, последнюю рабочую и pending-версии. */
    private fun pruneOldVersions() {
        val keep = setOfNotNull(
            prefs.getString(KEY_ACTIVE, null),
            prefs.getString(KEY_LAST_GOOD, null),
            prefs.getString(KEY_PENDING, null),
        )
        versionsRoot.listFiles()?.forEach { dir ->
            if (dir.isDirectory && dir.name !in keep && !dir.name.endsWith(".tmp")) {
                dir.deleteRecursively()
            }
        }
    }

    // ── Утилиты ───────────────────────────────────────────────────────────────

    private fun versionDir(version: String): File =
        File(versionsRoot, version.replace(Regex("[^A-Za-z0-9._-]"), "_"))

    private fun setLastError(message: String?) {
        prefs.edit().apply {
            if (message == null) remove(KEY_LAST_ERROR) else putString(KEY_LAST_ERROR, message)
        }.apply()
    }

    private fun appVersionCode(): Long {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            info.versionCode.toLong()
        }
    }

    private fun openConnection(url: String): HttpURLConnection {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = NETWORK_TIMEOUT_MS
        connection.readTimeout = NETWORK_TIMEOUT_MS
        connection.instanceFollowRedirects = true
        connection.setRequestProperty("User-Agent", "MeteoLive/${BuildConfig.VERSION_NAME}")
        connection.setRequestProperty("Cache-Control", "no-cache")
        return connection
    }

    private fun httpGetText(url: String): String {
        val connection = openConnection(url)
        try {
            if (connection.responseCode !in 200..299) {
                throw IOException("Сервер обновлений ответил ${connection.responseCode}")
            }
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    /** Сравнение версий по числовым сегментам: "9.0.10" новее "9.0.9". */
    private fun isNewer(candidate: String, current: String): Boolean {
        val a = versionParts(candidate)
        val b = versionParts(current)
        val length = maxOf(a.size, b.size)
        for (i in 0 until length) {
            val x = a.getOrElse(i) { 0L }
            val y = b.getOrElse(i) { 0L }
            if (x != y) return x > y
        }
        return false
    }

    private fun versionParts(version: String): List<Long> =
        Regex("\\d+").findAll(version).map { it.value.toLongOrNull() ?: 0L }.toList()

    companion object {
        private const val TAG = "MeteoOsUpdate"

        private const val PREFS_NAME = "meteo_os_prefs"
        private const val KEY_ACTIVE = "active_version"
        private const val KEY_PENDING = "pending_version"
        private const val KEY_LAST_GOOD = "last_good_version"
        private const val KEY_TRIAL = "trial_active"
        private const val KEY_LAST_ERROR = "last_error"
        private const val KEY_LAST_MANIFEST = "last_manifest"

        private const val PUBLIC_KEY_ASSET = "meteo_os_public.pem"

        private const val NETWORK_TIMEOUT_MS = 15_000
        private const val MAX_BUNDLE_BYTES = 200L * 1024 * 1024
        private const val MAX_UNPACKED_BYTES = 400L * 1024 * 1024
        private const val MAX_ZIP_ENTRIES = 5_000
    }
}
