package ru.wfllive.meteo.bridge

import android.webkit.JavascriptInterface
import org.json.JSONObject

/**
 * Мост темы: window.AndroidTheme
 *
 * Существующий UI (SettingsPanel.jsx, useWeatherUI.jsx) ожидает три метода:
 * setTheme / getCurrentTheme / getSystemTheme. Последнего раньше не было —
 * из-за этого «системная тема» в настройках не определялась.
 */
class ThemeBridge(
    private val host: BridgeHost,
    private val channel: BridgeChannel
) {

    /** "light" | "dark" | "auto" */
    @JavascriptInterface
    fun setTheme(theme: String?) {
        val value = normalize(theme)
        host.hostActivity.runOnUiThread {
            host.applyThemePreference(value)
            notifyTheme(value)
        }
    }

    @JavascriptInterface
    fun getCurrentTheme(): String = host.currentThemePreference()

    /** Реальная тема системы прямо сейчас: "dark" | "light". */
    @JavascriptInterface
    fun getSystemTheme(): String = if (host.isDarkThemeNow()) "dark" else "light"

    @JavascriptInterface
    fun isDarkMode(): Boolean = host.isDarkThemeNow()

    /**
     * Отправить текущее состояние темы в веб.
     * (Имя не `notify` — оно занято final-методом java.lang.Object.)
     */
    fun notifyTheme(preference: String = host.currentThemePreference()) {
        val isDark = host.isDarkThemeNow()

        channel.emit(
            BridgeEvents.THEME,
            JSONObject()
                .put("theme", preference)
                .put("isDark", isDark)
        )

        // Legacy: useWeatherUI слушает 'androidThemeChanged' с detail = Boolean
        channel.emit(BridgeEvents.LEGACY_THEME, isDark)
        channel.callGlobal("receiveAndroidTheme", preference)
        channel.callGlobal("onThemeChangeComplete", preference)
    }

    private fun normalize(theme: String?): String = when (theme?.lowercase()) {
        "light" -> "light"
        "dark" -> "dark"
        else -> "auto"
    }

    companion object {
        const val JS_NAME = "AndroidTheme"
    }
}

/**
 * Мост конфигурации: window.AndroidApi
 * Отдаёт вебу ключи/настройки, которые не должны лежать в JS-бандле.
 */
class ApiBridge(private val apiKey: String) {

    @JavascriptInterface
    fun getApiKey(): String = apiKey

    companion object {
        const val JS_NAME = "AndroidApi"
    }
}
