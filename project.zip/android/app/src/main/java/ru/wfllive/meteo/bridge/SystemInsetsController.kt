package ru.wfllive.meteo.bridge

import android.app.Activity
import android.os.Build
import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import kotlin.math.roundToInt

/**
 * Снимок системных отступов в px устройства.
 *
 * [tappableBottom] — ключ к «хитрости» с навбаром:
 *   • жестовая навигация  → tappableBottom == 0  (полоска-«пилюля» ничего не перекрывает,
 *                            можно рисовать контент до самого низа экрана);
 *   • 3 кнопки            → tappableBottom > 0   (там реальные кнопки — залезать НЕЛЬЗЯ).
 */
data class SystemInsets(
    val top: Int = 0,
    val bottom: Int = 0,
    val left: Int = 0,
    val right: Int = 0,
    val tappableBottom: Int = 0,
    val tappableLeft: Int = 0,
    val tappableRight: Int = 0,
    val imeBottom: Int = 0,
    val cutoutTop: Int = 0,
    val cutoutBottom: Int = 0,
    val navigationMode: String = NAV_UNKNOWN,
    val density: Float = 1f,
    val isLandscape: Boolean = false
) {

    val keyboardVisible: Boolean get() = imeBottom > 0

    private fun css(value: Int): Double {
        if (density <= 0f) return value.toDouble()
        return ((value / density) * 100).roundToInt() / 100.0
    }

    fun toJson(): JSONObject {
        val px = JSONObject()
            .put("top", top)
            .put("bottom", bottom)
            .put("left", left)
            .put("right", right)
            .put("tappableBottom", tappableBottom)
            .put("tappableLeft", tappableLeft)
            .put("tappableRight", tappableRight)
            .put("imeBottom", imeBottom)
            .put("cutoutTop", cutoutTop)
            .put("cutoutBottom", cutoutBottom)

        val cssJson = JSONObject()
            .put("top", css(top))
            .put("bottom", css(bottom))
            .put("left", css(left))
            .put("right", css(right))
            .put("tappableBottom", css(tappableBottom))
            .put("tappableLeft", css(tappableLeft))
            .put("tappableRight", css(tappableRight))
            .put("imeBottom", css(imeBottom))
            .put("cutoutTop", css(cutoutTop))
            .put("cutoutBottom", css(cutoutBottom))

        return JSONObject()
            .put("px", px)
            .put("css", cssJson)
            .put("density", density.toDouble())
            .put("navigationMode", navigationMode)
            .put("isLandscape", isLandscape)
            .put("keyboardVisible", keyboardVisible)
            .put("edgeToEdge", true)
    }

    companion object {
        const val NAV_GESTURE = "gesture"
        const val NAV_BUTTONS = "buttons"
        const val NAV_NONE = "none"
        const val NAV_UNKNOWN = "unknown"
    }
}

/**
 * Читает системные отступы и раздаёт их:
 *   • в веб (событие [BridgeEvents.INSETS] + метод AndroidBridge.getInsets());
 *   • в native (карта пересчитывает свою геометрию мгновенно, не дожидаясь JS).
 *
 * Здесь же включается edge-to-edge: окно рисуется под системными барами,
 * а веб сам добавляет паддинги через CSS-переменные (--safe-area-*).
 * Это единственный способ сделать «адекватно» на Android 15+ (targetSdk 35+),
 * где edge-to-edge включён принудительно.
 */
class SystemInsetsController(
    private val activity: Activity,
    private val channel: BridgeChannel
) {

    @Volatile
    var current: SystemInsets = SystemInsets()
        private set

    private var onChanged: ((SystemInsets) -> Unit)? = null
    private var anchor: View? = null

    /** Не шлём в веб одно и то же по десять раз подряд. */
    private var lastEmitted: String? = null

    /** Окно рисует контент под системными барами. Бары остаются прозрачными. */
    @Suppress("DEPRECATION")
    fun enableEdgeToEdge() {
        WindowCompat.setDecorFitsSystemWindows(activity.window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            activity.window.attributes = activity.window.attributes.apply {
                layoutInDisplayCutoutMode =
                    android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT < 35) {
            activity.window.statusBarColor = android.graphics.Color.TRANSPARENT
            activity.window.navigationBarColor = android.graphics.Color.TRANSPARENT
        }
    }

    /**
     * Подписаться на изменения отступов.
     *
     * ВАЖНО: слушатель вешается на НАШУ view (контейнер карты), а значения
     * читаются из [ViewCompat.getRootWindowInsets] — то есть всегда полные,
     * непотреблённые оконные отступы. Так мы не ломаем раздачу insets в Compose
     * (если повесить слушатель на decorView, дочерние view их уже не увидят)
     * и при этом получаем честные значения.
     *
     * Возвращаем insets неизменёнными — дочерние view тоже должны их увидеть.
     */
    fun attach(view: View, onChanged: (SystemInsets) -> Unit) {
        this.onChanged = onChanged
        this.anchor = view

        ViewCompat.setOnApplyWindowInsetsListener(view) { v, windowInsets ->
            publish(read(ViewCompat.getRootWindowInsets(v) ?: windowInsets))
            windowInsets
        }
        ViewCompat.requestApplyInsets(view)
        refresh()
    }

    fun detach(view: View) {
        ViewCompat.setOnApplyWindowInsetsListener(view, null)
        onChanged = null
        anchor = null
    }

    /** Перечитать отступы (например, после поворота экрана). */
    fun refresh() {
        val view = anchor ?: return
        val insets = ViewCompat.getRootWindowInsets(view) ?: return
        publish(read(insets))
    }

    /** Повторно отправить текущее состояние (например, после загрузки страницы). */
    fun resend() {
        val json = current.toJson()
        lastEmitted = json.toString()
        channel.emit(BridgeEvents.INSETS, json)
    }

    fun currentJson(): String = current.toJson().toString()

    private fun publish(insets: SystemInsets) {
        val changed = insets != current
        current = insets
        if (changed) onChanged?.invoke(insets)

        val json = insets.toJson().toString()
        if (json != lastEmitted) {
            lastEmitted = json
            channel.emit(BridgeEvents.INSETS, insets.toJson())
        }
    }

    private fun read(windowInsets: WindowInsetsCompat): SystemInsets {
        val bars = windowInsets.getInsets(
            WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
        )
        val tappable = windowInsets.getInsets(WindowInsetsCompat.Type.tappableElement())
        val navBars = windowInsets.getInsets(WindowInsetsCompat.Type.navigationBars())
        val ime = windowInsets.getInsets(WindowInsetsCompat.Type.ime())
        val cutout = windowInsets.displayCutout

        val metrics = activity.resources.displayMetrics
        val density = if (metrics.density > 0f) metrics.density else 1f
        val configuration = activity.resources.configuration
        val isLandscape =
            configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

        // Порог: «жестовая» полоса обычно <= 24dp, кнопочная панель заметно выше.
        val gestureThresholdPx = (GESTURE_NAV_MAX_DP * density).roundToInt()

        val navigationMode = when {
            navBars.bottom == 0 && navBars.left == 0 && navBars.right == 0 ->
                SystemInsets.NAV_NONE

            tappable.bottom == 0 && tappable.left == 0 && tappable.right == 0 ->
                SystemInsets.NAV_GESTURE

            navBars.bottom in 1..gestureThresholdPx && navBars.left == 0 && navBars.right == 0 ->
                SystemInsets.NAV_GESTURE

            else -> SystemInsets.NAV_BUTTONS
        }

        return SystemInsets(
            top = bars.top,
            bottom = bars.bottom,
            left = bars.left,
            right = bars.right,
            tappableBottom = tappable.bottom,
            tappableLeft = tappable.left,
            tappableRight = tappable.right,
            imeBottom = ime.bottom,
            cutoutTop = cutout?.safeInsetTop ?: 0,
            cutoutBottom = cutout?.safeInsetBottom ?: 0,
            navigationMode = navigationMode,
            density = density,
            isLandscape = isLandscape
        )
    }

    companion object {
        private const val GESTURE_NAV_MAX_DP = 28f
    }
}
