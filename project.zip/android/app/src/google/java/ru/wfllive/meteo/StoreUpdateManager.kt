/*package ru.wfllive.meteo

import android.app.Activity
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability

import android.widget.Toast

class StoreUpdateManager(private val activity: Activity) : StoreUpdateInterface {

    private val appUpdateManager = AppUpdateManagerFactory.create(activity)
    private var listener: InstallStateUpdatedListener? = null
    private var internalCallback: UpdateCallback? = null
    private var _isDownloading = false
    private var _isDownloaded = false

    init {
        setupListener()
    }

    private fun setupListener() {
        listener = InstallStateUpdatedListener { state ->
            when (state.installStatus()) {
                InstallStatus.DOWNLOADING -> {
                    _isDownloading = true
                    val bytesDownloaded = state.bytesDownloaded()
                    val totalBytes = state.totalBytesToDownload()
                    val progress = if (totalBytes > 0L) ((bytesDownloaded * 100) / totalBytes).toInt() else 0
                    activity.runOnUiThread { internalCallback?.onProgress(progress) }
                }
                InstallStatus.DOWNLOADED -> {
                    _isDownloading = false
                    _isDownloaded = true
                    activity.runOnUiThread { internalCallback?.onResult(null) }
                }
                InstallStatus.FAILED -> {
                    _isDownloading = false
                    activity.runOnUiThread { internalCallback?.onResult(Exception("Google Update Failed")) }
                }
                else -> Unit
            }
        }
    }

   /* override fun checkForUpdates(callback: UpdateCallback) {
        appUpdateManager.appUpdateInfo.addOnSuccessListener { info ->
            if (info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE) {
                callback.onResult(Exception("Update Available"))
            } else {
                callback.onResult(Exception("No update"))
            }
        }.addOnFailureListener {
            callback.onResult(Exception("Check failed", it))
        }
    }*/
    
        override fun checkForUpdates(callback: UpdateCallback) {
        appUpdateManager.appUpdateInfo.addOnSuccessListener { info ->
            if (info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE) {
                callback.onResult(Exception("Update Available"))
            } else {
                callback.onResult(Exception("No update"))
            }
        }.addOnFailureListener { e ->
            
            // ==================================================================
            // НАЧАЛО БЛОКА ОТЛАДКИ (ЗАКОММЕНТИРОВАТЬ ПЕРЕД РЕЛИЗОМ)
            // ==================================================================
            activity.runOnUiThread {
                val sb = StringBuilder("Google Update Error:\n")
                sb.append(e.message)
                
                if (e is com.google.android.play.core.install.InstallException) {
                    sb.append("\nError Code: ${e.errorCode}")
                    if (e.errorCode == -100) {
                        sb.append("\n(App not owned/installed from Play Store)")
                    }
                }
                
                android.widget.Toast.makeText(activity, sb.toString(), android.widget.Toast.LENGTH_LONG).show()
            }
            // ==================================================================
            // КОНЕЦ БЛОКА ОТЛАДКИ
            // ==================================================================

            // Логи в Logcat
            android.util.Log.e("StoreUpdateManager", "Google Update Check Failed", e)
            if (e is com.google.android.play.core.install.InstallException) {
                android.util.Log.e("StoreUpdateManager", "Error Code: ${e.errorCode}")
            }
            
            callback.onResult(Exception("Check failed: ${e.message}", e))
        }
    }
    

    override fun startFlexibleUpdate(callback: UpdateCallback) {
        internalCallback = callback
        appUpdateManager.appUpdateInfo.addOnSuccessListener { info ->
            if (info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                info.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)) {
                
                listener?.let { appUpdateManager.registerListener(it) }
                
                appUpdateManager.startUpdateFlow(
                    info,
                    activity,
                    AppUpdateOptions.defaultOptions(AppUpdateType.FLEXIBLE)
                )
            }
        }.addOnFailureListener { e ->
            callback.onResult(Exception(e))
        }
    }

    override fun startImmediateUpdate(activity: Activity, callback: UpdateCallback) {
        appUpdateManager.appUpdateInfo.addOnSuccessListener { info ->
            if (info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                info.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                
                appUpdateManager.startUpdateFlow(
                    info,
                    activity,
                    AppUpdateOptions.defaultOptions(AppUpdateType.IMMEDIATE)
                )
                // Callback тут условный, так как UI перехватывает Google
                callback.onResult(null)
            }
        }.addOnFailureListener { e ->
            callback.onResult(Exception(e))
        }
    }
    
    // РЕАЛИЗАЦИЯ ИЗ ДОКУМЕНТАЦИИ GOOGLE
    override fun onResume() {
        appUpdateManager.appUpdateInfo.addOnSuccessListener { info ->
            if (info.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                // Если обновление зависло, возобновляем его
                try {
                    appUpdateManager.startUpdateFlow(
                        info,
                        activity,
                        AppUpdateOptions.defaultOptions(AppUpdateType.IMMEDIATE)
                    )
                } catch (e: Exception) {
                    // Логируем ошибку, если нужно
                }
            }
        }
    }

    override fun completeUpdate(callback: UpdateCallback) {
        appUpdateManager.completeUpdate().addOnSuccessListener {
            _isDownloaded = false
            callback.onResult(null)
        }.addOnFailureListener { e ->
            callback.onResult(Exception(e))
        }
    }

    override fun checkIsLatestVersion(callback: UpdateCallback) {
        appUpdateManager.appUpdateInfo.addOnSuccessListener { info ->
            if (info.updateAvailability() == UpdateAvailability.UPDATE_NOT_AVAILABLE) {
                callback.onResult(null)
            } else {
                callback.onResult(Exception("Old version"))
            }
        }.addOnFailureListener {
            callback.onResult(Exception(it))
        }
    }

    override fun unregisterListener() {
        listener?.let { appUpdateManager.unregisterListener(it) }
    }

    override fun isDownloading() = _isDownloading
    override fun isDownloaded() = _isDownloaded
}*/


package ru.wfllive.meteo

import android.app.Activity
import android.widget.Toast
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.InstallException
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability

class StoreUpdateManager(private val activity: Activity) : StoreUpdateInterface {

    private val appUpdateManager = AppUpdateManagerFactory.create(activity)
    private var listener: InstallStateUpdatedListener? = null
    private var internalCallback: UpdateCallback? = null
    private var _isDownloading = false
    private var _isDownloaded = false

    // Константа для кода запроса
    companion object {
        const val UPDATE_REQUEST_CODE = 2400
    }

    init {
        setupListener()
    }

    private fun setupListener() {
        listener = InstallStateUpdatedListener { state ->
            when (state.installStatus()) {
                InstallStatus.DOWNLOADING -> {
                    _isDownloading = true
                    val bytesDownloaded = state.bytesDownloaded()
                    val totalBytes = state.totalBytesToDownload()
                    val progress = if (totalBytes > 0L) ((bytesDownloaded * 100) / totalBytes).toInt() else 0
                    activity.runOnUiThread { internalCallback?.onProgress(progress) }
                }
                InstallStatus.DOWNLOADED -> {
                    _isDownloading = false
                    _isDownloaded = true
                    activity.runOnUiThread { internalCallback?.onResult(null) }
                }
                InstallStatus.FAILED -> {
                    _isDownloading = false
                    activity.runOnUiThread { internalCallback?.onResult(Exception("Google Update Failed")) }
                }
                else -> Unit
            }
        }
    }

    override fun checkForUpdates(callback: UpdateCallback) {
        appUpdateManager.appUpdateInfo.addOnSuccessListener { info ->
            if (info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE) {
                callback.onResult(Exception("Update Available"))
            } else {
                callback.onResult(Exception("No update"))
            }
        }.addOnFailureListener { e ->
            // ... блок Toast для отладки, если нужно ...
            callback.onResult(Exception("Check failed: ${e.message}", e))
        }
    }

    override fun startFlexibleUpdate(callback: UpdateCallback) {
        internalCallback = callback
        appUpdateManager.appUpdateInfo.addOnSuccessListener { info ->
            if (info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                info.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)) {
                
                listener?.let { appUpdateManager.registerListener(it) }
                
                appUpdateManager.startUpdateFlow(
                    info,
                    activity,
                    AppUpdateOptions.defaultOptions(AppUpdateType.FLEXIBLE)
                )
            }
        }.addOnFailureListener { e ->
            callback.onResult(Exception(e))
        }
    }

    // ИЗМЕНЕНО: Используем startUpdateFlowForResult с кодом 2400
    override fun startImmediateUpdate(activity: Activity, callback: UpdateCallback) {
        appUpdateManager.appUpdateInfo.addOnSuccessListener { info ->
            if (info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                info.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                
                appUpdateManager.startUpdateFlowForResult(
                    info,
                    activity,
                    AppUpdateOptions.defaultOptions(AppUpdateType.IMMEDIATE),
                    UPDATE_REQUEST_CODE // <-- ВОТ ЭТОТ КОД
                )
            }
        }.addOnFailureListener { e ->
            callback.onResult(Exception(e))
        }
    }
    
    override fun onResume() {
        appUpdateManager.appUpdateInfo.addOnSuccessListener { info ->
            if (info.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                try {
                    appUpdateManager.startUpdateFlowForResult(
                        info,
                        activity,
                        AppUpdateOptions.defaultOptions(AppUpdateType.IMMEDIATE),
                        UPDATE_REQUEST_CODE // <-- И ЗДЕСЬ ТОЖЕ
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    override fun completeUpdate(callback: UpdateCallback) {
        appUpdateManager.completeUpdate().addOnSuccessListener {
            _isDownloaded = false
            callback.onResult(null)
        }.addOnFailureListener { e ->
            callback.onResult(Exception(e))
        }
    }

    override fun checkIsLatestVersion(callback: UpdateCallback) {
        appUpdateManager.appUpdateInfo.addOnSuccessListener { info ->
            if (info.updateAvailability() == UpdateAvailability.UPDATE_NOT_AVAILABLE) {
                callback.onResult(null)
            } else {
                callback.onResult(Exception("Old version"))
            }
        }.addOnFailureListener {
            callback.onResult(Exception(it))
        }
    }

    override fun unregisterListener() {
        listener?.let { appUpdateManager.unregisterListener(it) }
    }

    override fun isDownloading() = _isDownloading
    override fun isDownloaded() = _isDownloaded
}