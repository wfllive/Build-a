/*package ru.wfllive.meteo

import android.app.Activity
import ru.rustore.sdk.appupdate.listener.InstallStateUpdateListener
import ru.rustore.sdk.appupdate.manager.factory.RuStoreAppUpdateManagerFactory
import ru.rustore.sdk.appupdate.model.AppUpdateOptions
import ru.rustore.sdk.appupdate.model.AppUpdateType
import ru.rustore.sdk.appupdate.model.InstallStatus
import ru.rustore.sdk.appupdate.model.UpdateAvailability

class StoreUpdateManager(private val activity: Activity) : StoreUpdateInterface {
    
    private val manager = RuStoreAppUpdateManagerFactory.create(activity)
    private var installStateUpdateListener: InstallStateUpdateListener? = null
    private var internalCallback: UpdateCallback? = null
    private var _isDownloading = false
    private var _isDownloaded = false

    init {
        setupListener()
    }

    private fun setupListener() {
        installStateUpdateListener = InstallStateUpdateListener { installState ->
            when (installState.installStatus) {
                InstallStatus.DOWNLOADED -> {
                    _isDownloading = false
                    _isDownloaded = true
                    activity.runOnUiThread { internalCallback?.onResult(null) }
                }
                InstallStatus.DOWNLOADING -> {
                    _isDownloading = true
                    _isDownloaded = false
                    val totalBytes = installState.totalBytesToDownload
                    val bytesDownloaded = installState.bytesDownloaded
                    val progress = if (totalBytes > 0) ((bytesDownloaded * 100) / totalBytes).toInt() else 0
                    activity.runOnUiThread { internalCallback?.onProgress(progress) }
                }
                InstallStatus.FAILED -> {
                    _isDownloading = false
                    activity.runOnUiThread { internalCallback?.onResult(Exception("Ошибка загрузки RuStore")) }
                }
                else -> Unit
            }
        }
    }

    override fun checkForUpdates(callback: UpdateCallback) {
        manager.getAppUpdateInfo().addOnSuccessListener { info ->
            if (info.updateAvailability == UpdateAvailability.UPDATE_AVAILABLE) {
                callback.onResult(Exception("Обновление доступно"))
            } else {
                callback.onResult(Exception("Обновление недоступно"))
            }
        }.addOnFailureListener {
            callback.onResult(Exception("Ошибка проверки", it))
        }
    }

    override fun startFlexibleUpdate(callback: UpdateCallback) {
        this.internalCallback = callback
        if (_isDownloaded) {
            callback.onResult(null)
            return
        }
        manager.getAppUpdateInfo().addOnSuccessListener { info ->
            if (info.updateAvailability == UpdateAvailability.UPDATE_AVAILABLE) {
                installStateUpdateListener?.let { manager.registerListener(it) }
                manager.startUpdateFlow(info, AppUpdateOptions.Builder().appUpdateType(AppUpdateType.FLEXIBLE).build())
            }
        }.addOnFailureListener { e ->
            callback.onResult(Exception(e))
        }
    }

    override fun startImmediateUpdate(activity: Activity, callback: UpdateCallback) {
        manager.getAppUpdateInfo().addOnSuccessListener { info ->
            if (info.updateAvailability == UpdateAvailability.UPDATE_AVAILABLE) {
                manager.startUpdateFlow(info, AppUpdateOptions.Builder().appUpdateType(AppUpdateType.IMMEDIATE).build())
                    .addOnSuccessListener { callback.onResult(null) }
                    .addOnFailureListener { callback.onResult(Exception(it)) }
            }
        }.addOnFailureListener {
             callback.onResult(Exception(it))
        }
    }
    
    // Для RuStore реализация не требуется, но метод должен быть
    override fun onResume() {
    }

    override fun completeUpdate(callback: UpdateCallback) {
        manager.completeUpdate(AppUpdateOptions.Builder().appUpdateType(AppUpdateType.FLEXIBLE).build())
            .addOnSuccessListener { 
                _isDownloaded = false
                callback.onResult(null) 
            }
            .addOnFailureListener { e ->
                callback.onResult(Exception(e))
            }
    }

    override fun checkIsLatestVersion(callback: UpdateCallback) {
         manager.getAppUpdateInfo().addOnSuccessListener { info ->
            if (info.updateAvailability == UpdateAvailability.UPDATE_NOT_AVAILABLE) {
                callback.onResult(null)
            } else {
                callback.onResult(Exception("Есть обновление"))
            }
         }.addOnFailureListener {
             callback.onResult(Exception(it))
         }
    }

    override fun unregisterListener() {
        installStateUpdateListener?.let { manager.unregisterListener(it) }
    }

    override fun isDownloading() = _isDownloading
    override fun isDownloaded() = _isDownloaded
}*/

package ru.wfllive.meteo

import android.app.Activity
import ru.rustore.sdk.appupdate.listener.InstallStateUpdateListener
import ru.rustore.sdk.appupdate.manager.factory.RuStoreAppUpdateManagerFactory
import ru.rustore.sdk.appupdate.model.AppUpdateOptions
import ru.rustore.sdk.appupdate.model.AppUpdateType
import ru.rustore.sdk.appupdate.model.InstallStatus
import ru.rustore.sdk.appupdate.model.UpdateAvailability

class StoreUpdateManager(private val activity: Activity) : StoreUpdateInterface {
    
    private val manager = RuStoreAppUpdateManagerFactory.create(activity)
    private var installStateUpdateListener: InstallStateUpdateListener? = null
    private var internalCallback: UpdateCallback? = null
    private var _isDownloading = false
    private var _isDownloaded = false

    init {
        setupListener()
    }

    private fun setupListener() {
        installStateUpdateListener = InstallStateUpdateListener { installState ->
            when (installState.installStatus) {
                InstallStatus.DOWNLOADED -> {
                    _isDownloading = false
                    _isDownloaded = true
                    activity.runOnUiThread { internalCallback?.onResult(null) }
                }
                InstallStatus.DOWNLOADING -> {
                    _isDownloading = true
                    _isDownloaded = false
                    val totalBytes = installState.totalBytesToDownload
                    val bytesDownloaded = installState.bytesDownloaded
                    val progress = if (totalBytes > 0) ((bytesDownloaded * 100) / totalBytes).toInt() else 0
                    activity.runOnUiThread { internalCallback?.onProgress(progress) }
                }
                InstallStatus.FAILED -> {
                    _isDownloading = false
                    activity.runOnUiThread { internalCallback?.onResult(Exception("Ошибка загрузки RuStore")) }
                }
                else -> Unit
            }
        }
    }

    override fun checkForUpdates(callback: UpdateCallback) {
        manager.getAppUpdateInfo().addOnSuccessListener { info ->
            if (info.updateAvailability == UpdateAvailability.UPDATE_AVAILABLE) {
                callback.onResult(Exception("Обновление доступно"))
            } else {
                callback.onResult(Exception("Обновление недоступно"))
            }
        }.addOnFailureListener {
            callback.onResult(Exception("Ошибка проверки", it))
        }
    }

    override fun startFlexibleUpdate(callback: UpdateCallback) {
        this.internalCallback = callback
        if (_isDownloaded) {
            callback.onResult(null)
            return
        }
        manager.getAppUpdateInfo().addOnSuccessListener { info ->
            if (info.updateAvailability == UpdateAvailability.UPDATE_AVAILABLE) {
                installStateUpdateListener?.let { manager.registerListener(it) }
                manager.startUpdateFlow(info, AppUpdateOptions.Builder().appUpdateType(AppUpdateType.FLEXIBLE).build())
            }
        }.addOnFailureListener { e ->
            callback.onResult(Exception(e))
        }
    }

    // === ИЗМЕНЕННЫЙ МЕТОД ===
    override fun startImmediateUpdate(activity: Activity, callback: UpdateCallback) {
        manager.getAppUpdateInfo().addOnSuccessListener { info ->
            if (info.updateAvailability == UpdateAvailability.UPDATE_AVAILABLE) {
                manager.startUpdateFlow(info, AppUpdateOptions.Builder().appUpdateType(AppUpdateType.IMMEDIATE).build())
                    .addOnSuccessListener { resultCode ->
                        // ПРОВЕРЯЕМ КОД РЕЗУЛЬТАТА
                        if (resultCode == Activity.RESULT_CANCELED) {
                            // Пользователь отменил -> передаем ошибку -> ForceUpdateManager закроет приложение
                            callback.onResult(Exception("User canceled update"))
                        } else if (resultCode == Activity.RESULT_OK) {
                            // Успех
                            callback.onResult(null)
                        } else {
                            // Любой другой код (например, ошибка) -> тоже закрываем
                            callback.onResult(Exception("Update failed with code: $resultCode"))
                        }
                    }
                    .addOnFailureListener { callback.onResult(Exception(it)) }
            }
        }.addOnFailureListener {
             callback.onResult(Exception(it))
        }
    }
    
    override fun onResume() {
        // Для RuStore не требуется явный onResume
    }

    override fun completeUpdate(callback: UpdateCallback) {
        manager.completeUpdate(AppUpdateOptions.Builder().appUpdateType(AppUpdateType.FLEXIBLE).build())
            .addOnSuccessListener { 
                _isDownloaded = false
                callback.onResult(null) 
            }
            .addOnFailureListener { e ->
                callback.onResult(Exception(e))
            }
    }

    override fun checkIsLatestVersion(callback: UpdateCallback) {
         manager.getAppUpdateInfo().addOnSuccessListener { info ->
            if (info.updateAvailability == UpdateAvailability.UPDATE_NOT_AVAILABLE) {
                callback.onResult(null)
            } else {
                callback.onResult(Exception("Есть обновление"))
            }
         }.addOnFailureListener {
             callback.onResult(Exception(it))
         }
    }

    override fun unregisterListener() {
        installStateUpdateListener?.let { manager.unregisterListener(it) }
    }

    override fun isDownloading() = _isDownloading
    override fun isDownloaded() = _isDownloaded
}