package ru.wfllive.meteo

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.util.Log

class StoreUpdateManager(private val activity: Activity) : StoreUpdateInterface {

    // Сюда вставьте ссылку на страницу загрузки вашего приложения
    private val DOWNLOAD_URL = "https://meteolive.ru" // Пример

    override fun checkForUpdates(callback: UpdateCallback) {
        // В универсальной версии нет магазина, который проверяет обновления.
        // Поэтому мы говорим "Обновлений магазина нет".
        // Но ForceUpdateManager все равно сработает через Remote Config.
        callback.onResult(Exception("No store updates"))
    }

    override fun startFlexibleUpdate(callback: UpdateCallback) {
        // Гибкого обновления нет, сразу открываем браузер
        openDownloadLink()
        callback.onResult(null)
    }

    override fun startImmediateUpdate(activity: Activity, callback: UpdateCallback) {
        // Принудительное обновление -> открываем браузер
        openDownloadLink()
        // Не вызываем onResult(null), чтобы приложение не думало, что все готово.
        // Пусть висит диалог или закрывается, пользователь ушел в браузер.
    }

    override fun completeUpdate(callback: UpdateCallback) {
        // Нечего завершать
        callback.onResult(null)
    }

    override fun checkIsLatestVersion(callback: UpdateCallback) {
        // Считаем, что версия актуальна с точки зрения магазина
        callback.onResult(null)
    }

    override fun unregisterListener() {
        // Нет слушателей
    }

    override fun isDownloading(): Boolean = false
    override fun isDownloaded(): Boolean = false
    
    override fun onResume() {
        // Ничего не делаем
    }

    private fun openDownloadLink() {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(DOWNLOAD_URL))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
        } catch (e: Exception) {
            Log.e("StoreUpdateManager", "Failed to open browser", e)
        }
    }
}