import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("kotlin-parcelize")
    id("ru.ok.tracer").version("1.1.2")
    
    id("com.autonomousapps.dependency-analysis") version "3.5.1"
}

// Загружаем секреты из файла
val keystoreProperties = Properties().apply {
    val keystorePropertiesFile = rootProject.file("keystore.properties")
    if (keystorePropertiesFile.exists()) {
        load(FileInputStream(keystorePropertiesFile))
    }
}

android {
    namespace = "ru.wfllive.meteo"
    compileSdk = 36
    
    defaultConfig {
        applicationId = "ru.wfllive.meteo"
        minSdk = 26
        targetSdk = 36
        versionCode = 93
        versionName = "9.0.3 full"
        vectorDrawables.useSupportLibrary = true
    }
    
    // 1. Объявляем "измерение" для вариантов сборки
    flavorDimensions += "store"

    // 2. Создаем варианты (Flavors)
    productFlavors {
        // Вариант для RuStore (использует RuStore SDK для обновлений)
        create("rustore") {
            dimension = "store"
            // Можно добавить суффикс версии, чтобы различать APK
             versionNameSuffix = "-rustore" 
        }
        
        // Вариант для Google Play (использует Google Play In-App Updates)
        create("google") {
            dimension = "store"
             versionNameSuffix = "-google"
        }
        
        create("universal") {
            dimension = "store"
        }
    }
    
    signingConfigs {
        getByName("debug") {
            storeFile = file(keystoreProperties.getProperty("storeFile", "debug.keystore"))
            storePassword = keystoreProperties.getProperty("storePassword", "android")
            keyAlias = keystoreProperties.getProperty("keyAlias", "androiddebugkey")
            keyPassword = keystoreProperties.getProperty("keyPassword", "android")
        }
        create("release") {
            storeFile = file(keystoreProperties.getProperty("storeFile"))
            storePassword = keystoreProperties.getProperty("storePassword")
            keyAlias = keystoreProperties.getProperty("keyAlias")
            keyPassword = keystoreProperties.getProperty("keyPassword")
        }
    }
    
    tracer {
        create("defaultConfig") {
            pluginToken = "By5NTP52cNxHKBVSfNgrtvHo0qtvF2KUyL9odLqQ65z"
            appToken = "hAPUkAPPSsvpWuu5aTp2OiXCt5xSOVpcIrECjIJxyQG1"
            uploadMapping = true
        }
    }   

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
            isDebuggable = true
            
            buildConfigField("Boolean", "USE_DEV_SERVER", "true")
            buildConfigField("String", "DEV_SERVER_URL", "\"http://localhost:3000\"")
         // buildConfigField("String", "DEV_SERVER_URL", "\"http://192.168.0.120:3000\"")
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
                "proguard-custom.pro"
            )
            
            buildConfigField("Boolean", "USE_DEV_SERVER", "false")
            buildConfigField("String", "DEV_SERVER_URL", "\"\"")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    
    kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_11)
    }
}

    
    buildFeatures {
 
        buildConfig = true
        compose = true       // включаем Compose
    }
}




dependencies {
 
    implementation("androidx.appcompat:appcompat:1.7.0")
 
    implementation("androidx.core:core-splashscreen:1.2.0")
  

    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.compose.ui:ui:1.11.2")
    implementation("androidx.compose.foundation:foundation:1.11.2")
    implementation("androidx.compose.material3:material3:1.4.0")
    
    
    
    implementation("com.yandex.ads.multiplatform:mobileads-compose:8.0.1")
    implementation("com.yandex.android:mobileads-mediation:8.3.0.0")
    
  

    implementation("ru.rustore.sdk:remoteconfig:10.0.0")
    implementation(platform("ru.ok.tracer:tracer-platform:1.1.2"))
    implementation("ru.ok.tracer:tracer-crash-report")

    "rustoreImplementation"("ru.rustore.sdk:appupdate:10.2.0")
    "googleImplementation"("com.google.android.play:app-update-ktx:2.1.0")
}