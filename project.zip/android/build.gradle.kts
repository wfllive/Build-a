plugins {
    id("com.android.application") version "8.13.2" apply false
    id("com.android.library") version "8.13.2" apply false

    id("org.jetbrains.kotlin.android") version "2.3.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.3.0" apply false

    id("com.autonomousapps.dependency-analysis") version "3.5.1"
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}