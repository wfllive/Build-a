// Верхнеуровневый build файл с общими настройками для всех модулей
plugins {
    id("com.android.application") version "8.10.0" apply false
    id("com.android.library") version "8.10.0" apply false
    id("org.jetbrains.kotlin.android") version "2.3.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.3.0" apply false
    id("com.autonomousapps.dependency-analysis") version "3.5.1"
     // Updated to 2.0.0
     
     
}

tasks.register("clean", Delete::class) {
    delete(layout.buildDirectory)
}