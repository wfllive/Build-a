module.exports = {
  darkMode: 'class', // This enables class-based dark mode
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      animation: {
        'marquee': 'marquee 8s linear infinite',
      },
      keyframes: {
        marquee: {
          '0%': { transform: 'translateX(0%)' },
          '10%': { transform: 'translateX(0%)' },
          '45%': { transform: 'translateX(-100%)' },
          '55%': { transform: 'translateX(-100%)' },
          '90%': { transform: 'translateX(0%)' },
          '100%': { transform: 'translateX(0%)' },
        },
      },
    },
  },
  plugins: [],
}