200x500

<svg width="200" height="500" viewBox="0 0 100 250" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <!-- Градиент для темного фона -->
    <radialGradient id="bgGradient" cx="50%" cy="50%" r="70%">
      <stop offset="0%" stop-color="#1A237E"/> <!-- Темно-синий -->
      <stop offset="50%" stop-color="#0D47A1"/> <!-- Более темный синий -->
      <stop offset="100%" stop-color="#01579B"/> <!-- Еще темнее синий/голубой -->
    </radialGradient>

    <!-- Градиент для темного облака -->
    <linearGradient id="cloudGradient" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#78909C" /> <!-- Темно-серый -->
      <stop offset="50%" stop-color="#607D8B" /> <!-- Еще темнее серый/синеватый -->
      <stop offset="100%" stop-color="#455A64" /> <!-- Самый темный серый/синеватый -->
    </linearGradient>

    <!-- Градиент для солнца (без изменений) -->
    <radialGradient id="sunGradient" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#FFF176" />
      <stop offset="50%" stop-color="#FFD54F" />
      <stop offset="100%" stop-color="#FFB300" />
    </radialGradient>

    <!-- Градиент для молнии (без изменений) -->
    <linearGradient id="lightningGradient" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FFEA00" />
      <stop offset="50%" stop-color="#FFB300" />
      <stop offset="100%" stop-color="#FF8F00" />
    </linearGradient>

    <!-- Фильтр для тени (без изменений) -->
    <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
      <feDropShadow dx="2" dy="2" stdDeviation="2" flood-color="rgba(0,0,0,0.4)" /> <!-- Тень чуть темнее -->
    </filter>

  </defs>

  <!-- Фон -->
  <rect x="0" y="0" width="100" height="250" fill="url(#bgGradient)" />

  <!-- Группа для смещения всего содержимого вниз для центрирования в 100x250 viewBox -->
  <!-- Смещение на 75 единиц вниз: 100 (высота контента) + 75 (верхний отступ) + 75 (нижний отступ) = 250 -->
  <g transform="translate(0, 75)">
    <!-- Солнце -->
    <circle cx="44" cy="42" r="10" fill="url(#sunGradient)" filter="url(#shadow)">
      <!-- Лучи солнца -->
      <path d="M44 32 L44 28 M39 37 L36 35 M49 37 L52 35 M40 46 L37 48 M48 46 L51 48" stroke="#FFB300" stroke-width="0.5" fill="none" />
    </circle>

    <!-- Облако -->
    <!-- Координаты пути облака остаются такими же, но оно смещается группой -->
    <path d="M65 56c0-6-5-11-11-11-2.3 0-4.4 0.7-6.1 1.9C45.5 44.2 41.8 42 37.5 42 31.1 42 26 47.1 26 53.5S31.1 65 37.5 65H63c3.9 0 7-3.1 7-7z" fill="url(#cloudGradient)" filter="url(#shadow)" />

    <!-- Надпись "WFL Live" внутри облака -->
    <!-- Позиционирование текста внутри облака (относительно начала группы, т.е. оригинальных координат) -->
    <text x="45" y="57" font-family="Arial, sans-serif" font-size="8" fill="#FFFFFF" text-anchor="middle" font-weight="bold" filter="url(#shadow)">
      WFL Live
    </text>

    <!-- Молния -->
    <!-- Координаты пути молнии остаются такими же, но она смещается группой -->
    <path d="M52 66 L47 76 L51 76 L48 84 L57 70 L53 70 L56 66 Z" fill="url(#lightningGradient)" filter="url(#shadow)" />
  </g>
</svg>


1920x768

<svg width="1920" height="768" viewBox="0 0 250 100" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <!-- Градиент для темного фона (такой же, как для аватара) -->
    <radialGradient id="bgGradient" cx="50%" cy="50%" r="70%">
      <stop offset="0%" stop-color="#1A237E"/> <!-- Темно-синий -->
      <stop offset="50%" stop-color="#0D47A1"/> <!-- Более темный синий -->
      <stop offset="100%" stop-color="#01579B"/> <!-- Еще темнее синий/голубой -->
    </radialGradient>

    <!-- Градиент для темного облака (такой же, как для аватара) -->
    <linearGradient id="cloudGradient" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#78909C" /> <!-- Темно-серый -->
      <stop offset="50%" stop-color="#607D8B" /> <!-- Еще темнее серый/синеватый -->
      <stop offset="100%" stop-color="#455A64" /> <!-- Самый темный серый/синеватый -->
    </linearGradient>

    <!-- Градиент для солнца (без изменений) -->
    <radialGradient id="sunGradient" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#FFF176" />
      <stop offset="50%" stop-color="#FFD54F" />
      <stop offset="100%" stop-color="#FFB300" />
    </radialGradient>

    <!-- Градиент для молнии (без изменений) -->
    <linearGradient id="lightningGradient" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FFEA00" />
      <stop offset="50%" stop-color="#FFB300" />
      <stop offset="100%" stop-color="#FF8F00" />
    </linearGradient>

    <!-- Фильтр для тени (такой же, как для аватара) -->
    <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
      <feDropShadow dx="2" dy="2" stdDeviation="2" flood-color="rgba(0,0,0,0.4)" /> <!-- Тень чуть темнее -->
    </filter>

  </defs>

  <!-- Фон -->
  <rect x="0" y="0" width="250" height="100" fill="url(#bgGradient)" />

  <!-- Группа для смещения всего содержимого вправо для центрирования в 250x100 viewBox -->
  <!-- Смещение на 75 единиц вправо: 75 (левый отступ) + 100 (ширина контента) + 75 (правый отступ) = 250 -->
  <g transform="translate(75, 0)">
    <!-- Солнце -->
    <circle cx="44" cy="42" r="10" fill="url(#sunGradient)" filter="url(#shadow)">
      <!-- Лучи солнца -->
      <path d="M44 32 L44 28 M39 37 L36 35 M49 37 L52 35 M40 46 L37 48 M48 46 L51 48" stroke="#FFB300" stroke-width="0.5" fill="none" />
    </circle>

    <!-- Облако -->
    <!-- Координаты пути облака остаются такими же, но оно смещается группой -->
    <path d="M65 56c0-6-5-11-11-11-2.3 0-4.4 0.7-6.1 1.9C45.5 44.2 41.8 42 37.5 42 31.1 42 26 47.1 26 53.5S31.1 65 37.5 65H63c3.9 0 7-3.1 7-7z" fill="url(#cloudGradient)" filter="url(#shadow)" />

    <!-- Надпись "WFL Live" внутри облака -->
    <!-- Позиционирование текста внутри облака (относительно начала группы, т.е. оригинальных координат) -->
    <text x="45" y="57" font-family="Arial, sans-serif" font-size="8" fill="#FFFFFF" text-anchor="middle" font-weight="bold" filter="url(#shadow)">
      WFL Live
    </text>

    <!-- Молния -->
    <!-- Координаты пути молнии остаются такими же, но она смещается группой -->
    <path d="M52 66 L47 76 L51 76 L48 84 L57 70 L53 70 L56 66 Z" fill="url(#lightningGradient)" filter="url(#shadow)" />
  </g>
</svg>