
// важный

import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { createRequire } from 'module';
import replace from '@rollup/plugin-replace';
import { visualizer } from 'rollup-plugin-visualizer';
import { terser } from 'rollup-plugin-terser';
import obfuscator from 'rollup-plugin-javascript-obfuscator';
import crypto from 'crypto';

const require = createRequire(import.meta.url);

// Генератор хешей для файлов
const generateHash = (str, length = 8) => {
  return crypto.createHash('sha256').update(str).digest('hex').substring(0, length);
};


function removeErudaPlugin() {
  return {
    name: 'remove-eruda',
    transformIndexHtml(html, ctx) {
      if (ctx.server) {
        // dev — оставляем как есть
        return html;
      }
      // production build — удаляем блок eruda
      return html.replace(
        /<!-- eruda-start -->[\s\S]*?<!-- eruda-end -->/g,
        ''
      );
    },
  };
}

export default defineConfig({
  base: './',
  plugins: [
    react(),
    removeErudaPlugin(),
    replace({
      preventAssignment: true,
      values: {
        '"/assets/': '"assets/',
        "'/assets/": "'assets/",
        '(/assets/)': '(assets/)',
        'process.env.NODE_ENV': JSON.stringify('production')
      },
      delimiters: ['', '']
    }),
    visualizer({
      gzipSize: true,
      filename: 'bundle-analysis.html',
      open: false
    }),
    process.env.NODE_ENV === 'production' ? terser({
      format: {
        comments: false,
        beautify: false,
      },
      compress: {
        drop_console: true,
        drop_debugger: true,
        passes: 2,
      },
    }) : null,
    process.env.NODE_ENV === 'production' ? obfuscator({
      // БЕЗОПАСНОЕ но эффективное запутывание
      compact: true,
      controlFlowFlattening: true,
      controlFlowFlatteningThreshold: 0.4,
      deadCodeInjection: false,
      debugProtection: false,
      disableConsoleOutput: true,
      identifierNamesGenerator: 'hexadecimal',
      log: false,
      numbersToExpressions: true,
      renameGlobals: false,
      selfDefending: true,
      simplify: true,
      splitStrings: true,
      splitStringsChunkLength: 10,
      stringArray: true,
      stringArrayEncoding: ['base64'],
      stringArrayIndexShift: true,
      stringArrayWrappersCount: 1,
      stringArrayWrappersChainedCalls: true,
      stringArrayWrappersParametersMaxCount: 2,
      stringArrayWrappersType: 'function',
      stringArrayThreshold: 0.5,
      transformObjectKeys: true,
      unicodeEscapeSequence: false,
      
      // Критически важные имена
      reservedNames: [
        '^React$', '^react$', '^useState$', '^useEffect$', '^useContext$', 
        '^useReducer$', '^useRef$', '^createElement$', '^forwardRef$', 
        '^memo$', '^lazy$', '^Suspense$', '^Component$', '^Fragment$',
        '^__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED$'
      ],
      reservedStrings: [
        'process.env', 'import.meta', 'NODE_ENV', '*.css', 'children',
        'key', 'ref', 'props', 'state', 'className', 'onClick', 'onChange'
      ]
    }) : null
  ].filter(Boolean),
  server: {
    https: false,
    allowedHosts: true,
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
      '@assets': path.resolve(__dirname, './src/assets'),
      drawer: path.resolve(__dirname, './src/drawer'),
      pages: path.resolve(__dirname, './src/pages'),
      localization: path.resolve(__dirname, './src/localization'),
      weather: path.resolve(__dirname, './src/weather'),
      'weather-ui': path.resolve(__dirname, './src/weather/ui'),
      'weather-widgets': path.resolve(__dirname, './src/weather/weather-widgets'),
      'weather-icons': path.resolve(__dirname, './src/weather/icons')
    }
  },
  build: {
    outDir: './android/app/src/main/assets/dist',
    emptyOutDir: true,
    chunkSizeWarningLimit: 5000, // Увеличено для множества файлов
    sourcemap: false,
    
    rollupOptions: {
      output: {
        // Случайные имена файлов
        assetFileNames: (assetInfo) => {
          const ext = assetInfo.name.split('.').pop();
          const randomHash = crypto.randomBytes(6).toString('hex');
          return `assets/${randomHash}.${ext}`;
        },
        entryFileNames: 'assets/[hash].js',
        chunkFileNames: 'assets/[hash].js',
        
        // СОТНИ ФАЙЛОВ - безопасное разделение
        manualChunks: (id) => {
          const timestamp = Date.now().toString(36).slice(-4);
          
          // Дробим node_modules на 50+ файлов
          if (id.includes('node_modules')) {
            const packageMatch = id.match(/node_modules[\\/]([^\\/]+)/);
            if (packageMatch) {
              const packageName = packageMatch[1];
              const packageHash = generateHash(packageName, 6);
              
              // Отдельные чанки для основных пакетов
              if (packageName.startsWith('react')) return `react-${packageHash}-${timestamp}`;
              if (packageName.startsWith('@mui')) return `mui-${packageHash}-${timestamp}`;
              if (packageName.startsWith('axios')) return `axios-${packageHash}-${timestamp}`;
              if (packageName.startsWith('lodash')) return `lodash-${packageHash}-${timestamp}`;
              
              return `npm-${packageHash}-${timestamp}`;
            }
            return `vendor-${timestamp}`;
          }
          
          // Дробим исходный код на 100+ файлов
          if (id.includes('src/')) {
            const fileHash = generateHash(id, 8);
            
            // Чанки по типам файлов
            if (id.includes('/components/')) {
              const compName = id.split('/').pop().split('.')[0];
              return `comp-${generateHash(compName, 4)}-${timestamp}`;
            }
            
            if (id.includes('/pages/')) {
              const pageName = id.split('/').pop().split('.')[0];
              return `page-${generateHash(pageName, 4)}-${timestamp}`;
            }
            
            if (id.includes('/hooks/')) {
              return `hook-${fileHash.slice(0, 6)}-${timestamp}`;
            }
            
            if (id.includes('/utils/')) {
              return `util-${fileHash.slice(0, 6)}-${timestamp}`;
            }
            
            if (id.includes('/services/')) {
              return `service-${fileHash.slice(0, 6)}-${timestamp}`;
            }
            
            if (id.includes('/assets/')) {
              return `asset-${fileHash.slice(0, 6)}-${timestamp}`;
            }
            
            // Для остальных файлов - максимальное дробление
            return `file-${fileHash}-${timestamp}`;
          }
          
          // Для прочих файлов
          return `misc-${generateHash(id, 6)}-${timestamp}`;
        }
      }
    },
    
    // Дополнительная оптимизация
    terserOptions: {
      compress: {
        drop_console: true,
        drop_debugger: true,
        pure_funcs: ['console.log', 'console.info', 'console.debug'],
        passes: 2
      },
      format: {
        comments: false
      }
    }
  }
});



/*
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { createRequire } from 'module';
import replace from '@rollup/plugin-replace';
import { visualizer } from 'rollup-plugin-visualizer';
import { terser } from 'rollup-plugin-terser';
import obfuscator from 'rollup-plugin-javascript-obfuscator';
import cssnano from 'cssnano';
import crypto from 'crypto';

const require = createRequire(import.meta.url);

// Функция для проверки уровня безопасности
const calculateSecurityLevel = (config) => {
  let score = 0;
  let maxScore = 0;

  const weights = {
    controlFlowFlattening: 15,
    deadCodeInjection: 20,
    stringArray: 10,
    stringArrayEncoding: 5,
    transformObjectKeys: 10,
    selfDefending: 15,
    debugProtection: 25
  };

  Object.keys(config).forEach(key => {
    if (weights[key] && config[key]) {
      if (typeof config[key] === 'boolean') {
        score += weights[key];
        maxScore += weights[key];
      } else if (typeof config[key] === 'number' && config[key] > 0) {
        score += weights[key] * config[key];
        maxScore += weights[key];
      }
    }
  });

  return Math.round((score / maxScore) * 100);
};

// Мощная конфигурация обфускации
const getObfuscatorConfig = (isProduction) => {
  if (!isProduction) {
    return {
      compact: false,
      controlFlowFlattening: false,
      deadCodeInjection: false,
      stringArray: false,
      selfDefending: false
    };
  }

  const config = {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.85,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.5,
    debugProtection: true,
    debugProtectionInterval: 2000,
    disableConsoleOutput: true,
    identifierNamesGenerator: 'hexadecimal',
    log: false,
    numbersToExpressions: true,
    renameGlobals: true,
    renameProperties: true,
    renamePropertiesMode: 'safe',
    selfDefending: true,
    simplify: true,
    splitStrings: true,
    splitStringsChunkLength: 8,
    stringArray: true,
    stringArrayEncoding: ['rc4', 'base64'],
    stringArrayIndexesType: ['hexadecimal-number'],
    stringArrayIndexShift: true,
    stringArrayWrappersCount: 3,
    stringArrayWrappersChainedCalls: true,
    stringArrayWrappersParametersMaxCount: 5,
    stringArrayWrappersType: 'function',
    stringArrayThreshold: 0.85,
    transformObjectKeys: true,
    unicodeEscapeSequence: false,
    target: 'browser',
    domainLock: [],
    reservedNames: [],
    reservedStrings: [],
    seed: Math.floor(Math.random() * 1000000),
    sourceMap: false,
    sourceMapMode: 'separate',
    stringArrayRotate: true,
    stringArrayShuffle: true,
    stringArrayCallsTransform: true,
    stringArrayCallsTransformThreshold: 0.5
  };

  // Проверка уровня безопасности
  const securityLevel = calculateSecurityLevel(config);
  console.log(`🚀 Уровень безопасности обфускации: ${securityLevel}%`);

  if (securityLevel < 85) {
    console.warn('⚠️  Внимание: Уровень безопасности ниже рекомендуемого (85%)');
  } else {
    console.log('✅ Отличный уровень безопасности!');
  }

  return config;
};

export default defineConfig(({ mode }) => {
  const isProduction = mode === 'production';

  return {
    base: './',
    plugins: [
      react(),
      replace({
        preventAssignment: true,
        values: {
          '"/assets/': '"assets/',
          "'/assets/": "'assets/",
          '(/assets/)': '(assets/)',
          'process.env.NODE_ENV': JSON.stringify(isProduction ? 'production' : 'development')
        },
        delimiters: ['', '']
      }),
      visualizer({
        gzipSize: true,
        filename: 'bundle-analysis.html',
        open: false
      }),
      terser({
        format: {
          comments: false,
          beautify: false,
        },
        compress: {
          drop_console: isProduction,
          drop_debugger: isProduction,
          pure_funcs: isProduction ? ['console.log', 'console.info', 'console.debug'] : []
        },
      }),
      obfuscator(getObfuscatorConfig(isProduction))
    ],
    server: {
      https: false,
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './src'),
        '@assets': path.resolve(__dirname, './src/assets'),
        drawer: path.resolve(__dirname, './src/drawer'),
        pages: path.resolve(__dirname, './src/pages'),
        localization: path.resolve(__dirname, './src/localization'),
        weather: path.resolve(__dirname, './src/weather'),
        'weather-ui': path.resolve(__dirname, './src/weather/ui'),
        'weather-widgets': path.resolve(__dirname, './src/weather/weather-widgets'),
        'weather-icons': path.resolve(__dirname, './src/weather/icons')
      }
    },
    build: {
      outDir: './android/app/src/main/assets/dist',
      emptyOutDir: true,
      chunkSizeWarningLimit: 1000,
      sourcemap: isProduction ? 'hidden' : true,
      minify: isProduction ? 'terser' : false,
      rollupOptions: {
        output: {
          assetFileNames: (assetInfo) => {
            const ext = assetInfo.name.split('.').pop();
            const hash = crypto
              .createHash('sha256')
              .update(assetInfo.name)
              .digest('hex')
              .substring(0, 12);
            return `assets/${hash}.${ext}`;
          },
          entryFileNames: isProduction ? 'assets/[hash].[hash].js' : 'assets/[name].js',
          chunkFileNames: isProduction ? 'assets/[hash].[hash].js' : 'assets/[name].js',
          manualChunks: (id) => {
            if (id.includes('node_modules')) {
              const packageName = id.split('node_modules/')[1].split('/')[0];
              return `vendor/${packageName.replace('@', '')}`;
            }
            
            const hash = crypto
              .createHash('sha256')
              .update(id)
              .digest('hex')
              .substring(0, 8);
              
            return `chunk-${hash}`;
          },
        },
      },
      css: {
        modules: {
          generateScopedName: isProduction ? '[hash:base64:12]' : '[name]__[local]',
        },
        minify: isProduction ? cssnano() : false,
      },
      fs: {
        strict: false
      },
      experimental: {
        renderBuiltUrl(filename, { hostType }) {
          if (hostType === 'js' || hostType === 'css') {
            return { runtime: `JSON.stringify('assets/${filename.split('/').pop()}')` };
          }
          return { relative: true };
        }
      }
    }
  };
});*/



