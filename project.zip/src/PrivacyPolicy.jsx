

import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

const PrivacyPolicy = ({ isOpen, onClose, onAccept, lastUpdatedDate }) => {
  const { t, i18n } = useTranslation();
  const [isChecked, setIsChecked] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setIsChecked(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleAccept = () => {
    if (isChecked) {
      //onAccept();
      onClose();
    }
  };

  return (
    /* 
      ИЗМЕНЕНИЕ 1: p-0 для мобильных (убираем отступы вокруг), 
      md:p-4 для десктопа (возвращаем отступы)
    */
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-0 md:p-4">
      
      {/* 
        ИЗМЕНЕНИЕ 2: 
        - w-full h-full: на мобильных занимает всю ширину и высоту
        - rounded-none: на мобильных углы прямые
        - md:h-auto md:max-h-[90vh]: на десктопе высота по содержимому (но не более 90%)
        - md:rounded-lg: на десктопе углы скругленные
      */}
      <div className="bg-white dark:bg-gray-800 w-full h-full md:w-full md:max-w-2xl md:h-auto md:max-h-[90vh] md:rounded-lg shadow-xl flex flex-col">
        
        {/* Header - фиксированный */}
        {/* md:rounded-t-lg - скругление только сверху и только на десктопе */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 dark:from-blue-700 dark:to-blue-800 p-4 md:p-6 md:rounded-t-lg flex-shrink-0 safe-top">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>
            <div>
              <h2 className="text-xl md:text-2xl font-bold text-white">
                {t('privacy.title')}
              </h2>
              <p className="text-blue-100 text-xs md:text-sm mt-1">
                {t('privacy.lastUpdated')} {lastUpdatedDate}
              </p>
            </div>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 bg-white dark:bg-gray-800">
          <section className="space-y-4">
            {/* Секция 1: Сбор и использование информации */}
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-blue-600 dark:text-blue-300 text-sm font-bold">1</span>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {t('privacy.sections.dataCollection.title')}
                </h3>
                <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-300">
                  {t('privacy.sections.dataCollection.content')}
                </p>
              </div>
            </div>

            {/* Секция 2: Данные о местоположении */}
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-blue-600 dark:text-blue-300 text-sm font-bold">2</span>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {t('privacy.sections.locationData.title')}
                </h3>
                <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-300">
                  {t('privacy.sections.locationData.content')}
                </p>
              </div>
            </div>

            {/* Секция 3: Технические данные */}
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-blue-600 dark:text-blue-300 text-sm font-bold">3</span>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {t('privacy.sections.technicalData.title')}
                </h3>
                <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-300">
                  {t('privacy.sections.technicalData.content')}
                </p>
                <div className="mt-2">
                  <a 
                    href="https://apptracer.ru/privacy/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-blue-600 dark:text-blue-400 hover:underline text-sm inline-flex items-center"
                  >
                    {t('privacy.sections.technicalData.link')}
                    <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                    </svg>
                  </a>
                </div>
              </div>
            </div>

            {/* Секция 4: Хранение данных */}
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-blue-600 dark:text-blue-300 text-sm font-bold">4</span>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {t('privacy.sections.dataStorage.title')}
                </h3>
                <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-300">
                  {t('privacy.sections.dataStorage.content')}
                </p>
              </div>
            </div>

            {/* Секция 5: Локальное хранилище */}
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-blue-600 dark:text-blue-300 text-sm font-bold">5</span>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {t('privacy.sections.localStorage.title')}
                </h3>
                <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-300">
                  {t('privacy.sections.localStorage.content')}
                </p>
              </div>
            </div>

            {/* Секция 6: Внешние ссылки */}
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-blue-600 dark:text-blue-300 text-sm font-bold">6</span>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {t('privacy.sections.externalLinks.title')}
                </h3>
                <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-300">
                  {t('privacy.sections.externalLinks.content1')}
                </p>
                <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-300 mt-2">
                  {t('privacy.sections.externalLinks.content2')}
                </p>
              </div>
            </div>

            {/* Секция 7: Ваши права */}
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-blue-600 dark:text-blue-300 text-sm font-bold">7</span>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {t('privacy.sections.yourRights.title')}
                </h3>
                <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-300">
                  {t('privacy.sections.yourRights.content')}
                </p>
              </div>
            </div>
            
                        {/* Секция 8: реклама */}
                        <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-blue-600 dark:text-blue-300 text-sm font-bold">8</span>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
Наши Рекламные Партнеры
                </h3>
                <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-300">
Некоторые рекламодатели в нашем приложении могут использовать файлы cookie и веб-маяки. Наши рекламные партнеры перечислены ниже. У каждого из наших рекламных партнеров есть собственная политика конфиденциальности в отношении пользовательских данных. Для удобства мы разместили ссылки на их политики конфиденциальности ниже.
                </p>
                <a className="text-sm leading-relaxed text-blue-600 dark:text-blue-300" href="https:/yandex.ru/legal/
confidential/">Yandex</a>
              </div>
            </div>
            
            

            {/* Секция 9: Контакты */}
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-blue-600 dark:text-blue-300 text-sm font-bold">9</span>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {t('privacy.sections.contact.title')}
                </h3>
                <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-300 mb-3">
                  {t('privacy.sections.contact.description')}
                </p>
            <div className="space-y-2">
            <div className="flex items-center space-x-3">
            <svg className="w-5 h-5 text-blue-600 dark:text-blue-400" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.562 8.161c-.18 1.897-.962 6.502-1.361 8.627-.168.9-.5 1.201-.82 1.23-.697.064-1.226-.461-1.901-.903-1.056-.692-1.653-1.123-2.678-1.799-1.185-.781-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.139-5.062 3.345-.479.329-.913.489-1.302.481-.428-.008-1.252-.241-1.865-.44-.751-.244-1.349-.374-1.297-.789.027-.216.324-.437.893-.663 3.498-1.524 5.831-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635.445-.008 1.143.223.66.913z"/>
             </svg>
              <a 
                href="https://t.me/wfllive" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-blue-600 dark:text-blue-400 hover:underline text-sm"
              >
      {t('privacy.sections.contact.telegram')}
      </a>
    </div>

  {/* VK Icon */}
  <div className="flex items-center space-x-3">
    <svg className="w-5 h-5 text-blue-600 dark:text-blue-400" fill="currentColor" viewBox="0 0 24 24">
      <path d="M15.684 0H8.316C1.592 0 0 1.592 0 8.316v7.368C0 22.408 1.592 24 8.316 24h7.368C22.408 24 24 22.408 24 15.684V8.316C24 1.592 22.408 0 15.684 0zm2.648 17.908c-.13.222-.915.464-2.016.464-1.907 0-3.64-1.537-4.78-3.498-.125-.209-.67-1.002-.809-.792-.14.209-.11.695-.11 1.49 0 .494-.11.995-1.01.995-.76 0-2.623-.81-4.038-3.59-1.69-3.324-2.24-6.042-2.24-6.567 0-.318.123-.585.795-.585h2.42c.447 0 .638.22.82.69.574 1.475 1.465 3.314 1.83 3.75.273.327.44.423.604.423.125 0 .328-.145.328-.953V6.545c0-.817-.228-1.18-.693-1.272-.347-.07-.033-.565.847-.565 1.05 0 1.362.488 1.362 1.585v3.833c0 .41.176.557.284.557.233 0 .423-.125.847-.877.87-1.537 1.506-3.587 1.506-3.587.082-.437.396-.71.956-.71h2.416c.738 0 .89.377.726.93-.51 1.762-1.93 4.023-2.12 4.297-.523.76-.392.89 0 1.39 1.07 1.363 2.113 2.988 2.223 3.738.054.37-.25.97-1.248.97z"/>
    </svg>
    <a 
      href="https://vk.com/meteolive" 
      className="text-blue-600 dark:text-blue-400 hover:underline text-sm"
      target="_blank"
      rel="noopener noreferrer"
        >
      {t('privacy.sections.contact.vk')}
    </a>
  </div>
</div>
              </div>
            </div>
          </section>

          {/* Важное примечание */}
          <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 p-4 rounded-lg">
            <div className="flex items-start space-x-3">
              <svg className="w-5 h-5 text-yellow-600 dark:text-yellow-400 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              <div>
                <h4 className="text-sm font-semibold text-yellow-800 dark:text-yellow-200 mb-1">
                  {t('privacy.importantNote.title')}
                </h4>
                <p className="text-sm text-yellow-700 dark:text-yellow-300">
                  {t('privacy.importantNote.content')}
                </p>
              </div>
            </div>
          </div>

          {/* Confirmation Checkbox */}
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 p-5 rounded-xl border border-blue-100 dark:border-blue-800 mb-4">
            <div className="flex items-start space-x-4">
              <div className="flex items-center h-5 mt-0.5 flex-shrink-0">
                <input
                  id="privacy-agreement"
                  type="checkbox"
                  checked={isChecked}
                  onChange={(e) => setIsChecked(e.target.checked)}
                  className="w-5 h-5 text-blue-600 bg-white border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600 cursor-pointer"
                />
              </div>
              <div>
                <label 
                  htmlFor="privacy-agreement" 
                  className="block text-sm font-medium text-blue-800 dark:text-blue-200 cursor-pointer mb-1"
                >
                  {t('privacy.confirmation.title')}
                </label>
                <p className="text-sm text-blue-700 dark:text-blue-300 leading-relaxed">
                  {t('privacy.confirmation.text')}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer - фиксированный */}
        {/* md:rounded-b-lg - скругление только снизу и только на десктопе */}
        <div className="border-t border-gray-200 dark:border-gray-700 p-4 md:p-6 bg-gray-50 dark:bg-gray-700 md:rounded-b-lg flex-shrink-0 safe-bottom">
          <div className="flex flex-col items-center space-y-4">
            <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
              {t('privacy.footer.text')}
            </p>
            <button
              onClick={handleAccept}
              disabled={!isChecked}
              className={`w-full md:w-auto px-8 py-3 text-base font-medium text-white rounded-lg transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-blue-500 focus:ring-opacity-50 ${
                isChecked 
                  ? 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg hover:shadow-xl cursor-pointer transform md:hover:scale-105' 
                  : 'bg-gradient-to-r from-gray-400 to-gray-500 cursor-not-allowed opacity-60'
              }`}
            >
              {t('privacy.footer.button')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;