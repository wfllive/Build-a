import React, { useEffect, useState, useRef, useCallback } from "react";
import {
  ShieldCheck,
  Clock3,
  Loader2,
  AlertCircle,
  XCircle,
  Video,
  PlayCircle,
} from "lucide-react";

// ─── helpers ─────────────────────────────────────────────────────────────────

const isAndroid = () =>
  typeof window !== "undefined" &&
  typeof window.Android !== "undefined" &&
  typeof window.Android.getAdFreeState === "function";

function formatMs(ms) {
  const totalSec = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;

  if (h > 0) return `${h}ч`;
  if (m > 0) return `${m}м`;
  return `${s}с`;
}

const DEFAULT_STATE = {
  adsDisabled: false,
  adsRemainingMs: 0,
  cooldownRemainingMs: 0,
  canActivate: true,
};

// ─── hook ────────────────────────────────────────────────────────────────────

function useAdFreeState() {
  const [adState, setAdState] = useState(DEFAULT_STATE);
  const [isRewardedReady, setIsRewardedReady] = useState(false);
  const [rewardedStatus, setRewardedStatus] = useState("idle");
  const tickRef = useRef(null);

  const refreshState = useCallback(() => {
    if (!isAndroid()) return;

    try {
      const raw = window.Android.getAdFreeState();
      setAdState(JSON.parse(raw));

      const ready = window.Android.isRewardedAdReady?.() ?? false;
      setIsRewardedReady(ready);
    } catch (e) {
      console.warn("[AdFree] refresh error:", e);
    }
  }, []);

  const startTick = useCallback(() => {
    if (tickRef.current) clearInterval(tickRef.current);

    tickRef.current = setInterval(() => {
      setAdState((prev) => {
        const adsRemainingMs = Math.max(0, prev.adsRemainingMs - 1000);
        const cooldownRemainingMs = Math.max(0, prev.cooldownRemainingMs - 1000);

        return {
          ...prev,
          adsDisabled: adsRemainingMs > 0,
          adsRemainingMs,
          cooldownRemainingMs,
          canActivate: cooldownRemainingMs === 0,
        };
      });
    }, 1000);
  }, []);

  useEffect(() => {
    if (!isAndroid()) return;

    refreshState();
    startTick();

    const onAdFreeChanged = (e) => {
      if (e?.detail) setAdState(e.detail);
      else refreshState();
    };

    const onRewardedChanged = (e) => {
      if (!e?.detail) return;
      const { status, isReady, adState: newAdState } = e.detail;

      setRewardedStatus(status);
      setIsRewardedReady(isReady);

      if (newAdState) setAdState(newAdState);
    };

    window.addEventListener("adFreeStateChanged", onAdFreeChanged);
    window.addEventListener("rewardedAdStateChanged", onRewardedChanged);

    return () => {
      window.removeEventListener("adFreeStateChanged", onAdFreeChanged);
      window.removeEventListener("rewardedAdStateChanged", onRewardedChanged);
      if (tickRef.current) clearInterval(tickRef.current);
    };
  }, [refreshState, startTick]);

  return { adState, isRewardedReady, rewardedStatus, setRewardedStatus };
}

// ─── component ───────────────────────────────────────────────────────────────

export default function AdFreeButton({ className = "", style = {} }) {
  const { adState, isRewardedReady, rewardedStatus, setRewardedStatus } =
    useAdFreeState();

  const [isActivating, setIsActivating] = useState(false);

  if (!isAndroid()) return null;

  const canPress =
    adState.canActivate &&
    isRewardedReady &&
    !isActivating &&
    rewardedStatus !== "loading" &&
    rewardedStatus !== "showing";

  const handleClick = async () => {
    if (!canPress) return;

    setIsActivating(true);
    setRewardedStatus("loading");

    try {
      const raw = window.Android.showRewardedAd();
      const result = JSON.parse(raw);

      if (!result.success) {
        switch (result.reason) {
          case "cooldown":
            setRewardedStatus("cooldown");
            break;
          case "not_ready":
          case "loading":
            setRewardedStatus("loading");
            break;
          default:
            setRewardedStatus("error");
            break;
        }
      } else {
        setRewardedStatus("showing");
      }
    } catch (e) {
      console.error("[AdFree] error:", e);
      setRewardedStatus("error");
    } finally {
      setIsActivating(false);
    }
  };

    const getUi = () => {
    if (adState.adsDisabled) {
      return {
        icon: ShieldCheck,
        text: "Скрыта", // было "Без рекламы"
        right: formatMs(adState.adsRemainingMs),
        color: "#16a34a",
        spin: false,
      };
    }

    if (!adState.canActivate) {
      return {
        icon: Clock3,
        text: "Повтор", 
        right: formatMs(adState.cooldownRemainingMs),
        color: "#64748b",
        spin: false,
      };
    }

    if (rewardedStatus === "loading" || isActivating || !isRewardedReady) {
      return {
        icon: Loader2,
        text: "Загрузка",
        right: "...",
        color: "#0f766e",
        spin: true,
      };
    }

    if (rewardedStatus === "showing") {
      return {
        icon: PlayCircle,
        text: "Смотрим",
        right: "...",
        color: "#2563eb",
        spin: false,
      };
    }

    if (rewardedStatus === "dismissed") {
      return {
        icon: XCircle,
        text: "Закрыто",
        right: "—",
        color: "#d97706",
        spin: false,
      };
    }

    if (rewardedStatus === "error") {
      return {
        icon: AlertCircle,
        text: "Ошибка",
        right: "позже",
        color: "#dc2626",
        spin: false,
      };
    }

    return {
      icon: Video,
      text: "Пауза", // супер-коротко
      right: "5 мин",
      color: "#2563eb",
      spin: false,
    };
  };

  const ui = getUi();
  const Icon = ui.icon;

  return (
    <div style={{ width: "100%", ...style }} className={className}>
      <style>
        {`
          @keyframes adfree-spin {
            to { transform: rotate(360deg); }
          }
        `}
      </style>

      <button
        type="button"
        onClick={handleClick}
        disabled={!canPress}
        style={{
          width: "100%",
          minHeight: "36px", // Сделали чуть ниже
          padding: "6px 8px", // Уменьшили отступы по краям
          borderRadius: "8px",
          border: "none",
          background: "#f8fafc", // Легкий фон
          display: "grid",
          gridTemplateColumns: "18px minmax(0, 1fr) auto", // Иконка занимает меньше места
          alignItems: "center",
          gap: "8px", // Отступ между иконкой и текстом
          cursor: canPress ? "pointer" : "default",
          opacity: !canPress && !adState.adsDisabled ? 0.6 : 1,
          WebkitTapHighlightColor: "transparent",
        }}
      >
        <span
          style={{
            display: "grid",
            placeItems: "center",
          }}
        >
          <Icon
            size={16} // Уменьшенная иконка
            color={ui.color}
            style={ui.spin ? { animation: "adfree-spin 1s linear infinite" } : undefined}
          />
        </span>

        <span
          style={{
            minWidth: 0,
            overflow: "hidden",
            textOverflow: "ellipsis", // Если даже "Скрыта" не влезет, обрежется аккуратно
            whiteSpace: "nowrap",
            fontSize: "13px",
            fontWeight: 500,
            color: "#334155", // Чуть более мягкий темный цвет
            textAlign: "left",
          }}
        >
          {ui.text}
        </span>

        <span
          style={{
            flexShrink: 0,
            fontSize: "12px", // Время чуть мельче
            fontWeight: 600,
            color: ui.color,
            whiteSpace: "nowrap",
          }}
        >
          {ui.right}
        </span>
      </button>
    </div>
  );
}