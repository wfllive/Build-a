/**
 * Диалог обновлений: ДВЕ независимые системы.
 *
 *   1. «Meteo OS» — OTA-обновление веб-интерфейса (React-бандла). Скачивается
 *      с GitHub, проверяется по SHA-256/подписи и применяется перезагрузкой
 *      WebView — без магазина и без переустановки APK.
 *      Мост: AndroidBridge.meteoOs (src/native/bridge/androidBridge.js).
 *
 *   2. «Приложение» — нативное обновление APK через магазин (RuStore /
 *      Google Play / universal). Осталось как было: window.Android.checkForUpdates().
 *
 * Состояние обеих систем живёт в Drawer.jsx и приходит через props.
 */

import React, { useState, useEffect } from 'react';
import { useSpring, animated, config } from '@react-spring/web';
import { FiDownload, FiRefreshCw, FiX, FiCpu, FiSmartphone, FiRotateCcw, FiCheck } from 'react-icons/fi';

const SectionTitle = ({ icon, children }) => (
  <div className="flex items-center mb-2 text-sm font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
    {icon}
    <span className="ml-2">{children}</span>
  </div>
);

const ProgressBar = ({ value }) => (
  <div className="mb-2">
    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
      <div
        className="bg-blue-600 h-2.5 rounded-full transition-all duration-300"
        style={{ width: `${value}%` }}
      />
    </div>
    <div className="flex justify-between mt-1 text-xs text-gray-600 dark:text-gray-400">
      <span>Прогресс:</span>
      <span>{value}%</span>
    </div>
  </div>
);

const UpdateDialog = ({
  isOpen,
  onClose,
  // ── Нативное обновление APK ────────────────────────────────────────────────
  onUpdate,
  onInstall,
  status,
  progress,
  error,
  // ── Meteo OS (OTA веб-бандла) ──────────────────────────────────────────────
  os, // { supported, state, status, progress, error, availableVersion, notes }
  onOsCheck,
  onOsDownload,
  onOsApply,
  onOsReset,
}) => {
  const [localError, setLocalError] = useState(error);
  const [isRendered, setIsRendered] = useState(isOpen);
  const [confirmReset, setConfirmReset] = useState(false);
  const isWeb = typeof window.Android === 'undefined';

  useEffect(() => {
    setLocalError(error);
  }, [error]);

  useEffect(() => {
    if (!isOpen) setConfirmReset(false);
  }, [isOpen]);

  const backdropAnimation = useSpring({
    opacity: isOpen ? 1 : 0,
    config: config.fast,
    onRest: () => {
      if (!isOpen) setIsRendered(false);
    },
  });

  const dialogAnimation = useSpring({
    opacity: isOpen ? 1 : 0,
    transform: isOpen
      ? 'translateY(0) scale(1)'
      : 'translateY(20px) scale(0.98)',
    config: { tension: 300, friction: 25 },
    onStart: () => {
      if (isOpen) setIsRendered(true);
    },
  });

  if (!isRendered) return null;

  const handleClose = () => {
    setLocalError(null);
    onClose();
  };

  const handleAction = () => {
    if (status === 'downloaded') {
      onInstall();
    } else {
      onUpdate();
    }
  };

  const osState = os?.state;
  const osStatus = os?.status || 'idle';
  const osSupported = Boolean(os?.supported);
  const osCurrent = osState?.currentVersion;
  const osIsOta = osState?.source === 'ota';

  // ── Секция Meteo OS ─────────────────────────────────────────────────────────

  const renderMeteoOs = () => {
    if (isWeb || !osSupported) {
      return (
        <p className="text-sm text-gray-500 dark:text-gray-400">
          {isWeb
            ? 'Обновления Meteo OS доступны только в мобильном приложении.'
            : 'Установленная версия приложения не поддерживает Meteo OS — обновите приложение.'}
        </p>
      );
    }

    return (
      <>
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-gray-700 dark:text-gray-300">
            Версия интерфейса: <b>{osCurrent || '—'}</b>
            {osIsOta && (
              <span className="ml-1 text-xs text-blue-500">(OTA)</span>
            )}
          </span>
          {osStatus === 'upToDate' && (
            <span className="flex items-center text-xs text-green-600 dark:text-green-400">
              <FiCheck className="mr-1" /> Актуально
            </span>
          )}
        </div>

        {os?.error && (
          <div className="mb-2 p-2 bg-red-100 dark:bg-red-900 rounded-lg text-xs text-red-800 dark:text-red-200">
            {os.error}
          </div>
        )}

        {osStatus === 'checking' && (
          <div className="flex items-center py-1 text-sm text-gray-700 dark:text-gray-300">
            <FiRefreshCw className="animate-spin text-blue-500 mr-2" />
            Проверяем обновления Meteo OS...
          </div>
        )}

        {osStatus === 'available' && (
          <div className="mb-2">
            <p className="text-sm text-gray-700 dark:text-gray-300">
              Доступна версия <b>{os.availableVersion}</b>.
            </p>
            {os.notes && (
              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400 whitespace-pre-line">
                {os.notes}
              </p>
            )}
          </div>
        )}

        {osStatus === 'requiresAppUpdate' && (
          <div className="mb-2 p-3 rounded-lg bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-700/50">
            <p className="text-sm font-medium text-amber-800 dark:text-amber-200">
              Доступна Meteo OS {os.availableVersion}, но из-за изменений она
              требует новую версию приложения.
            </p>
            <p className="mt-1 text-xs text-amber-700 dark:text-amber-300">
              Рекомендуем сначала обновить основное приложение — кнопка
              в разделе «Приложение» ниже.
            </p>
          </div>
        )}

        {osStatus === 'downloading' && <ProgressBar value={os.progress || 0} />}

        {osStatus === 'downloaded' && (
          <p className="mb-2 text-sm text-gray-700 dark:text-gray-300">
            Обновление загружено и проверено. Применение перезагрузит интерфейс
            (около секунды).
          </p>
        )}

        {osStatus === 'applying' && (
          <div className="flex items-center py-1 text-sm text-gray-700 dark:text-gray-300">
            <FiRefreshCw className="animate-spin text-blue-500 mr-2" />
            Применяем обновление...
          </div>
        )}

        <div className="flex flex-wrap gap-2 mt-1">
          {(osStatus === 'idle' || osStatus === 'upToDate' || osStatus === 'error' || osStatus === 'requiresAppUpdate') && (
            <button
              onClick={onOsCheck}
              className="px-3 py-1.5 text-sm rounded-lg bg-blue-600 hover:bg-blue-700 text-white flex items-center"
            >
              <FiRefreshCw className="mr-1.5" size={14} />
              Проверить
            </button>
          )}

          {osStatus === 'available' && (
            <button
              onClick={onOsDownload}
              className="px-3 py-1.5 text-sm rounded-lg bg-blue-600 hover:bg-blue-700 text-white flex items-center"
            >
              <FiDownload className="mr-1.5" size={14} />
              Скачать
            </button>
          )}

          {osStatus === 'downloaded' && (
            <button
              onClick={onOsApply}
              className="px-3 py-1.5 text-sm rounded-lg bg-green-600 hover:bg-green-700 text-white flex items-center"
            >
              <FiRefreshCw className="mr-1.5" size={14} />
              Применить
            </button>
          )}

          {osIsOta && osStatus !== 'downloading' && osStatus !== 'applying' && (
            confirmReset ? (
              <button
                onClick={() => {
                  setConfirmReset(false);
                  onOsReset();
                }}
                className="px-3 py-1.5 text-sm rounded-lg bg-red-600 hover:bg-red-700 text-white flex items-center"
              >
                <FiRotateCcw className="mr-1.5" size={14} />
                Точно сбросить?
              </button>
            ) : (
              <button
                onClick={() => setConfirmReset(true)}
                className="px-3 py-1.5 text-sm rounded-lg border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
              >
                <FiRotateCcw className="mr-1.5" size={14} />
                Сбросить
              </button>
            )
          )}
        </div>
      </>
    );
  };

  // ── Секция нативного обновления APK ────────────────────────────────────────

  const renderNativeUpdate = () => {
    if (isWeb) {
      return (
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Обновления приложения работают только в мобильной версии.
        </p>
      );
    }

    return (
      <>
        {localError && (
          <div className="mb-2 p-2 bg-red-100 dark:bg-red-900 rounded-lg text-xs text-red-800 dark:text-red-200">
            {localError}
          </div>
        )}

        {status === 'checking' && (
          <div className="flex items-center py-1 text-sm text-gray-700 dark:text-gray-300">
            <FiRefreshCw className="animate-spin text-blue-500 mr-2" />
            Проверяем обновления...
          </div>
        )}

        {(status === 'available' || status === 'downloaded') && (
          <>
            <p className="mb-2 text-sm text-gray-700 dark:text-gray-300">
              {status === 'available'
                ? 'Доступна новая версия приложения. Загрузить сейчас?'
                : 'Обновление загружено и готово к установке.'}
            </p>
            <button
              onClick={handleAction}
              className={`px-3 py-1.5 text-sm rounded-lg ${
                status === 'downloaded'
                  ? 'bg-green-600 hover:bg-green-700'
                  : 'bg-blue-600 hover:bg-blue-700'
              } text-white flex items-center`}
            >
              {status === 'downloaded' ? (
                <>
                  <FiRefreshCw className="mr-1.5" size={14} />
                  Установить
                </>
              ) : (
                <>
                  <FiDownload className="mr-1.5" size={14} />
                  Обновить
                </>
              )}
            </button>
          </>
        )}

        {status === 'downloading' && (
          <>
            <ProgressBar value={progress} />
            <p className="text-xs text-gray-700 dark:text-gray-300">
              Пожалуйста, не закрывайте приложение во время загрузки...
            </p>
          </>
        )}

        {status === 'latest' && (
          <p className="flex items-center text-sm text-green-600 dark:text-green-400">
            <FiCheck className="mr-1.5" /> Установлена последняя версия
          </p>
        )}
      </>
    );
  };

  return (
    <>
      <animated.div
        style={{
          ...backdropAnimation,
          pointerEvents: isOpen ? 'auto' : 'none',
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          backdropFilter: 'blur(4px)',
          zIndex: 50,
        }}
        onClick={handleClose}
      />

      <animated.div
        style={{
          ...dialogAnimation,
          pointerEvents: isOpen ? 'auto' : 'none',
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: dialogAnimation.transform.to(t => `translate(-50%, -50%) ${t}`),
          width: '90%',
          maxWidth: '28rem',
          zIndex: 50,
        }}
        className="origin-center"
      >
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-xl max-h-[85vh] overflow-y-auto">
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-xl font-bold text-black dark:text-white">
              Обновления
            </h3>
            <button
              onClick={handleClose}
              className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
            >
              <FiX size={20} />
            </button>
          </div>

          {/* ── Meteo OS: обновление интерфейса без магазина ── */}
          <div className="mb-4 pb-4 border-b border-gray-200 dark:border-gray-700">
            <SectionTitle icon={<FiCpu size={14} />}>Meteo OS · интерфейс</SectionTitle>
            {renderMeteoOs()}
          </div>

          {/* ── Нативное обновление приложения через магазин ── */}
          <div>
            <SectionTitle icon={<FiSmartphone size={14} />}>Приложение</SectionTitle>
            {renderNativeUpdate()}
          </div>

          <div className="flex justify-end mt-5">
            <button
              onClick={handleClose}
              className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 text-black dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              Закрыть
            </button>
          </div>
        </div>
      </animated.div>
    </>
  );
};

export default UpdateDialog;
