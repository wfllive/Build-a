import React, { useState } from 'react';
import { useSpring, animated, config } from '@react-spring/web';
import { FiHelpCircle } from 'react-icons/fi';
import { FaTelegramPlane, FaVk, FaTimes } from 'react-icons/fa';

const SupportDialog = ({ isOpen, onClose }) => {
  const [isRendered, setIsRendered] = useState(isOpen);

  const backdropAnimation = useSpring({
    opacity: isOpen ? 1 : 0,
    config: config.fast,
    onRest: () => {
      if (!isOpen) setIsRendered(false);
    }
  });

  const dialogAnimation = useSpring({
    opacity: isOpen ? 1 : 0,
    transform: isOpen 
      ? 'translateY(0) scale(1)' 
      : 'translateY(20px) scale(0.98)',
    config: {
      tension: 300,
      friction: 25,
    },
    onStart: () => {
      if (isOpen) setIsRendered(true);
    }
  });

  if (!isRendered) return null;

  return (
    <>
      <animated.div
        style={{
          ...backdropAnimation,
          pointerEvents: isOpen ? 'auto' : 'none',
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.7)',
          backdropFilter: 'blur(4px)',
          zIndex: 50,
        }}
        onClick={onClose}
      />

      <animated.div
        style={{
          ...dialogAnimation,
          pointerEvents: isOpen ? 'auto' : 'none',
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: dialogAnimation.transform.to(t => `translate(-50%, -50%) ${t}`),
          width: '90%',
          maxWidth: '28rem',
          zIndex: 50,
        }}
        className="origin-center"
      >
        <div className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden border border-gray-700 shadow-xl">
          <div className="flex items-center justify-between px-6 py-5 border-b border-gray-700">
            <div className="flex items-center space-x-3">
              <FiHelpCircle className="text-black dark:text-white text-xl min-w-[24px]" />
              <h3 className="text-xl font-semibold text-blavk dark:text-white">Поддержка</h3>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-gray-300 hover:text-white hover:bg-gray-700 transition-colors"
            >
              <FaTimes size={20} />
            </button>
          </div>

          <div className="p-6">
            <p className="text-gray-500 mb-8 text-center">
              Свяжитесь с нами через удобный для вас канал:
            </p>

            <div className="space-y-4">
              <a
                href="https://t.me/wfllive"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center px-5 py-4 bg-gradient-to-r from-sky-600 to-cyan-600 rounded-lg text-white font-medium hover:scale-[1.02] transition-transform active:scale-95"
              >
                <FaTelegramPlane size={24} className="mr-3" />
                <span>Telegram</span>
              </a>

              <a
                href="https://vk.com/meteolive"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center px-5 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg text-white font-medium hover:scale-[1.02] transition-transform active:scale-95"
              >
                <FaVk size={24} className="mr-3" />
                <span>ВКонтакте</span>
              </a>
            </div>

            <div className="mt-8 pt-4 border-t border-gray-700 text-center text-sm text-gray-500 dark:text-gray-500">
              <p>Обычно отвечаем в течение 1-2 часов</p>
            </div>
          </div>
        </div>
      </animated.div>
    </>
  );
};

export default SupportDialog;






