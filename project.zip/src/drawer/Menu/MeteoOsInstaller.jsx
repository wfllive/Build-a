/**
 * Meteo OS — красивый полноэкранный установщик OTA-обновления интерфейса.
 *
 * Показывается ПОВЕРХ всего приложения, когда пользователь запускает
 * установку из UpdateDialog. Ведёт через все шаги:
 *
 *   downloading → downloaded (готово к установке) → applying → (reload WebView)
 *
 * Дизайн: тёмный экран в стиле «системного обновления» — логотип, кольцевой
 * прогресс, шаги установки, версия. Не закрывается свайпом во время загрузки.
 *
 * Управляется из Drawer.jsx; статусы приходят событием native:meteoOs.
 */

import React, { useEffect, useMemo, useState } from 'react';
import { useSpring, animated, config } from '@react-spring/web';
import { FiCheck, FiDownload, FiCpu, FiRefreshCw, FiAlertTriangle, FiX } from 'react-icons/fi';

// ── Кольцевой прогресс ───────────────────────────────────────────────────────

const RING_SIZE = 168;
const RING_STROKE = 7;
const RING_R = (RING_SIZE - RING_STROKE) / 2;
const RING_LEN = 2 * Math.PI * RING_R;

const ProgressRing = ({ progress, indeterminate, state }) => {
  const spring = useSpring({
    dash: RING_LEN * (1 - (indeterminate ? 0.25 : progress / 100)),
    config: { tension: 120, friction: 20 },
  });

  const color =
    state === 'error' ? '#f87171'
    : state === 'done' ? '#4ade80'
    : '#38bdf8';

  return (
    <div
      className={indeterminate ? 'meteo-os-ring--spin' : ''}
      style={{ width: RING_SIZE, height: RING_SIZE }}
    >
      <svg width={RING_SIZE} height={RING_SIZE}>
        <circle
          cx={RING_SIZE / 2}
          cy={RING_SIZE / 2}
          r={RING_R}
          fill="none"
          stroke="rgba(148, 163, 184, 0.15)"
          strokeWidth={RING_STROKE}
        />
        <animated.circle
          cx={RING_SIZE / 2}
          cy={RING_SIZE / 2}
          r={RING_R}
          fill="none"
          stroke={color}
          strokeWidth={RING_STROKE}
          strokeLinecap="round"
          strokeDasharray={RING_LEN}
          strokeDashoffset={spring.dash}
          transform={`rotate(-90 ${RING_SIZE / 2} ${RING_SIZE / 2})`}
          style={{ transition: 'stroke .4s' }}
        />
      </svg>
    </div>
  );
};

// ── Шаг установки ────────────────────────────────────────────────────────────

const Step = ({ label, state }) => (
  <div className="flex items-center py-1.5">
    <span
      className="flex items-center justify-center rounded-full mr-3 flex-shrink-0"
      style={{
        width: 22,
        height: 22,
        background:
          state === 'done' ? 'rgba(74, 222, 128, 0.15)'
          : state === 'active' ? 'rgba(56, 189, 248, 0.15)'
          : 'rgba(148, 163, 184, 0.1)',
      }}
    >
      {state === 'done' && <FiCheck size={13} color="#4ade80" />}
      {state === 'active' && (
        <FiRefreshCw size={12} color="#38bdf8" className="animate-spin" />
      )}
      {state === 'idle' && (
        <span style={{ width: 6, height: 6, borderRadius: 999, background: 'rgba(148,163,184,.5)' }} />
      )}
    </span>
    <span
      className="text-sm"
      style={{
        color:
          state === 'done' ? 'rgba(226, 232, 240, 0.9)'
          : state === 'active' ? '#e2e8f0'
          : 'rgba(148, 163, 184, 0.6)',
      }}
    >
      {label}
    </span>
  </div>
);

// ── Установщик ───────────────────────────────────────────────────────────────

/**
 * @param phase   'downloading' | 'verifying' | 'ready' | 'applying' | 'error'
 * @param progress 0..100 (для downloading)
 */
const MeteoOsInstaller = ({
  isOpen,
  phase,
  progress,
  version,
  notes,
  error,
  onInstall,   // нажали «Установить сейчас» (phase === 'ready')
  onClose,     // закрыть (доступно в ready / error)
  onRetry,     // повторить загрузку после ошибки
}) => {
  const [isRendered, setIsRendered] = useState(isOpen);
  const [dots, setDots] = useState('');

  // Живая «печать» точек в статусе, чтобы экран не казался зависшим.
  useEffect(() => {
    if (!isOpen || (phase !== 'applying' && phase !== 'verifying')) return undefined;
    const timer = setInterval(() => {
      setDots((d) => (d.length >= 3 ? '' : d + '.'));
    }, 450);
    return () => clearInterval(timer);
  }, [isOpen, phase]);

  const backdrop = useSpring({
    opacity: isOpen ? 1 : 0,
    config: config.default,
    onRest: () => { if (!isOpen) setIsRendered(false); },
    onStart: () => { if (isOpen) setIsRendered(true); },
  });

  const card = useSpring({
    opacity: isOpen ? 1 : 0,
    transform: isOpen ? 'translateY(0px) scale(1)' : 'translateY(24px) scale(0.97)',
    config: { tension: 260, friction: 26 },
  });

  const steps = useMemo(() => {
    const stepState = (index) => {
      const order = { downloading: 0, verifying: 1, ready: 2, applying: 2, error: -1 };
      const current = order[phase] ?? 0;
      if (phase === 'error') return index === 0 ? 'active' : 'idle';
      if (index < current) return 'done';
      if (index === current) return phase === 'ready' ? 'done' : 'active';
      return 'idle';
    };
    return [
      { label: 'Загрузка пакета обновления', state: stepState(0) },
      { label: 'Проверка целостности и подписи', state: stepState(1) },
      {
        label: phase === 'applying' ? 'Установка и перезапуск интерфейса' : 'Установка',
        state: phase === 'applying' ? 'active' : stepState(2),
      },
    ];
  }, [phase]);

  if (!isRendered) return null;

  const canClose = phase === 'ready' || phase === 'error';
  const ringState = phase === 'error' ? 'error' : phase === 'ready' ? 'done' : 'progress';
  const indeterminate = phase === 'verifying' || phase === 'applying';

  const title =
    phase === 'downloading' ? 'Загрузка Meteo OS'
    : phase === 'verifying' ? `Проверка обновления${dots}`
    : phase === 'ready' ? 'Готово к установке'
    : phase === 'applying' ? `Установка${dots}`
    : 'Не удалось обновить';

  const subtitle =
    phase === 'downloading' ? 'Пакет загружается с сервера обновлений'
    : phase === 'verifying' ? 'Сверяем контрольную сумму и цифровую подпись'
    : phase === 'ready' ? 'Установка перезапустит интерфейс — это займёт пару секунд'
    : phase === 'applying' ? 'Не закрывайте приложение'
    : (error || 'Произошла ошибка при загрузке обновления');

  return (
    <>
      <animated.div
        style={{
          ...backdrop,
          pointerEvents: isOpen ? 'auto' : 'none',
          position: 'fixed',
          inset: 0,
          zIndex: 70,
          background:
            'radial-gradient(120% 90% at 50% 0%, #1e3a5f 0%, #0b1220 55%, #060a13 100%)',
        }}
      />

      <animated.div
        style={{
          ...card,
          pointerEvents: isOpen ? 'auto' : 'none',
          position: 'fixed',
          inset: 0,
          zIndex: 71,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '32px 24px',
          paddingTop: 'calc(32px + var(--safe-area-top, 0px))',
          paddingBottom: 'calc(32px + var(--safe-area-bottom, 0px))',
        }}
      >
        {canClose && (
          <button
            onClick={onClose}
            aria-label="Закрыть"
            style={{
              position: 'absolute',
              top: 'calc(16px + var(--safe-area-top, 0px))',
              right: 16,
              color: 'rgba(148,163,184,.8)',
              padding: 8,
            }}
          >
            <FiX size={22} />
          </button>
        )}

        {/* Логотип-чип Meteo OS */}
        <div
          className="flex items-center mb-8"
          style={{
            padding: '6px 14px',
            borderRadius: 999,
            background: 'rgba(56, 189, 248, 0.1)',
            border: '1px solid rgba(56, 189, 248, 0.25)',
          }}
        >
          <FiCpu size={14} color="#38bdf8" />
          <span
            style={{
              marginLeft: 8,
              fontSize: 12,
              fontWeight: 700,
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
              color: '#7dd3fc',
            }}
          >
            Meteo OS
          </span>
        </div>

        {/* Кольцо прогресса с центральным содержимым */}
        <div style={{ position: 'relative', marginBottom: 28 }}>
          <ProgressRing
            progress={progress}
            indeterminate={indeterminate}
            state={ringState}
          />
          <div
            style={{
              position: 'absolute',
              inset: 0,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {phase === 'downloading' && (
              <>
                <span style={{ fontSize: 34, fontWeight: 700, color: '#f1f5f9' }}>
                  {Math.round(progress)}
                  <span style={{ fontSize: 18, color: '#94a3b8' }}>%</span>
                </span>
                <FiDownload size={16} color="#38bdf8" style={{ marginTop: 4 }} />
              </>
            )}
            {(phase === 'verifying' || phase === 'applying') && (
              <FiRefreshCw size={34} color="#38bdf8" className="animate-spin" />
            )}
            {phase === 'ready' && <FiCheck size={44} color="#4ade80" />}
            {phase === 'error' && <FiAlertTriangle size={40} color="#f87171" />}
          </div>
        </div>

        <h2
          style={{
            fontSize: 22,
            fontWeight: 700,
            color: '#f1f5f9',
            marginBottom: 6,
            textAlign: 'center',
          }}
        >
          {title}
        </h2>
        <p
          style={{
            fontSize: 14,
            color: 'rgba(148,163,184,.9)',
            textAlign: 'center',
            maxWidth: 320,
            marginBottom: 8,
          }}
        >
          {subtitle}
        </p>

        {version && (
          <p style={{ fontSize: 13, color: '#7dd3fc', marginBottom: 20 }}>
            Версия интерфейса {version}
          </p>
        )}

        {/* Шаги */}
        {phase !== 'error' && (
          <div
            style={{
              width: '100%',
              maxWidth: 320,
              padding: '14px 18px',
              borderRadius: 16,
              background: 'rgba(15, 23, 42, 0.55)',
              border: '1px solid rgba(51, 65, 85, 0.5)',
              marginBottom: 20,
            }}
          >
            {steps.map((s) => (
              <Step key={s.label} label={s.label} state={s.state} />
            ))}
          </div>
        )}

        {/* Что нового */}
        {phase === 'ready' && notes && (
          <div
            style={{
              width: '100%',
              maxWidth: 320,
              padding: '12px 16px',
              borderRadius: 14,
              background: 'rgba(15, 23, 42, 0.4)',
              marginBottom: 20,
            }}
          >
            <p
              style={{
                fontSize: 11,
                fontWeight: 700,
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                color: 'rgba(148,163,184,.7)',
                marginBottom: 6,
              }}
            >
              Что нового
            </p>
            <p style={{ fontSize: 13, color: 'rgba(226,232,240,.85)', whiteSpace: 'pre-line' }}>
              {notes}
            </p>
          </div>
        )}

        {/* Кнопки */}
        {phase === 'ready' && (
          <button
            onClick={onInstall}
            style={{
              width: '100%',
              maxWidth: 320,
              padding: '14px 0',
              borderRadius: 14,
              fontSize: 15,
              fontWeight: 700,
              color: '#06111f',
              background: 'linear-gradient(135deg, #38bdf8, #22d3ee)',
              boxShadow: '0 8px 24px rgba(56, 189, 248, 0.35)',
            }}
          >
            Установить сейчас
          </button>
        )}

        {phase === 'error' && (
          <div style={{ display: 'flex', gap: 12, width: '100%', maxWidth: 320 }}>
            <button
              onClick={onClose}
              style={{
                flex: 1,
                padding: '13px 0',
                borderRadius: 14,
                fontSize: 14,
                fontWeight: 600,
                color: '#e2e8f0',
                border: '1px solid rgba(71, 85, 105, 0.7)',
              }}
            >
              Закрыть
            </button>
            <button
              onClick={onRetry}
              style={{
                flex: 1,
                padding: '13px 0',
                borderRadius: 14,
                fontSize: 14,
                fontWeight: 700,
                color: '#06111f',
                background: 'linear-gradient(135deg, #38bdf8, #22d3ee)',
              }}
            >
              Повторить
            </button>
          </div>
        )}

        {(phase === 'downloading' || phase === 'verifying' || phase === 'applying') && (
          <p style={{ fontSize: 12, color: 'rgba(100,116,139,.8)', marginTop: 4 }}>
            Обновление защищено цифровой подписью
          </p>
        )}
      </animated.div>

      {/* Локальный стиль вращения кольца в indeterminate-режиме */}
      <style>{`
        .meteo-os-ring--spin { animation: meteoOsRingSpin 1.2s linear infinite; }
        @keyframes meteoOsRingSpin { to { transform: rotate(360deg); } }
      `}</style>
    </>
  );
};

export default MeteoOsInstaller;
