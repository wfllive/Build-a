


// рабочий код


import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { FiHeart, FiCoffee, FiDownload } from 'react-icons/fi';
import SupportDialog from './Menu/SupportDialog';
import UpdateDialog from './Menu/UpdateDialog';
import MeteoOsInstaller from './Menu/MeteoOsInstaller';
import { useTranslation } from 'react-i18next';
import { AndroidBridge } from '@/native';
import './DrawerMenu.css';

import AdFreeButton from "./AdFreeButton";

const DrawerMenu = ({ isOpen, onToggle, children }) => {
  const { t } = useTranslation();
  const [isLatestVersion, setIsLatestVersion] = useState(false);
  const [supportOpen, setSupportOpen] = useState(false);
  const [updateDialogOpen, setUpdateDialogOpen] = useState(false);
  const [updateStatus, setUpdateStatus] = useState('available');
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [updateError, setUpdateError] = useState(null);
  const [isCheckingUpdate, setIsCheckingUpdate] = useState(false);
  const [hasUpdate, setHasUpdate] = useState(false);
  const isWeb = typeof window.Android === 'undefined';
  const [appVersion, setAppVersion] = useState('1.0');

  // ── Meteo OS: OTA-обновления веб-интерфейса (не путать с обновлением APK) ──
  const [osState, setOsState] = useState(null);         // ответ meteoOsGetState()
  // idle|checking|available|requiresAppUpdate|downloading|downloaded|applying|upToDate|error
  const [osStatus, setOsStatus] = useState('idle');
  const [osProgress, setOsProgress] = useState(0);
  const [osError, setOsError] = useState(null);
  const [osAvailableVersion, setOsAvailableVersion] = useState(null);
  const [osNotes, setOsNotes] = useState('');
  // Полноэкранный установщик: открывается на время загрузки/установки.
  const [installerOpen, setInstallerOpen] = useState(false);
  const osSupported = !isWeb && AndroidBridge.meteoOs.isSupported;

  // Refs и состояние для свайпа
  const drawerRef = useRef();
  const contentRef = useRef();
  const touchStartX = useRef(null);
  const [swipeOffset, setSwipeOffset] = useState(0);

  // Оптимизированные обработчики свайпа
  const handleTouchStart = useCallback((e) => {
    touchStartX.current = e.touches[0].clientX;
    setSwipeOffset(0);
  }, []);

  const handleTouchMove = useCallback((e) => {
    if (!isOpen || !touchStartX.current) return;
    
    const currentX = e.touches[0].clientX;
    const diff = touchStartX.current - currentX;
    
    if (diff > 0) { // Только свайп влево
      setSwipeOffset(-Math.min(diff, 100));
      e.preventDefault();
    }
  }, [isOpen]);

  const handleTouchEnd = useCallback(() => {
    if (swipeOffset < -50) {
      onToggle();
    }
    setSwipeOffset(0);
    touchStartX.current = null;
  }, [swipeOffset, onToggle]);

  // Оптимизированные функции меню
  const openSupport = useCallback(() => {
    setSupportOpen(true);
    onToggle();
  }, [onToggle]);
  
  const closeSupport = useCallback(() => setSupportOpen(false), []);
  
  const openUpdateDialog = useCallback(() => {
    // Диалог открываем ВСЕГДА: даже если APK актуален, внутри есть секция
    // Meteo OS (обновление интерфейса без магазина) и кнопка сброса.
    setUpdateDialogOpen(true);
    setUpdateError(null);

    if (!isWeb && !isLatestVersion) {
      setUpdateStatus('checking');
      checkForUpdates();
    } else if (isLatestVersion) {
      setUpdateStatus('latest');
    }

    onToggle();
  }, [isLatestVersion, isWeb, onToggle]);
  
  const closeUpdateDialog = useCallback(() => {
    setUpdateDialogOpen(false);
    setUpdateError(null);
  }, []);

  const checkForUpdates = useCallback(() => {
    if (isWeb) return;
    setIsCheckingUpdate(true);
    setUpdateError(null);
    window.Android.checkForUpdates();
  }, [isWeb]);

  const checkIsLatestVersion = useCallback(() => {
    if (!isWeb && window.Android) {
      window.Android.checkIsLatestVersion();
    }
  }, [isWeb]);

  const handleStartUpdate = useCallback(() => {
    if (isWeb) return;
    setUpdateStatus('downloading');
    setDownloadProgress(0);
    setUpdateError(null);
    if (window.Android) {
      window.Android.startFlexibleUpdate();
    }
  }, [isWeb]);

  const handleInstallUpdate = useCallback(() => {
    if (isWeb) return;
    if (window.Android) {
      window.Android.installUpdate();
    }
    closeUpdateDialog();
    setIsLatestVersion(true);
    setHasUpdate(false);
  }, [isWeb, closeUpdateDialog]);

  // ── Meteo OS: действия ─────────────────────────────────────────────────────

  const refreshOsState = useCallback(() => {
    if (!osSupported) return;
    const state = AndroidBridge.meteoOs.getState();
    if (state) setOsState(state);
  }, [osSupported]);

  const handleOsCheck = useCallback(() => {
    if (!osSupported) return;
    setOsStatus('checking');
    setOsError(null);
    AndroidBridge.meteoOs.check();
  }, [osSupported]);

  const handleOsDownload = useCallback(() => {
    if (!osSupported) return;
    setOsStatus('downloading');
    setOsProgress(0);
    setOsError(null);
    // Загрузка идёт в красивом полноэкранном установщике,
    // диалог обновлений при этом закрываем.
    setInstallerOpen(true);
    setUpdateDialogOpen(false);
    AndroidBridge.meteoOs.download();
  }, [osSupported]);

  const handleOsApply = useCallback(() => {
    if (!osSupported) return;
    setOsStatus('applying');
    // Дальше native перезагрузит WebView с новой версией —
    // текущий JS-контекст умрёт, состояние восстановится с нуля.
    AndroidBridge.meteoOs.apply();
  }, [osSupported]);

  const handleOsReset = useCallback(() => {
    if (!osSupported) return;
    setOsStatus('applying');
    AndroidBridge.meteoOs.resetToBuiltin();
  }, [osSupported]);

  const closeInstaller = useCallback(() => {
    setInstallerOpen(false);
  }, []);

  const retryInstaller = useCallback(() => {
    handleOsDownload();
  }, [handleOsDownload]);

  // Подписка на события Meteo OS + начальное состояние.
  useEffect(() => {
    if (!osSupported) return undefined;

    refreshOsState();

    const unsubscribe = AndroidBridge.meteoOs.subscribe((detail) => {
      if (!detail || !detail.status) return;
      switch (detail.status) {
        case 'available':
          setOsStatus('available');
          setOsAvailableVersion(detail.version || null);
          setOsNotes(detail.notes || '');
          setOsError(null);
          break;
        case 'requiresAppUpdate':
          // Новая Meteo OS есть, но требует свежий APK: не качаем,
          // а рекомендуем обновить основное приложение из магазина.
          setOsStatus('requiresAppUpdate');
          setOsAvailableVersion(detail.version || null);
          setOsNotes(detail.notes || '');
          setOsError(null);
          // Сразу проверяем нативное обновление, чтобы секция «Приложение»
          // показала кнопку «Обновить» без лишнего клика.
          if (window.Android && typeof window.Android.checkForUpdates === 'function') {
            setUpdateStatus('checking');
            window.Android.checkForUpdates();
          }
          break;
        case 'upToDate':
          setOsStatus('upToDate');
          setOsError(null);
          break;
        case 'downloading':
          setOsStatus('downloading');
          setOsProgress(detail.progress || 0);
          break;
        case 'downloaded':
          setOsStatus('downloaded');
          setOsProgress(100);
          setOsError(null);
          refreshOsState();
          break;
        case 'applying':
        case 'reset':
          setOsStatus('applying');
          break;
        case 'error':
          setOsStatus('error');
          setOsError(detail.error || 'Неизвестная ошибка Meteo OS');
          break;
        default:
          break;
      }
    });

    return unsubscribe;
  }, [osSupported, refreshOsState]);

  // Оптимизированные эффекты
  useEffect(() => {
    checkIsLatestVersion();

    const handleUpdateAvailable = (e) => {
      setIsCheckingUpdate(false);
      setHasUpdate(true);
      if (e.detail && e.detail.alreadyDownloaded) {
        setUpdateStatus('downloaded');
        setDownloadProgress(100);
      } else {
        setUpdateStatus('available');
      }
    };

    const handlers = {
      updateAvailable: handleUpdateAvailable,
      updateStarted: () => {
        setIsCheckingUpdate(false);
        setUpdateStatus('downloading');
      },
      updateDownloaded: () => {
        setIsCheckingUpdate(false);
        setUpdateStatus('downloaded');
        setDownloadProgress(100);
      },
      updateProgress: (e) => {
        setDownloadProgress(e.detail || 0);
      },
      updateError: (e) => {
        setIsCheckingUpdate(false);
        setUpdateError(e.detail || 'Update error');
      },
      isLatestVersion: () => {
        setIsLatestVersion(true);
        setHasUpdate(false);
      }
    };

    if (!isWeb) {
      Object.entries(handlers).forEach(([event, handler]) => {
        window.addEventListener(event, handler, { passive: true });
      });
    }

    return () => {
      if (!isWeb) {
        Object.entries(handlers).forEach(([event, handler]) => {
          window.removeEventListener(event, handler);
        });
      }
    };
  }, [isWeb, checkIsLatestVersion]);
  
  useEffect(() => {
    if (!isWeb && window.Android) {
      const version = window.Android.getAppVersion();
      if (version) setAppVersion(version);
    }
  }, [isWeb]);

  useEffect(() => {
    const handleClick = (e) => {
      if (isOpen && drawerRef.current && !drawerRef.current.contains(e.target) && 
          contentRef.current && contentRef.current.contains(e.target)) {
        onToggle();
      }
    };
    
    document.addEventListener('mousedown', handleClick, { passive: true });
    document.addEventListener('touchstart', handleClick, { passive: true });
    return () => {
      document.removeEventListener('mousedown', handleClick);
      document.removeEventListener('touchstart', handleClick);
    };
  }, [isOpen, onToggle]);

  // Мемоизированное меню
  const menu = useMemo(() => [
    {
      id: 'donate',
      icon: <FiHeart size={20} className="flex-shrink-0 text-black dark:text-white" />,
      name: t('menu.donate'),
      action: () => {
        window.open('https://boosty.to/wfllive/donate');
        onToggle();
      },
    },
    {
      id: 'support',
      icon: <FiCoffee size={20} className="flex-shrink-0 text-black dark:text-white" />,
      name: t('menu.support'),
      action: openSupport,
    },
    {
      id: 'update',
      icon: <FiDownload size={20} className="flex-shrink-0 text-black dark:text-white" />,
      name: isLatestVersion 
        ? t('menu.latestVersion') 
        : hasUpdate 
          ? t('menu.updateAvailable') 
          : t('menu.checkUpdates'),
      action: openUpdateDialog,
      // Пункт больше не блокируется: внутри диалога живёт и секция Meteo OS
      // (обновление интерфейса без магазина), доступная всегда.
      disabled: false
    },
  ], [t, isLatestVersion, hasUpdate, openSupport, openUpdateDialog, onToggle]);

  // Мемоизированный SVG компонент
  const AppIcon = useMemo(() => (
    <svg 
      width="70" 
      height="70" 
      viewBox="0 0 100 100" 
      className="mb-3 rounded-lg"
    >
      <defs>
        <radialGradient id="bgGradient" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#42A5F5"/>
          <stop offset="50%" stopColor="#1E88E5"/>
          <stop offset="100%" stopColor="#1565C0"/>
        </radialGradient>

        <linearGradient id="cloudGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="50%" stopColor="#F0F4F8" />
          <stop offset="100%" stopColor="#DCE3E9" />
        </linearGradient>

        <radialGradient id="sunGradient" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#FFF176" />
          <stop offset="50%" stopColor="#FFD54F" />
          <stop offset="100%" stopColor="#FFB300" />
        </radialGradient>

        <linearGradient id="lightningGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFEA00" />
          <stop offset="50%" stopColor="#FFB300" />
          <stop offset="100%" stopColor="#FF8F00" />
        </linearGradient>

        <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
          <feDropShadow dx="2" dy="2" stdDeviation="2" floodColor="rgba(0,0,0,0.2)" />
        </filter>

        <pattern id="cloudTexture" patternUnits="userSpaceOnUse" width="4" height="4">
          <circle cx="2" cy="2" r="1" fill="rgba(255,255,255,0.3)" />
        </pattern>
      </defs>

      <circle cx="50" cy="50" r="48" fill="url(#bgGradient)" filter="url(#shadow)" />

      <circle cx="44" cy="42" r="10" fill="url(#sunGradient)" filter="url(#shadow)">
        <path d="M44 32 L44 28 M39 37 L36 35 M49 37 L52 35 M40 46 L37 48 M48 46 L51 48"
              stroke="#FFB300" strokeWidth="0.5" fill="none" />
      </circle>

      <path d="M65 56c0-6-5-11-11-11-2.3 0-4.4 0.7-6.1 1.9C45.5 44.2 41.8 42 37.5 42 31.1 42 26 47.1 26 53.5S31.1 65 37.5 65H63c3.9 0 7-3.1 7-7z"
            fill="url(#cloudGradient)" filter="url(#shadow)">
        <rect x="26" y="42" width="37" height="23.5" fill="url(#cloudTexture)" />
      </path>

      <path d="M52 66 L47 76 L51 76 L48 84 L57 70 L53 70 L56 66 Z"
            fill="url(#lightningGradient)" filter="url(#shadow)" />
    </svg>
  ), []);

  return (
    <>
      
      <div 
        className="drawer-container dark:bg-gray-900"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <div 
          className={`drawer-overlay ${isOpen ? 'drawer-overlay--visible' : ''}`}
          onClick={onToggle}
        />
        
        <div
          ref={drawerRef}
          className={`drawer ${isOpen ? 'drawer--open' : ''}`}
          style={swipeOffset ? { transform: `translateX(${swipeOffset}px)`, WebkitTransform: `translateX(${swipeOffset}px)` } : {}}
        >
          <div className="drawer-content bg-white dark:bg-gray-900 rounded-r-xl">
            <div className="drawer-header-spacer" />
            
            <div className="drawer-logo">
              {AppIcon}
              <h2 className="drawer-title">{t("main.name")}</h2>
            </div>
            
            <div style={{ padding: '12px 16px' }}>
    
  </div>
            
            <nav className="drawer-nav">
              {/*
                key — на ВНЕШНЕМ элементе списка. Раньше здесь был лишний
                фрагмент <>…</>, а key стоял на вложенной кнопке: короткий
                фрагмент ключ не принимает, поэтому React ругался
                «Each child in a list should have a unique key prop».
              */}
              {menu.map((menuItem) => (
                <button
                  key={menuItem.id}
                  type="button"
                  className={`drawer-menu-item ${menuItem.disabled ? 'drawer-menu-item--disabled' : ''}`}
                  onClick={() => {
                    if (!menuItem.disabled && menuItem.action) {
                      menuItem.action();
                    }
                  }}
                  disabled={menuItem.disabled}
                >
                  {menuItem.icon}
                  <span className="drawer-menu-text">
                    {menuItem.name}
                  </span>
                </button>
              ))}
              <AdFreeButton />
            </nav>
            
            <div className="drawer-footer">
              <p className="drawer-version">{t("main.versiontext")} {appVersion}</p>
              <a
                href="https://www.weatherapi.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="drawer-link"
              >
                {t("main.nameapi")}
              </a>
            </div>
          </div>
        </div>

        <div
          ref={contentRef}
          className={`drawer-main-content ${isOpen ? 'drawer-main-content--shifted' : ''}`}
        >
          <div 
            className="drawer-children-container"
            onClick={(e) => e.stopPropagation()}
          >
            {children}
          </div>
        </div>
      </div>

      <SupportDialog isOpen={supportOpen} onClose={closeSupport} />
      <UpdateDialog 
        isOpen={updateDialogOpen}
        onClose={closeUpdateDialog}
        onUpdate={handleStartUpdate}
        onInstall={handleInstallUpdate}
        status={updateStatus}
        progress={downloadProgress}
        error={updateError}
        os={{
          supported: osSupported,
          state: osState,
          status: osStatus,
          progress: osProgress,
          error: osError,
          availableVersion: osAvailableVersion,
          notes: osNotes,
        }}
        onOsCheck={handleOsCheck}
        onOsDownload={handleOsDownload}
        onOsApply={handleOsApply}
        onOsReset={handleOsReset}
      />

      {/*
        Красивый полноэкранный установщик Meteo OS.
        Фазы выводим из osStatus: downloading → (100%) verifying → ready →
        applying. «verifying» — момент, когда прогресс дошёл до 100%, но
        событие downloaded ещё не пришло (native проверяет SHA-256/подпись
        и распаковывает архив).
      */}
      <MeteoOsInstaller
        isOpen={installerOpen}
        phase={
          osStatus === 'downloading'
            ? (osProgress >= 100 ? 'verifying' : 'downloading')
            : osStatus === 'downloaded'
              ? 'ready'
              : osStatus === 'applying'
                ? 'applying'
                : osStatus === 'error'
                  ? 'error'
                  : 'downloading'
        }
        progress={osProgress}
        version={osAvailableVersion}
        notes={osNotes}
        error={osError}
        onInstall={handleOsApply}
        onClose={closeInstaller}
        onRetry={retryInstaller}
      />
    </>
  );
};

export default DrawerMenu;





