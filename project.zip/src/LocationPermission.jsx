/*import React, { useState, useEffect, useRef } from 'react';

const LocationPermission = ({ isOpen, onClose, onGrantPermission }) => {
  const [isChecking, setIsChecking] = useState(false);
  const [error, setError] = useState('');
  const timeoutRef = useRef(null);
  const permissionHandledRef = useRef(false);

  // Сброс состояния при открытии/закрытии диалога
  useEffect(() => {
    if (isOpen) {
      console.log('📍 LocationPermission: Dialog opened');
      setError('');
      setIsChecking(false);
      permissionHandledRef.current = false;
      
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    } else {
      console.log('📍 LocationPermission: Dialog closed');
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    }
  }, [isOpen]);

  // Обработчики событий от Android
  useEffect(() => {
    const handleAndroidPermissionResult = (event) => {
      const granted = event.detail;
      console.log('📍 LocationPermission: Android permission result received:', granted);
      
      if (granted && !permissionHandledRef.current) {
        console.log('📍 LocationPermission: Permission granted, waiting for location data...');
        permissionHandledRef.current = true;
        
        // Устанавливаем таймаут на получение местоположения
        timeoutRef.current = setTimeout(() => {
          console.log('📍 LocationPermission: Location data timeout after permission grant');
          setError('Не удалось получить местоположение. Проверьте GPS и интернет.');
          setIsChecking(false);
          permissionHandledRef.current = false;
        }, 15000);
      } else if (!granted) {
        console.log('📍 LocationPermission: Permission denied by user');
        setError('Доступ к местоположению запрещен в настройках Android');
        setIsChecking(false);
        permissionHandledRef.current = false;
      }
    };

    const handleAndroidLocationData = (event) => {
      const locationData = event.detail;
      console.log('📍 LocationPermission: Android location data received:', locationData);
      
      // Очищаем таймаут
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
      
      if (locationData.granted && locationData.latitude !== 0 && locationData.longitude !== 0) {
        console.log('📍 LocationPermission: Valid location received, closing dialog');
        const location = {
          latitude: locationData.latitude,
          longitude: locationData.longitude,
          accuracy: locationData.accuracy || 0,
          timestamp: locationData.timestamp || Date.now(),
          source: locationData.source || 'android'
        };
        console.log('📍 LocationPermission: Calling onGrantPermission with:', location);
        onGrantPermission(location);
        setIsChecking(false);
        onClose();
      } else if (locationData.granted) {
        // Разрешение есть, но местоположение не получено
        console.log('📍 LocationPermission: Permission granted but no location data');
        setError('Не удалось определить ваше местоположение. Проверьте GPS и интернет.');
        setIsChecking(false);
        permissionHandledRef.current = false;
      }
    };

    const handleAndroidLocationError = (event) => {
      const errorData = event.detail;
      console.log('📍 LocationPermission: Android location error received:', errorData);
      
      // Очищаем таймаут
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
      
      let errorMessage = 'Ошибка получения местоположения';
      if (errorData.errorMessage) {
        errorMessage += `: ${errorData.errorMessage}`;
      }
      if (errorData.errorCode) {
        errorMessage += ` (код: ${errorData.errorCode})`;
      }
      
      setError(errorMessage);
      setIsChecking(false);
      permissionHandledRef.current = false;
    };

    if (isOpen) {
      console.log('📍 LocationPermission: Adding event listeners');
      window.addEventListener('androidLocationPermissionResult', handleAndroidPermissionResult);
      window.addEventListener('androidLocationUpdate', handleAndroidLocationData);
      window.addEventListener('androidLocationError', handleAndroidLocationError);
    }

    return () => {
      console.log('📍 LocationPermission: Removing event listeners');
      window.removeEventListener('androidLocationPermissionResult', handleAndroidPermissionResult);
      window.removeEventListener('androidLocationUpdate', handleAndroidLocationData);
      window.removeEventListener('androidLocationError', handleAndroidLocationError);
      
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    };
  }, [isOpen, onGrantPermission, onClose]);

  const handleAndroidPermission = () => {
    console.log('📍 LocationPermission: Starting Android permission flow');
    setIsChecking(true);
    setError('');
    permissionHandledRef.current = false;
    
    // Общий таймаут на случай, если ничего не произойдет
    timeoutRef.current = setTimeout(() => {
      console.log('📍 LocationPermission: Overall timeout - no response from Android');
      setError('Нет ответа от системы. Попробуйте еще раз или используйте браузерный метод.');
      setIsChecking(false);
      permissionHandledRef.current = false;
    }, 20000);

    // Проверяем доступность Android API
    if (!window.Android) {
      console.error('📍 LocationPermission: Android interface not available');
      setError('Android API не доступен');
      setIsChecking(false);
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
      return;
    }

    if (typeof window.Android.requestLocationPermission !== 'function') {
      console.error('📍 LocationPermission: requestLocationPermission method not available');
      setError('Метод запроса местоположения не доступен');
      setIsChecking(false);
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
      return;
    }

    console.log('📍 LocationPermission: Calling Android.requestLocationPermission()');
    
    // Вызываем нативный метод
    try {
      window.Android.requestLocationPermission();
      console.log('📍 LocationPermission: Android.requestLocationPermission() called successfully');
    } catch (error) {
      console.error('📍 LocationPermission: Error calling Android method:', error);
      setError('Ошибка вызова Android API');
      setIsChecking(false);
      permissionHandledRef.current = false;
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    }
  };

  const handleBrowserPermission = async () => {
    console.log('📍 LocationPermission: Starting browser permission flow');
    setIsChecking(true);
    setError('');
    permissionHandledRef.current = false;

    try {
      if (!navigator.geolocation) {
        throw new Error('Геолокация не поддерживается вашим браузером');
      }

      console.log('📍 LocationPermission: Calling navigator.geolocation.getCurrentPosition');
      
      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          timeout: 10000,
          maximumAge: 60000,
          enableHighAccuracy: true
        });
      });

      console.log('📍 LocationPermission: Browser location obtained successfully:', position.coords);
      
      const location = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy,
        timestamp: position.timestamp || Date.now(),
        source: 'browser'
      };
      
      console.log('📍 LocationPermission: Calling onGrantPermission with:', location);
      onGrantPermission(location);
      setIsChecking(false);
      onClose();
    } catch (err) {
      console.error('📍 LocationPermission: Browser location error:', err);
      setIsChecking(false);
      permissionHandledRef.current = false;
      
      let errorMessage = 'Произошла ошибка при получении местоположения';
      if (err.code === err.PERMISSION_DENIED) {
        errorMessage = 'Доступ к местоположению запрещен. Пожалуйста, разрешите доступ в настройках браузера.';
      } else if (err.code === err.POSITION_UNAVAILABLE) {
        errorMessage = 'Информация о местоположении недоступна.';
      } else if (err.code === err.TIMEOUT) {
        errorMessage = 'Время ожидания запроса местоположения истекло.';
      } else if (err.message) {
        errorMessage = err.message;
      }
      
      setError(errorMessage);
    }
  };

  const handleGrantPermission = () => {
    console.log('📍 LocationPermission: Grant permission clicked, Android available:', !!window.Android);
    
    // Проверяем, доступен ли Android WebAppInterface
    if (window.Android && typeof window.Android.requestLocationPermission === 'function') {
      console.log('📍 LocationPermission: Using Android method');
      handleAndroidPermission();
    } else {
      console.log('📍 LocationPermission: Using browser method');
      handleBrowserPermission();
    }
  };

  const handleManualInput = () => {
    console.log('📍 LocationPermission: Manual input selected');
    // Очищаем таймаут при ручном вводе
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    onClose();
  };

  const handleRetry = () => {
    console.log('📍 LocationPermission: Retry clicked');
    setError('');
    setIsChecking(false);
    permissionHandledRef.current = false;
    
    // Очищаем предыдущий таймаут
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    
    handleGrantPermission();
  };

  const handleClose = () => {
    console.log('📍 LocationPermission: Close clicked');
    // Очищаем таймаут при закрытии
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    onClose();
  };

  if (!isOpen) {
    console.log('📍 LocationPermission: Dialog not open, returning null');
    return null;
  }

  console.log('📍 LocationPermission: Rendering dialog, isChecking:', isChecking, 'error:', error);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full">
        
        <div className="bg-blue-600 dark:bg-blue-700 p-6 rounded-t-lg">
          <div className="flex items-center justify-center space-x-3">
            <div className="w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </div>
            <h2 className="text-xl font-bold text-white text-center">
              Доступ к местоположению
            </h2>
          </div>
        </div>

        
        <div className="p-6 space-y-4">
          <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">
            Для предоставления точных прогнозов погоды в вашем регионе, 
            приложению требуется доступ к вашему местоположению.
          </p>

          {window.Android && (
            <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
              <div className="flex items-start space-x-3">
                <svg className="w-5 h-5 text-green-600 dark:text-green-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-sm text-green-800 dark:text-green-300">
                  Будет открыт системный диалог Android для запроса разрешения на доступ к местоположению.
                </p>
              </div>
            </div>
          )}

          <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
            <div className="flex items-start space-x-3">
              <svg className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <p className="text-sm text-blue-800 dark:text-blue-300">
                Ваше местоположение используется только для показа погоды и не сохраняется на серверах.
              </p>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-lg">
              <div className="flex items-start space-x-3">
                <svg className="w-5 h-5 text-red-600 dark:text-red-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div className="flex-1">
                  <p className="text-sm text-red-800 dark:text-red-300 font-medium mb-1">
                    Ошибка
                  </p>
                  <p className="text-sm text-red-700 dark:text-red-400 mb-2">
                    {error}
                  </p>
                  <button
                    onClick={handleRetry}
                    className="px-3 py-1 text-xs bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
                    disabled={isChecking}
                  >
                    Попробовать снова
                  </button>
                </div>
              </div>
            </div>
          )}

          {isChecking && !error && (
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
              <div className="flex items-center space-x-3">
                <svg className="animate-spin h-5 w-5 text-blue-600 dark:text-blue-400" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <p className="text-sm text-blue-800 dark:text-blue-300">
                  {window.Android ? 'Ожидание ответа от системы Android...' : 'Определение местоположения...'}
                </p>
              </div>
            </div>
          )}
        </div>

        
        <div className="border-t border-gray-200 dark:border-gray-700 p-4 bg-gray-50 dark:bg-gray-700 rounded-b-lg">
          <div className="flex flex-col space-y-3 sm:flex-row sm:space-y-0 sm:space-x-3">
            <button
              onClick={handleManualInput}
              className="flex-1 px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-200 dark:bg-gray-600 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
              disabled={isChecking}
            >
              Ввести вручную
            </button>
            <button
              onClick={handleGrantPermission}
              disabled={isChecking}
              className="flex-1 px-4 py-2 text-sm font-medium text-white bg-blue-600 dark:bg-blue-700 rounded-lg hover:bg-blue-700 dark:hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
            >
              {isChecking ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  <span>Определение...</span>
                </>
              ) : (
                <span>{window.Android ? 'Разрешить в Android' : 'Разрешить в браузере'}</span>
              )}
            </button>
          </div>
          
          <div className="mt-3 text-center">
            <button
              onClick={handleClose}
              className="text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
              disabled={isChecking}
            >
              Настроить позже
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LocationPermission;*/

import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';

const LocationPermission = ({ isOpen, onClose, onGrantPermission, onRemindLater }) => {
  const { t } = useTranslation();
  const [isChecking, setIsChecking] = useState(false);
  const [error, setError] = useState('');
  const timeoutRef = useRef(null);
  const permissionHandledRef = useRef(false);

  // Сброс состояния при открытии/закрытии диалога
  useEffect(() => {
    if (isOpen) {
      console.log('📍 LocationPermission: Dialog opened');
      setError('');
      setIsChecking(false);
      permissionHandledRef.current = false;
      
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    } else {
      console.log('📍 LocationPermission: Dialog closed');
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    }
  }, [isOpen]);

  // Обработчики событий от Android
  useEffect(() => {
    const handleAndroidPermissionResult = (event) => {
      const granted = event.detail;
      console.log('📍 LocationPermission: Android permission result received:', granted);
      
      if (granted && !permissionHandledRef.current) {
        console.log('📍 LocationPermission: Permission granted, waiting for location data...');
        permissionHandledRef.current = true;
        
        // Устанавливаем таймаут на получение местоположения
        timeoutRef.current = setTimeout(() => {
          console.log('📍 LocationPermission: Location data timeout after permission grant');
          setError(t('location.error.timeoutAfterPermission'));
          setIsChecking(false);
          permissionHandledRef.current = false;
        }, 15000);
      } else if (!granted) {
        console.log('📍 LocationPermission: Permission denied by user');
        setError(t('location.error.permissionDeniedAndroid'));
        setIsChecking(false);
        permissionHandledRef.current = false;
      }
    };

    const handleAndroidLocationData = (event) => {
      const locationData = event.detail;
      console.log('📍 LocationPermission: Android location data received:', locationData);
      
      // Очищаем таймаут
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
      
      if (locationData.granted && locationData.latitude !== 0 && locationData.longitude !== 0) {
        console.log('📍 LocationPermission: Valid location received, closing dialog');
        const location = {
          latitude: locationData.latitude,
          longitude: locationData.longitude,
          accuracy: locationData.accuracy || 0,
          timestamp: locationData.timestamp || Date.now(),
          source: locationData.source || 'android'
        };
        console.log('📍 LocationPermission: Calling onGrantPermission with:', location);
        onGrantPermission(location);
        setIsChecking(false);
        onClose();
      } else if (locationData.granted) {
        // Разрешение есть, но местоположение не получено
        console.log('📍 LocationPermission: Permission granted but no location data');
        setError(t('location.error.noLocationData'));
        setIsChecking(false);
        permissionHandledRef.current = false;
      }
    };

    const handleAndroidLocationError = (event) => {
      const errorData = event.detail;
      console.log('📍 LocationPermission: Android location error received:', errorData);
      
      // Очищаем таймаут
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
      
      let errorMessage = t('location.error.general');
      if (errorData.errorMessage) {
        errorMessage += `: ${errorData.errorMessage}`;
      }
      if (errorData.errorCode) {
        errorMessage += ` (${t('location.error.code')}: ${errorData.errorCode})`;
      }
      
      setError(errorMessage);
      setIsChecking(false);
      permissionHandledRef.current = false;
    };

    if (isOpen) {
      console.log('📍 LocationPermission: Adding event listeners');
      window.addEventListener('androidLocationPermissionResult', handleAndroidPermissionResult);
      window.addEventListener('androidLocationUpdate', handleAndroidLocationData);
      window.addEventListener('androidLocationError', handleAndroidLocationError);
    }

    return () => {
      console.log('📍 LocationPermission: Removing event listeners');
      window.removeEventListener('androidLocationPermissionResult', handleAndroidPermissionResult);
      window.removeEventListener('androidLocationUpdate', handleAndroidLocationData);
      window.removeEventListener('androidLocationError', handleAndroidLocationError);
      
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    };
  }, [isOpen, onGrantPermission, onClose, t]);

  const handleAndroidPermission = () => {
    console.log('📍 LocationPermission: Starting Android permission flow');
    setIsChecking(true);
    setError('');
    permissionHandledRef.current = false;
    
    // Общий таймаут на случай, если ничего не произойдет
    timeoutRef.current = setTimeout(() => {
      console.log('📍 LocationPermission: Overall timeout - no response from Android');
      setError(t('location.error.noResponse'));
      setIsChecking(false);
      permissionHandledRef.current = false;
    }, 20000);

    // Проверяем доступность Android API
    if (!window.Android) {
      console.error('📍 LocationPermission: Android interface not available');
      setError(t('location.error.androidApiUnavailable'));
      setIsChecking(false);
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
      return;
    }

    if (typeof window.Android.requestLocationPermission !== 'function') {
      console.error('📍 LocationPermission: requestLocationPermission method not available');
      setError(t('location.error.locationMethodUnavailable'));
      setIsChecking(false);
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
      return;
    }

    console.log('📍 LocationPermission: Calling Android.requestLocationPermission()');
    
    // Вызываем нативный метод
    try {
      window.Android.requestLocationPermission();
      console.log('📍 LocationPermission: Android.requestLocationPermission() called successfully');
    } catch (error) {
      console.error('📍 LocationPermission: Error calling Android method:', error);
      setError(t('location.error.androidApiError'));
      setIsChecking(false);
      permissionHandledRef.current = false;
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    }
  };

  const handleBrowserPermission = async () => {
    console.log('📍 LocationPermission: Starting browser permission flow');
    setIsChecking(true);
    setError('');
    permissionHandledRef.current = false;

    try {
      if (!navigator.geolocation) {
        throw new Error(t('location.error.geolocationUnsupported'));
      }

      console.log('📍 LocationPermission: Calling navigator.geolocation.getCurrentPosition');
      
      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          timeout: 10000,
          maximumAge: 60000,
          enableHighAccuracy: true
        });
      });

      console.log('📍 LocationPermission: Browser location obtained successfully:', position.coords);
      
      const location = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy,
        timestamp: position.timestamp || Date.now(),
        source: 'browser'
      };
      
      console.log('📍 LocationPermission: Calling onGrantPermission with:', location);
      onGrantPermission(location);
      setIsChecking(false);
      onClose();
    } catch (err) {
      console.error('📍 LocationPermission: Browser location error:', err);
      setIsChecking(false);
      permissionHandledRef.current = false;
      
      let errorMessage = t('location.error.general');
      if (err.code === err.PERMISSION_DENIED) {
        errorMessage = t('location.error.permissionDeniedBrowser');
      } else if (err.code === err.POSITION_UNAVAILABLE) {
        errorMessage = t('location.error.positionUnavailable');
      } else if (err.code === err.TIMEOUT) {
        errorMessage = t('location.error.timeout');
      } else if (err.message) {
        errorMessage = err.message;
      }
      
      setError(errorMessage);
    }
  };

  const handleGrantPermission = () => {
    console.log('📍 LocationPermission: Grant permission clicked, Android available:', !!window.Android);
    
    // Проверяем, доступен ли Android WebAppInterface
    if (window.Android && typeof window.Android.requestLocationPermission === 'function') {
      console.log('📍 LocationPermission: Using Android method');
      handleAndroidPermission();
    } else {
      console.log('📍 LocationPermission: Using browser method');
      handleBrowserPermission();
    }
  };

  const handleManualInput = () => {
    console.log('📍 LocationPermission: Manual input selected');
    // Очищаем таймаут при ручном вводе
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    onClose();
  };

  const handleRemindLater = () => {
    console.log('📍 LocationPermission: Remind later selected');
    // Очищаем таймаут
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    if (onRemindLater) {
      onRemindLater();
    }
    onClose();
  };

  const handleRetry = () => {
    console.log('📍 LocationPermission: Retry clicked');
    setError('');
    setIsChecking(false);
    permissionHandledRef.current = false;
    
    // Очищаем предыдущий таймаут
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    
    handleGrantPermission();
  };

  const handleClose = () => {
    console.log('📍 LocationPermission: Close clicked');
    // Очищаем таймаут при закрытии
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    onClose();
  };

  if (!isOpen) {
    console.log('📍 LocationPermission: Dialog not open, returning null');
    return null;
  }

  console.log('📍 LocationPermission: Rendering dialog, isChecking:', isChecking, 'error:', error);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full">
        {/* Header */}
        <div className="bg-blue-600 dark:bg-blue-700 p-6 rounded-t-lg">
          <div className="flex items-center justify-center space-x-3">
            <div className="w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </div>
            <h2 className="text-xl font-bold text-white text-center">
              {t('location.title')}
            </h2>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">
            {t('location.description')}
          </p>

          {window.Android && (
            <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
              <div className="flex items-start space-x-3">
                <svg className="w-5 h-5 text-green-600 dark:text-green-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-sm text-green-800 dark:text-green-300">
                  {t('location.androidInfo')}
                </p>
              </div>
            </div>
          )}

          <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
            <div className="flex items-start space-x-3">
              <svg className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <p className="text-sm text-blue-800 dark:text-blue-300">
                {t('location.privacyInfo')}
              </p>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-lg">
              <div className="flex items-start space-x-3">
                <svg className="w-5 h-5 text-red-600 dark:text-red-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div className="flex-1">
                  <p className="text-sm text-red-800 dark:text-red-300 font-medium mb-1">
                    {t('location.error.title')}
                  </p>
                  <p className="text-sm text-red-700 dark:text-red-400 mb-2">
                    {error}
                  </p>
                  <button
                    onClick={handleRetry}
                    className="px-3 py-1 text-xs bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
                    disabled={isChecking}
                  >
                    {t('location.retry')}
                  </button>
                </div>
              </div>
            </div>
          )}

          {isChecking && !error && (
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
              <div className="flex items-center space-x-3">
                <svg className="animate-spin h-5 w-5 text-blue-600 dark:text-blue-400" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <p className="text-sm text-blue-800 dark:text-blue-300">
                  {window.Android ? t('location.checking.android') : t('location.checking.browser')}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-gray-200 dark:border-gray-700 p-4 bg-gray-50 dark:bg-gray-700 rounded-b-lg">
          <div className="flex flex-col space-y-3 sm:flex-row sm:space-y-0 sm:space-x-3">
            <button
              onClick={handleManualInput}
              className="flex-1 px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-200 dark:bg-gray-600 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
              disabled={isChecking}
            >
              {t('location.manualInput')}
            </button>
            <button
              onClick={handleGrantPermission}
              disabled={isChecking}
              className="flex-1 px-4 py-2 text-sm font-medium text-white bg-blue-600 dark:bg-blue-700 rounded-lg hover:bg-blue-700 dark:hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
            >
              {isChecking ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  <span>{t('location.detecting')}</span>
                </>
              ) : (
                <span>
                  {window.Android ? t('location.grant.android') : t('location.grant.browser')}
                </span>
              )}
            </button>
          </div>
          
          <div className="mt-3 text-center">
            <button
              onClick={handleRemindLater}
              className="text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
              disabled={isChecking}
            >
              {t('location.remindLater')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LocationPermission;