/*import { WEATHER_CODE_TO_TYPE } from './WeatherDataMapper';

class OpenWeatherMapProvider {
  constructor() {
    this.apiKey = "06116e75d37507cce73c461785ff4c9b";
    this.astronomyApiKey = "829bd488-dbf2-4b29-8818-a5dbf0dda8bf"; // Получите на https://astronomyapi.com
    this.baseUrl = 'https://api.openweathermap.org/data/2.5';
    this.airQualityUrl = 'http://api.openweathermap.org/data/2.5/air_pollution';
    this.geoUrl = 'https://api.openweathermap.org/geo/1.0';
    this.astronomyUrl = 'https://api.astronomyapi.com/api/v2/bodies/positions';
  }

  // Конвертация кодов погоды OpenWeatherMap в наши коды
  convertWeatherCode(owmCode) {
    const codeMap = {
      200: 1273, 201: 1276, 202: 1279, 210: 1087, 211: 1087, 212: 1282,
      221: 1087, 230: 1273, 231: 1276, 232: 1279, 300: 1072, 301: 1072,
      302: 1153, 310: 1063, 311: 1063, 312: 1183, 313: 1186, 314: 1192,
      321: 1072, 500: 1063, 501: 1063, 502: 1189, 503: 1192, 504: 1195,
      511: 1066, 520: 1180, 521: 1183, 522: 1189, 531: 1192, 600: 1066,
      601: 1114, 602: 1117, 611: 1066, 612: 1069, 613: 1069, 615: 1066,
      616: 1069, 620: 1066, 621: 1114, 622: 1117, 701: 1135, 711: 1147,
      721: 1147, 731: 1147, 741: 1135, 751: 1147, 761: 1147, 762: 1147,
      771: 1087, 781: 1282, 800: 1000, 801: 1003, 802: 1006, 803: 1009,
      804: 1009,
    };
    return codeMap[owmCode] || 1000;
  }

  getWindDirection(degrees) {
    const directions = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
    const index = Math.round(degrees / 22.5) % 16;
    return directions[index];
  }

  kelvinToCelsius(kelvin) {
    return kelvin - 273.15;
  }

  kelvinToFahrenheit(kelvin) {
    return (kelvin - 273.15) * 9/5 + 32;
  }

  // Получение данных о луне из Astronomy API
  async getMoonData(lat, lon, date) {
    try {
      const fromDate = new Date(date);
      const toDate = new Date(date);
      toDate.setDate(toDate.getDate() + 7); // Данные на 7 дней вперед

      const response = await fetch(this.astronomyUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${btoa(this.astronomyApiKey + ':')}`
        },
        body: JSON.stringify({
          latitude: lat,
          longitude: lon,
          elevation: 0,
          from_date: fromDate.toISOString().split('T')[0],
          to_date: toDate.toISOString().split('T')[0],
          time: '12:00:00',
          bodies: ['moon']
        })
      });

      if (!response.ok) throw new Error('Astronomy API failed');

      const data = await response.json();
      return data.data;
    } catch (error) {
      console.error('Moon data error:', error);
      // Резервный расчет если API недоступно
      return this.calculateBackupMoonData(lat, lon, date);
    }
  }

  // Резервный расчет фаз луны
  calculateBackupMoonData(lat, lon, date) {
    const dates = [];
    for (let i = 0; i < 7; i++) {
      const currentDate = new Date(date);
      currentDate.setDate(currentDate.getDate() + i);
      
      const julianDate = this.toJulianDate(currentDate);
      const phase = this.calculateMoonPhase(julianDate);
      
      dates.push({
        date: currentDate.toISOString().split('T')[0],
        phase: phase,
        phaseName: this.getMoonPhaseName(phase)
      });
    }
    return dates;
  }

  toJulianDate(date) {
    return date.getTime() / 86400000 + 2440587.5;
  }

  calculateMoonPhase(julianDate) {
    const phase = (julianDate % 29.53) / 29.53;
    
    if (phase < 0.03 || phase > 0.97) return 'new_moon';
    if (phase < 0.22) return 'waxing_crescent';
    if (phase < 0.28) return 'first_quarter';
    if (phase < 0.47) return 'waxing_gibbous';
    if (phase < 0.53) return 'full_moon';
    if (phase < 0.72) return 'waning_gibbous';
    if (phase < 0.78) return 'last_quarter';
    return 'waning_crescent';
  }

  getMoonPhaseName(phaseCode) {
    const phases = {
      'new_moon': 'Новолуние',
      'waxing_crescent': 'Растущий серп',
      'first_quarter': 'Первая четверть',
      'waxing_gibbous': 'Растущая луна',
      'full_moon': 'Полнолуние',
      'waning_gibbous': 'Убывающая луна',
      'last_quarter': 'Последняя четверть',
      'waning_crescent': 'Убывающий серп'
    };
    return phases[phaseCode] || 'Неизвестно';
  }

  // Нормализация данных для единого формата
  async normalizeWeatherData(currentData, forecastData, hourlyData, airQualityData = null, lat, lon) {
    if (!currentData) return null;

    const current = currentData;
    const forecastList = forecastData?.list || [];
    const hourlyList = hourlyData?.list || [];

    // Получаем данные о луне
    const moonData = await this.getMoonData(lat, lon, new Date());

    // Текущая погода
    const normalizedCurrent = {
      temperature: Math.round(this.kelvinToCelsius(current.main.temp)),
      feelsLike: Math.round(this.kelvinToCelsius(current.main.feels_like)),
      humidity: current.main.humidity,
      pressure: Math.round(current.main.pressure * 0.750062),
      windSpeed: Math.round(current.wind.speed * 3.6),
      windDirection: this.getWindDirection(current.wind.deg),
      windGust: current.wind.gust ? Math.round(current.wind.gust * 3.6) : null,
      uvIndex: 0,
      visibility: current.visibility / 1000,
      cloudCover: current.clouds.all,
      weatherCode: this.convertWeatherCode(current.weather[0].id),
      weatherType: this.getWeatherType(this.convertWeatherCode(current.weather[0].id)),
      description: current.weather[0].description,
      icon: current.weather[0].icon,
      sunrise: new Date(current.sys.sunrise * 1000),
      sunset: new Date(current.sys.sunset * 1000),
      timestamp: new Date(current.dt * 1000)
    };

    // Суточный прогноз с данными о луне
    const normalizedDaily = forecastList.slice(0, 7).map((day, index) => {
      const dateStr = new Date(day.dt * 1000).toISOString().split('T')[0];
      const moonInfo = moonData.find(m => m.date === dateStr) || 
                       { phase: 'unknown', phaseName: 'Неизвестно' };

      return {
        date: new Date(day.dt * 1000),
        tempMin: Math.round(this.kelvinToCelsius(day.temp.min)),
        tempMax: Math.round(this.kelvinToCelsius(day.temp.max)),
        weatherCode: this.convertWeatherCode(day.weather[0].id),
        weatherType: this.getWeatherType(this.convertWeatherCode(day.weather[0].id)),
        precipitation: day.pop * 100,
        humidity: day.humidity,
        windSpeed: Math.round(day.speed * 3.6),
        windDirection: this.getWindDirection(day.deg),
        sunrise: new Date(day.sunrise * 1000),
        sunset: new Date(day.sunset * 1000),
        moonPhase: moonInfo.phase,
        moonPhaseName: moonInfo.phaseName,
        uvIndex: 0
      };
    });

    // Почасовой прогноз
    const normalizedHourly = hourlyList.slice(0, 24).map(hour => ({
      time: new Date(hour.dt * 1000),
      temperature: Math.round(this.kelvinToCelsius(hour.main.temp)),
      feelsLike: Math.round(this.kelvinToCelsius(hour.main.feels_like)),
      weatherCode: this.convertWeatherCode(hour.weather[0].id),
      weatherType: this.getWeatherType(this.convertWeatherCode(hour.weather[0].id)),
      precipitation: hour.pop * 100,
      humidity: hour.main.humidity,
      windSpeed: Math.round(hour.wind.speed * 3.6),
      windDirection: this.getWindDirection(hour.wind.deg),
      cloudCover: hour.clouds.all
    }));

    // Качество воздуха
    let normalizedAirQuality = null;
    if (airQualityData) {
      const aq = airQualityData.list[0];
      normalizedAirQuality = {
        aqi: aq.main.aqi,
        pm25: aq.components.pm2_5,
        pm10: aq.components.pm10,
        so2: aq.components.so2,
        no2: aq.components.no2,
        o3: aq.components.o3,
        co: aq.components.co
      };
    }

    return {
      current: normalizedCurrent,
      daily: normalizedDaily,
      hourly: normalizedHourly,
      airQuality: normalizedAirQuality,
      location: {
        name: currentData.name,
        lat: currentData.coord.lat,
        lon: currentData.coord.lon
      }
    };
  }

  async searchLocations(query, lang = 'ru') {
    try {
      const response = await fetch(
        `${this.geoUrl}/direct?q=${encodeURIComponent(query)}&limit=5&appid=${this.apiKey}&lang=${lang}`
      );
      
      if (!response.ok) throw new Error('Location search failed');
      
      const data = await response.json();
      return data.map(location => ({
        name: location.name,
        country: location.country,
        state: location.state,
        lat: location.lat,
        lon: location.lon
      }));
    } catch (error) {
      console.error('Search locations error:', error);
      throw error;
    }
  }

  async getWeather(location, lang = 'ru', days = 3) {
    try {
      let lat, lon, locationName;

      if (typeof location === 'object') {
        lat = location.lat;
        lon = location.lon;
        locationName = location.name;
      } else {
        const locations = await this.searchLocations(location, lang);
        if (locations.length === 0) throw new Error('Location not found');
        lat = locations[0].lat;
        lon = locations[0].lon;
        locationName = locations[0].name;
      }

      // Параллельные запросы
      const [currentResponse, forecastResponse, hourlyResponse, airQualityResponse] = await Promise.all([
        fetch(`${this.baseUrl}/weather?lat=${lat}&lon=${lon}&appid=${this.apiKey}&lang=${lang}`),
        fetch(`${this.baseUrl}/forecast/daily?lat=${lat}&lon=${lon}&cnt=${days}&appid=${this.apiKey}&lang=${lang}`),
        fetch(`${this.baseUrl}/forecast?lat=${lat}&lon=${lon}&appid=${this.apiKey}&lang=${lang}`),
        fetch(`${this.airQualityUrl}?lat=${lat}&lon=${lon}&appid=${this.apiKey}`)
      ]);

      if (!currentResponse.ok || !forecastResponse.ok) {
        throw new Error('Weather data fetch failed');
      }

      const currentData = await currentResponse.json();
      const forecastData = await forecastResponse.json();
      const hourlyData = await hourlyResponse.json();
      const airQualityData = airQualityResponse.ok ? await airQualityResponse.json() : null;

      return await this.normalizeWeatherData(
        currentData, 
        forecastData, 
        hourlyData, 
        airQualityData, 
        lat, 
        lon
      );
    } catch (error) {
      console.error('Get weather error:', error);
      throw error;
    }
  }

  getWeatherType(code) {
    return WEATHER_CODE_TO_TYPE[code] || 'clear';
  }
}

export default OpenWeatherMapProvider;*/
