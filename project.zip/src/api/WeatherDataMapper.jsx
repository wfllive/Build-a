export const WEATHER_TYPES = {
  CLEAR: 'clear',
  PARTLY_CLOUDY: 'partly-cloudy',
  CLOUDY: 'cloudy',
  RAINY: 'rainy',
  SNOWY: 'snowy',
  THUNDERSTORM: 'thunderstorm',
  MIST: 'mist',
  FOG: 'fog'
};

export const WEATHER_CODE_TO_TYPE = {
  1000: WEATHER_TYPES.CLEAR,
  1003: WEATHER_TYPES.PARTLY_CLOUDY,
  1006: WEATHER_TYPES.CLOUDY,
  1009: WEATHER_TYPES.CLOUDY,
  1030: WEATHER_TYPES.MIST,
  1063: WEATHER_TYPES.RAINY,
  1066: WEATHER_TYPES.SNOWY,
  1069: WEATHER_TYPES.SNOWY,
  1072: WEATHER_TYPES.RAINY,
  1087: WEATHER_TYPES.THUNDERSTORM,
  1114: WEATHER_TYPES.SNOWY,
  1117: WEATHER_TYPES.SNOWY,
  1135: WEATHER_TYPES.FOG,
  1147: WEATHER_TYPES.FOG,
  1150: WEATHER_TYPES.RAINY,
  1153: WEATHER_TYPES.RAINY,
  1168: WEATHER_TYPES.RAINY,
  1171: WEATHER_TYPES.RAINY,
  1180: WEATHER_TYPES.RAINY,
  1183: WEATHER_TYPES.RAINY,
  1186: WEATHER_TYPES.RAINY,
  1189: WEATHER_TYPES.RAINY,
  1192: WEATHER_TYPES.RAINY,
  1195: WEATHER_TYPES.RAINY,
  1198: WEATHER_TYPES.RAINY,
  1201: WEATHER_TYPES.RAINY,
  1204: WEATHER_TYPES.SNOWY,
  1207: WEATHER_TYPES.SNOWY,
  1210: WEATHER_TYPES.SNOWY,
  1213: WEATHER_TYPES.SNOWY,
  1216: WEATHER_TYPES.SNOWY,
  1219: WEATHER_TYPES.SNOWY,
  1222: WEATHER_TYPES.SNOWY,
  1225: WEATHER_TYPES.SNOWY,
  1237: WEATHER_TYPES.SNOWY,
  1240: WEATHER_TYPES.RAINY,
  1243: WEATHER_TYPES.RAINY,
  1246: WEATHER_TYPES.RAINY,
  1249: WEATHER_TYPES.SNOWY,
  1252: WEATHER_TYPES.SNOWY,
  1255: WEATHER_TYPES.SNOWY,
  1258: WEATHER_TYPES.SNOWY,
  1261: WEATHER_TYPES.SNOWY,
  1264: WEATHER_TYPES.SNOWY,
  1273: WEATHER_TYPES.THUNDERSTORM,
  1276: WEATHER_TYPES.THUNDERSTORM,
  1279: WEATHER_TYPES.THUNDERSTORM,
  1282: WEATHER_TYPES.THUNDERSTORM
};

export const WeatherDataUtils = {
  getSunrise: (forecastData) => {
    return forecastData?.forecast?.forecastday?.[0]?.astro?.sunrise || '';
  },

  getSunset: (forecastData) => {
    return forecastData?.forecast?.forecastday?.[0]?.astro?.sunset || '';
  },

  getMoonrise: (forecastData) => {
    return forecastData?.forecast?.forecastday?.[0]?.astro?.moonrise || '';
  },

  getMoonset: (forecastData) => {
    return forecastData?.forecast?.forecastday?.[0]?.astro?.moonset || '';
  },

  getMoonPhase: (forecastData) => {
    return forecastData?.forecast?.forecastday?.[0]?.astro?.moon_phase || '';
  },

  getMoonIllumination: (forecastData) => {
    return forecastData?.forecast?.forecastday?.[0]?.astro?.moon_illumination || 0;
  },

  getHourlyForecast: (forecastData) => {
    return forecastData?.forecast?.forecastday?.[0]?.hour || [];
  },

  getDailyForecast: (forecastData) => {
    return forecastData?.forecast?.forecastday || [];
  },

  getCurrentTemp: (weatherData, units = 'metric') => {
    if (!weatherData?.current) return null;
    return units === 'metric' ? weatherData.current.temp_c : weatherData.current.temp_f;
  },

  getFeelsLikeTemp: (weatherData, units = 'metric') => {
    if (!weatherData?.current) return null;
    return units === 'metric' ? weatherData.current.feelslike_c : weatherData.current.feelslike_f;
  },

  getCurrentCondition: (weatherData) => {
    return weatherData?.current?.condition || {};
  },

  getCurrentHumidity: (weatherData) => {
    return weatherData?.current?.humidity || 0;
  },

  getCurrentWindSpeed: (weatherData) => {
    return weatherData?.current?.wind_kph || 0;
  },

  getCurrentWindDirection: (weatherData) => {
    return weatherData?.current?.wind_dir || '';
  },

  getCurrentPressure: (weatherData) => {
    return weatherData?.current?.pressure_mb || 0;
  },

  getCurrentPrecipitation: (weatherData) => {
    return weatherData?.current?.precip_mm || 0;
  },

  getCurrentUV: (weatherData) => {
    return weatherData?.current?.uv || 0;
  },

  getCurrentAirQuality: (weatherData) => {
    return weatherData?.current?.air_quality || null;
  }
};