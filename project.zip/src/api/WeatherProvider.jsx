/*import { WEATHER_CODE_TO_TYPE } from './WeatherDataMapper';

//const apiKey = window.AndroidApi.getApiKey();

class WeatherProvider {
  constructor() {
    this.apiKey = "3fea683678784107a07174534221506";
  //  this.apiKey = apiKey;
    this.baseUrl = 'https://api.weatherapi.com/v1';
  }

  normalizeWeatherData(data) {
    if (!data) return null;

    return {
      location: {
        name: data.location.name,
        country: data.location.country,
        region: data.location.region,
        lat: data.location.lat,
        lon: data.location.lon,
        tz_id: data.location.tz_id,
        localtime: data.location.localtime
      },
      current: {
        temp_c: data.current.temp_c,
        temp_f: data.current.temp_f,
        condition: {
          text: data.current.condition.text,
          code: data.current.condition.code
        },
        feelslike_c: data.current.feelslike_c,
        feelslike_f: data.current.feelslike_f,
        humidity: data.current.humidity,
        wind_kph: data.current.wind_kph,
        wind_dir: data.current.wind_dir,
        pressure_mb: data.current.pressure_mb,
        precip_mm: data.current.precip_mm,
        uv: data.current.uv,
        gust_kph: data.current.gust_kph,
        air_quality: data.current.air_quality,
        is_day: data.current.is_day
      },
      forecast: {
        forecastday: data.forecast.forecastday.map(day => ({
          date: day.date,
          day: {
            maxtemp_c: day.day.maxtemp_c,
            maxtemp_f: day.day.maxtemp_f,
            mintemp_c: day.day.mintemp_c,
            mintemp_f: day.day.mintemp_f,
            condition: {
              text: day.day.condition.text,
              code: day.day.condition.code
            },
            uv: day.day.uv,
            daily_chance_of_rain: day.day.daily_chance_of_rain,
            daily_chance_of_snow: day.day.daily_chance_of_snow,
            totalprecip_mm: day.day.totalprecip_mm
          },
          astro: {
            sunrise: day.astro.sunrise,
            sunset: day.astro.sunset,
            moonrise: day.astro.moonrise,
            moonset: day.astro.moonset,
            moon_phase: day.astro.moon_phase,
            moon_illumination: day.astro.moon_illumination
          },
          hour: day.hour.map(hour => ({
            time: hour.time,
            temp_c: hour.temp_c,
            temp_f: hour.temp_f,
            condition: {
              text: hour.condition.text,
              code: hour.condition.code
            },
            is_day: hour.is_day,
            chance_of_rain: hour.chance_of_rain,
            chance_of_snow: hour.chance_of_snow
          }))
        }))
      }
    };
  }

  async searchLocations(query, lang = 'ru') {
    try {
      const response = await fetch(
        `${this.baseUrl}/search.json?key=${this.apiKey}&q=${encodeURIComponent(query)}&lang=${lang}`
      );
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data.map(location => ({
        name: location.name,
        country: location.country,
        region: location.region,
        lat: location.lat,
        lon: location.lon
      }));
    } catch (error) {
      console.error('Search error:', error);
      throw new Error('Failed to search locations');
    }
  }

  async getWeather(location, lang = 'ru', days = 3) {
    try {
      let url;
      
      if (typeof location === 'object' && location.coords) {
        url = `${this.baseUrl}/forecast.json?key=${this.apiKey}&q=${location.coords.latitude},${location.coords.longitude}&days=${days}&lang=${lang}&aqi=yes`;
      } else {
        url = `${this.baseUrl}/forecast.json?key=${this.apiKey}&q=${encodeURIComponent(location)}&days=${days}&lang=${lang}&aqi=yes`;
      }

      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return this.normalizeWeatherData(data);
    } catch (error) {
      console.error('Weather fetch error:', error);
      throw new Error('Failed to fetch weather data');
    }
  }

  getWeatherType(code) {
    return WEATHER_CODE_TO_TYPE[code] || 'clear';
  }
}

export default WeatherProvider;*/

// раб
/*
import { WEATHER_CODE_TO_TYPE } from './WeatherDataMapper';

class WeatherProvider {
  constructor() {
    // ✅ Вместо прямого обращения к weatherapi.com — через Vercel прокси
    this.baseUrl = 'https://api-server-three-silk.vercel.app/api/weather';
    // Для локальной разработки:
    // this.baseUrl = 'http://localhost:3000/api/weather';
  }

  normalizeWeatherData(data) {
    // ← Без изменений, всё остаётся как было
    if (!data) return null;

    return {
      location: {
        name: data.location.name,
        country: data.location.country,
        region: data.location.region,
        lat: data.location.lat,
        lon: data.location.lon,
        tz_id: data.location.tz_id,
        localtime: data.location.localtime
      },
      current: {
        temp_c: data.current.temp_c,
        temp_f: data.current.temp_f,
        condition: {
          text: data.current.condition.text,
          code: data.current.condition.code
        },
        feelslike_c: data.current.feelslike_c,
        feelslike_f: data.current.feelslike_f,
        humidity: data.current.humidity,
        wind_kph: data.current.wind_kph,
        wind_dir: data.current.wind_dir,
        pressure_mb: data.current.pressure_mb,
        precip_mm: data.current.precip_mm,
        uv: data.current.uv,
        gust_kph: data.current.gust_kph,
        air_quality: data.current.air_quality,
        is_day: data.current.is_day
      },
      forecast: {
        forecastday: data.forecast.forecastday.map(day => ({
          date: day.date,
          day: {
            maxtemp_c: day.day.maxtemp_c,
            maxtemp_f: day.day.maxtemp_f,
            mintemp_c: day.day.mintemp_c,
            mintemp_f: day.day.mintemp_f,
            condition: {
              text: day.day.condition.text,
              code: day.day.condition.code
            },
            uv: day.day.uv,
            daily_chance_of_rain: day.day.daily_chance_of_rain,
            daily_chance_of_snow: day.day.daily_chance_of_snow,
            totalprecip_mm: day.day.totalprecip_mm
          },
          astro: {
            sunrise: day.astro.sunrise,
            sunset: day.astro.sunset,
            moonrise: day.astro.moonrise,
            moonset: day.astro.moonset,
            moon_phase: day.astro.moon_phase,
            moon_illumination: day.astro.moon_illumination
          },
          hour: day.hour.map(hour => ({
            time: hour.time,
            temp_c: hour.temp_c,
            temp_f: hour.temp_f,
            condition: {
              text: hour.condition.text,
              code: hour.condition.code
            },
            is_day: hour.is_day,
            chance_of_rain: hour.chance_of_rain,
            chance_of_snow: hour.chance_of_snow
          }))
        }))
      }
    };
  }

  // ✅ ИЗМЕНЕНО: запрос через прокси
  async searchLocations(query, lang = 'ru') {
    try {
      const response = await fetch(
        `${this.baseUrl}?endpoint=search&q=${encodeURIComponent(query)}&lang=${lang}`
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data.map(location => ({
        name: location.name,
        country: location.country,
        region: location.region,
        lat: location.lat,
        lon: location.lon
      }));
    } catch (error) {
      console.error('Search error:', error);
      throw new Error('Failed to search locations');
    }
  }

  // ✅ ИЗМЕНЕНО: запрос через прокси
  async getWeather(location, lang = 'ru', days = 3) {
    try {
      let q;

      if (typeof location === 'object' && location.coords) {
        q = `${location.coords.latitude},${location.coords.longitude}`;
      } else {
        q = encodeURIComponent(location);
      }

      const url = `${this.baseUrl}?endpoint=forecast&q=${q}&days=${days}&lang=${lang}&aqi=yes`;

      const response = await fetch(url);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return this.normalizeWeatherData(data);
    } catch (error) {
      console.error('Weather fetch error:', error);
      throw new Error('Failed to fetch weather data');
    }
  }

  getWeatherType(code) {
    return WEATHER_CODE_TO_TYPE[code] || 'clear';
  }
}

export default WeatherProvider;*/

// раб(времн случай ошибка пусьой)

import { WEATHER_CODE_TO_TYPE } from './WeatherDataMapper';

class WeatherProvider {
  constructor() {
    this.baseUrl = 'https://api-server-three-silk.vercel.app/api/weather';

    // Для локальной разработки:
    // this.baseUrl = 'http://localhost:3000/api/weather';
  }

  normalizeWeatherData(data) {
    if (!data || typeof data !== 'object') {
      return null;
    }

    const location = data.location || {};
    const current = data.current || {};
    const currentCondition = current.condition || {};

    const forecastDays = Array.isArray(data.forecast?.forecastday)
      ? data.forecast.forecastday
      : [];

    return {
      location: {
        name: location.name || '',
        country: location.country || '',
        region: location.region || '',
        lat: location.lat ?? null,
        lon: location.lon ?? null,
        tz_id: location.tz_id || '',
        localtime: location.localtime || ''
      },

      current: {
        temp_c: current.temp_c ?? null,
        temp_f: current.temp_f ?? null,

        condition: {
          text: currentCondition.text || '',
          code: currentCondition.code ?? null
        },

        feelslike_c: current.feelslike_c ?? null,
        feelslike_f: current.feelslike_f ?? null,
        humidity: current.humidity ?? null,
        wind_kph: current.wind_kph ?? null,
        wind_dir: current.wind_dir || '',
        pressure_mb: current.pressure_mb ?? null,
        precip_mm: current.precip_mm ?? null,
        uv: current.uv ?? null,
        gust_kph: current.gust_kph ?? null,
        air_quality: current.air_quality || null,
        is_day: current.is_day ?? null
      },

      forecast: {
        forecastday: forecastDays.map(day => {
          const dayInfo = day.day || {};
          const dayCondition = dayInfo.condition || {};
          const astro = day.astro || {};

          const hours = Array.isArray(day.hour) ? day.hour : [];

          return {
            date: day.date || '',

            day: {
              maxtemp_c: dayInfo.maxtemp_c ?? null,
              maxtemp_f: dayInfo.maxtemp_f ?? null,
              mintemp_c: dayInfo.mintemp_c ?? null,
              mintemp_f: dayInfo.mintemp_f ?? null,

              condition: {
                text: dayCondition.text || '',
                code: dayCondition.code ?? null
              },

              uv: dayInfo.uv ?? null,
              daily_chance_of_rain: dayInfo.daily_chance_of_rain ?? null,
              daily_chance_of_snow: dayInfo.daily_chance_of_snow ?? null,
              totalprecip_mm: dayInfo.totalprecip_mm ?? null
            },

            astro: {
              sunrise: astro.sunrise || '',
              sunset: astro.sunset || '',
              moonrise: astro.moonrise || '',
              moonset: astro.moonset || '',
              moon_phase: astro.moon_phase || '',
              moon_illumination: astro.moon_illumination ?? null
            },

            hour: hours.map(hour => {
              const hourCondition = hour.condition || {};

              return {
                time: hour.time || '',
                temp_c: hour.temp_c ?? null,
                temp_f: hour.temp_f ?? null,

                condition: {
                  text: hourCondition.text || '',
                  code: hourCondition.code ?? null
                },

                is_day: hour.is_day ?? null,
                chance_of_rain: hour.chance_of_rain ?? null,
                chance_of_snow: hour.chance_of_snow ?? null
              };
            })
          };
        })
      }
    };
  }

  async searchLocations(query, lang = 'ru') {
    try {
      if (!query || !query.trim()) {
        return [];
      }

      const response = await fetch(
        `${this.baseUrl}?endpoint=search&q=${encodeURIComponent(query)}&lang=${lang}`
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (!Array.isArray(data)) {
        return [];
      }

      return data.map(location => ({
        name: location.name || '',
        country: location.country || '',
        region: location.region || '',
        lat: location.lat ?? null,
        lon: location.lon ?? null
      }));
    } catch (error) {
      console.error('Search error:', error);
      throw new Error('Failed to search locations');
    }
  }

  async getWeather(location, lang = 'ru', days = 3) {
    try {
      if (!location) {
        return null;
      }

      let q;

      if (typeof location === 'object' && location.coords) {
        q = `${location.coords.latitude},${location.coords.longitude}`;
      } else {
        q = encodeURIComponent(location);
      }

      const url = `${this.baseUrl}?endpoint=forecast&q=${q}&days=${days}&lang=${lang}&aqi=yes`;

      const response = await fetch(url);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      return this.normalizeWeatherData(data);
    } catch (error) {
      console.error('Weather fetch error:', error);
      throw new Error('Failed to fetch weather data');
    }
  }

  getWeatherType(code) {
    if (!code) {
      return 'clear';
    }

    return WEATHER_CODE_TO_TYPE[code] || 'clear';
  }
}

export default WeatherProvider;

