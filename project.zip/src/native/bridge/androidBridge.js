/**
 * ЕДИНОЕ публичное API моста для всего React-приложения.
 *
 * Правило простое: в компонентах НЕТ обращений к window.Android — только
 * `import { AndroidBridge } from '@/native'`.
 *
 * Kotlin-зеркало: android/.../bridge/NativeBridge.kt
 * Документация:   docs/native-bridge.md
 */

import {
  bridgeVersion,
  invoke,
  invokeJson,
  isNativeApp,
  nativeObject,
  on,
  parseJson,
  supports,
} from './core';
import { LegacyEvents, MapStatus, NativeEvents } from './events';

// ── Отступы по умолчанию (браузер / старый APK) ─────────────────────────────

export const EMPTY_INSETS = {
  windowInsets: null,
  top: 0,
  bottom: 0,
  left: 0,
  right: 0,
  tappableBottom: 0,
  tappableLeft: 0,
  tappableRight: 0,
  imeBottom: 0,
  cutoutTop: 0,
  cutoutBottom: 0,
  navigationMode: 'none',
  keyboardVisible: false,
  isLandscape: false,
  density: typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1,
  isNative: false,
};

/**
 * Приводит ответ native к плоскому объекту в CSS-пикселях.
 *
 * ВАЖНО: `css`/`px` — это отступы В КООРДИНАТАХ КОНТЕЙНЕРА WebView.
 * Android рисует непрозрачные системные бары и уже отодвигает от них WebView,
 * поэтому внутри контейнера отступов обычно НЕТ (нули) — и веб не добавляет их
 * второй раз. Полные оконные значения при этом доступны в `windowInsets`.
 */
function normalizeInsets(raw) {
  if (!raw) return EMPTY_INSETS;
  const css = raw.css || raw;
  const windowCss = raw.window?.css || null;
  return {
    windowInsets: windowCss
      ? {
          top: Number(windowCss.top) || 0,
          bottom: Number(windowCss.bottom) || 0,
          left: Number(windowCss.left) || 0,
          right: Number(windowCss.right) || 0,
          tappableBottom: Number(windowCss.tappableBottom) || 0,
        }
      : null,
    top: Number(css.top) || 0,
    bottom: Number(css.bottom) || 0,
    left: Number(css.left) || 0,
    right: Number(css.right) || 0,
    tappableBottom: Number(css.tappableBottom) || 0,
    tappableLeft: Number(css.tappableLeft) || 0,
    tappableRight: Number(css.tappableRight) || 0,
    imeBottom: Number(css.imeBottom) || 0,
    cutoutTop: Number(css.cutoutTop) || 0,
    cutoutBottom: Number(css.cutoutBottom) || 0,
    navigationMode: raw.navigationMode || 'unknown',
    keyboardVisible: Boolean(raw.keyboardVisible),
    isLandscape: Boolean(raw.isLandscape),
    density: Number(raw.density) || EMPTY_INSETS.density,
    isNative: true,
  };
}

// ── Приложение ──────────────────────────────────────────────────────────────

const app = {
  getVersion: () => invoke('getAppVersion', [], { fallback: null }),
  getDeviceInfo: () => invokeJson('getDeviceInfo', [], { fallback: null }),
  isDarkMode: () => invoke('isDarkMode', [], { fallback: null }),
  log: (tag, message) => invoke('log', [String(tag), String(message)], { silent: true }),
};

// ── Безопасные отступы ──────────────────────────────────────────────────────

const insets = {
  /** Текущее значение (синхронно). */
  get() {
    if (!isNativeApp()) return EMPTY_INSETS;
    return normalizeInsets(invokeJson('getInsets', [], { fallback: null }));
  },

  /** Попросить native прислать insets заново. */
  request() {
    invoke('requestInsets', [], { silent: true });
  },

  /** Подписка на изменения. @returns unsubscribe */
  subscribe(handler) {
    return on(NativeEvents.INSETS, (detail) => handler(normalizeInsets(detail)));
  },
};

// ── Тема ────────────────────────────────────────────────────────────────────

const theme = {
  /** "light" | "dark" | "auto" */
  get: () => invoke('getCurrentTheme', [], { kind: 'theme', fallback: null }),
  getSystem: () => invoke('getSystemTheme', [], { kind: 'theme', fallback: null }),
  isDark: () => invoke('isDarkMode', [], { kind: 'theme', fallback: app.isDarkMode() }),
  set: (value) => invoke('setTheme', [value], { kind: 'theme' }),
  subscribe: (handler) => on(NativeEvents.THEME, handler),
};

// ── Геолокация ──────────────────────────────────────────────────────────────

const location = {
  /** "granted" | "denied" | "should_show_rationale" | "unknown" */
  getStatus: () => invoke('getLocationStatus', [], { fallback: 'unknown' }),
  request: () => invoke('requestLocationPermission', []),
  subscribe: (handler) => on(NativeEvents.LOCATION, handler),
  subscribePermission: (handler) =>
    on(NativeEvents.LOCATION_PERMISSION, (detail) =>
      handler(typeof detail === 'object' ? Boolean(detail?.granted) : Boolean(detail))
    ),
};

// ── Карта ───────────────────────────────────────────────────────────────────

/**
 * Пересылает раскладку карты в native.
 *
 * @param {object} payload
 * @param {string} payload.url
 * @param {{x:number,y:number,width:number,height:number}} payload.rect  CSS-px, getBoundingClientRect()
 * @param {{width:number,height:number}} [payload.viewport]              window.innerWidth/innerHeight
 * @param {'auto'|'safe'|'edge'} [payload.insetsMode]
 * @param {boolean} [payload.visible]
 */
function mapUpdate(payload) {
  if (!isNativeApp()) return false;

  const viewport = payload.viewport || {
    width: window.innerWidth,
    height: window.innerHeight,
  };

  const body = {
    url: payload.url,
    rect: {
      x: Math.round(payload.rect.x),
      y: Math.round(payload.rect.y),
      width: Math.round(payload.rect.width),
      height: Math.round(payload.rect.height),
    },
    viewport: {
      width: Math.round(viewport.width),
      height: Math.round(viewport.height),
    },
    insetsMode: payload.insetsMode || 'auto',
    visible: payload.visible !== false,
  };

  if (supports('mapUpdate')) {
    invoke('mapUpdate', [JSON.stringify(body)]);
    return true;
  }

  // Fallback: новый веб + старый APK (bridgeVersion < 2).
  if (supports('updateWebView')) {
    const height = window.innerHeight || 1;
    invoke('updateWebView', [
      body.url,
      body.rect.x,
      body.rect.y,
      body.rect.width,
      body.rect.height,
      body.rect.y / height,
      Math.max(0, height - (body.rect.y + body.rect.height)) / height,
      (window.innerWidth || 0) >= 600,
    ]);
    return true;
  }

  return false;
}

const map = {
  update: mapUpdate,

  setUrl(url) {
    if (supports('mapSetUrl')) invoke('mapSetUrl', [url]);
    else invoke('updateUrl', [url], { silent: true });
  },

  show() {
    if (supports('mapShow')) invoke('mapShow');
    else invoke('showWebView', [], { silent: true });
  },

  hide() {
    if (supports('mapHide')) invoke('mapHide');
    else invoke('hideWebView', [], { silent: true });
  },

  reload() {
    if (supports('mapReload')) invoke('mapReload');
    else invoke('retryLoading', [], { silent: true });
  },

  /** Скрыть и остановить, но не уничтожать. */
  suspend() {
    if (supports('mapSuspend')) invoke('mapSuspend');
    else invoke('softCleanup', [], { silent: true });
  },

  /** Уничтожить нативный WebView карты. */
  release() {
    invoke('mapRelease', [], { silent: true });
  },

  status: () => invokeJson('mapStatus', [], { fallback: null }),

  /** Подписка на статус карты. @returns unsubscribe */
  subscribe: (handler) => on(NativeEvents.MAP, handler),
};

// ── Реклама ─────────────────────────────────────────────────────────────────

const ads = {
  getState: () => invokeJson('getAdFreeState', [], { fallback: null }),
  isRewardedReady: () => invoke('isRewardedAdReady', [], { fallback: false }),
  showRewarded: () => invokeJson('showRewardedAd', [], { fallback: { success: false } }),
  activateAdFree: () =>
    invokeJson('activateAdFreeFor5Minutes', [], { fallback: { success: false } }),
  subscribe: (handler) => on(LegacyEvents.AD_FREE, handler),
  subscribeRewarded: (handler) => on(LegacyEvents.REWARDED, handler),
};

// ── Обновления ──────────────────────────────────────────────────────────────

const updates = {
  check: () => invoke('checkForUpdates'),
  checkIsLatest: () => invoke('checkIsLatestVersion'),
  startFlexible: () => invoke('startFlexibleUpdate'),
  install: () => invoke('installUpdate'),
};

// ── Meteo OS: OTA-обновления веб-бандла ─────────────────────────────────────
//
// НЕ путать с `updates` выше: те обновляют APK через магазин (RuStore /
// Google Play), а Meteo OS доставляет новые версии React-интерфейса без
// магазина. Kotlin-зеркало: android/.../ota/MeteoOsUpdateManager.kt.
//
// Статусы приходят событием NativeEvents.METEO_OS (см. events.js).

const meteoOs = {
  /** Поддерживает ли установленный APK систему Meteo OS. */
  get isSupported() {
    return supports('meteoOsGetState');
  },

  /** Текущее состояние: версии (builtin/active/pending), ошибки, источник. */
  getState: () => invokeJson('meteoOsGetState', [], { fallback: null }),

  /** Проверить обновления. Результат — событием native:meteoOs. */
  check: () => invoke('meteoOsCheckForUpdates'),

  /** Скачать найденное обновление. Прогресс — событиями native:meteoOs. */
  download: () => invoke('meteoOsDownloadUpdate'),

  /** Применить скачанное: native перезагрузит WebView с новой версией. */
  apply: () => invoke('meteoOsApplyUpdate'),

  /**
   * Подтвердить, что интерфейс успешно стартовал.
   * Зовётся автоматически из src/index.jsx после монтирования React —
   * без подтверждения native откатит версию при следующем старте.
   */
  reportHealthy: () => invoke('meteoOsReportHealthy', [], { silent: true }),

  /** Сбросить интерфейс до версии, встроенной в APK. */
  resetToBuiltin: () => invoke('meteoOsResetToBuiltin'),

  /** Подписка на события Meteo OS. @returns функция отписки */
  subscribe: (handler) => on(NativeEvents.METEO_OS, handler),
};

// ── Экспорт ─────────────────────────────────────────────────────────────────

export const AndroidBridge = {
  get isNative() {
    return isNativeApp();
  },
  get version() {
    return bridgeVersion();
  },
  supports,
  on,
  parseJson,
  raw: nativeObject,

  app,
  insets,
  theme,
  location,
  map,
  ads,
  updates,
  meteoOs,

  events: NativeEvents,
  legacyEvents: LegacyEvents,
  mapStatus: MapStatus,
};

export default AndroidBridge;
