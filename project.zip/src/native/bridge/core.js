/**
 * Низкий уровень моста JS ↔ Android.
 *
 * Здесь нет никакой доменной логики — только:
 *   • безопасный вызов native-методов (никаких падений в UI);
 *   • разбор JSON-ответов;
 *   • одна шина событий вместо десятка window.onXxx-колбэков.
 *
 * Публичное API приложения — src/native/bridge/androidBridge.js
 */

const isBrowser = typeof window !== 'undefined';

/** Имена нативных объектов в window. */
export const NATIVE_OBJECTS = {
  bridge: 'AndroidBridge', // новый API (v2)
  legacy: 'Android',       // тот же объект под старым именем
  theme: 'AndroidTheme',
  api: 'AndroidApi',
};

const DEBUG = isBrowser && /[?&]bridgeDebug=1/.test(window.location.search);

/** Возвращает нативный объект или undefined (в браузере — всегда undefined). */
export function nativeObject(kind) {
  if (!isBrowser) return undefined;
  const name = NATIVE_OBJECTS[kind] || kind;
  const target = window[name];
  return target && typeof target === 'object' ? target : undefined;
}

/** Основной нативный объект: сперва новый, потом legacy. */
export function nativeCore() {
  return nativeObject('bridge') || nativeObject('legacy');
}

/** Запущены ли мы внутри Android WebView приложения. */
export function isNativeApp() {
  return Boolean(nativeCore());
}

/** Версия контракта: 0 — моста нет, 1 — старый APK, 2+ — новый. */
export function bridgeVersion() {
  const core = nativeCore();
  if (!core) return 0;
  if (typeof core.bridgeVersion !== 'function') return 1;
  try {
    return Number(core.bridgeVersion()) || 1;
  } catch (e) {
    return 1;
  }
}

/** Есть ли у native такой метод. */
export function supports(method, kind = 'core') {
  const target = kind === 'core' ? nativeCore() : nativeObject(kind);
  return Boolean(target && typeof target[method] === 'function');
}

/**
 * Безопасный вызов нативного метода.
 * Любая ошибка (нет объекта, нет метода, исключение внутри) → fallback.
 */
export function invoke(method, args = [], options = {}) {
  const { kind = 'core', fallback = undefined, silent = false } = options;
  const target = kind === 'core' ? nativeCore() : nativeObject(kind);

  if (!target || typeof target[method] !== 'function') {
    if (DEBUG && !silent) console.warn(`[bridge] нет метода ${kind}.${method}`);
    return fallback;
  }

  try {
    const result = target[method](...args);
    if (DEBUG) console.debug(`[bridge] ${kind}.${method}`, args, '→', result);
    return result;
  } catch (error) {
    if (!silent) console.error(`[bridge] ошибка ${kind}.${method}:`, error);
    return fallback;
  }
}

/** Вызов, результат которого — JSON-строка. */
export function invokeJson(method, args = [], options = {}) {
  const { fallback = null } = options;
  const raw = invoke(method, args, { ...options, fallback: null });
  return parseJson(raw, fallback);
}

export function parseJson(raw, fallback = null) {
  if (raw == null) return fallback;
  if (typeof raw === 'object') return raw;
  if (typeof raw !== 'string') return fallback;
  try {
    return JSON.parse(raw);
  } catch (e) {
    return fallback;
  }
}

// ── Шина событий ────────────────────────────────────────────────────────────

const listeners = new Map();
/** Чтобы одно и то же событие не обработалось дважды (шина + CustomEvent). */
const suppressWindowEvent = new Set();
const windowBound = new Set();

function deliver(event, detail) {
  const handlers = listeners.get(event);
  if (!handlers || handlers.size === 0) return;
  handlers.forEach((handler) => {
    try {
      handler(detail);
    } catch (error) {
      console.error(`[bridge] обработчик ${event} упал:`, error);
    }
  });
}

function bindWindowEvent(event) {
  if (!isBrowser || windowBound.has(event)) return;
  windowBound.add(event);
  window.addEventListener(event, (nativeEvent) => {
    // Native шлёт и в шину, и в CustomEvent — второй раз игнорируем.
    if (suppressWindowEvent.has(event)) {
      suppressWindowEvent.delete(event);
      return;
    }
    deliver(event, nativeEvent?.detail);
  });
}

/** Точка входа для native: window.__nativeBridgeEmit(name, detail). */
function installNativeEmitter() {
  if (!isBrowser || window.__nativeBridgeEmit) return;
  window.__nativeBridgeEmit = (event, detail) => {
    if (DEBUG) console.debug('[bridge] ←', event, detail);
    suppressWindowEvent.add(event);
    // Флаг живёт только до конца текущей задачи.
    Promise.resolve().then(() => suppressWindowEvent.delete(event));
    deliver(event, detail);
  };
}

/**
 * Подписка на событие моста.
 * @returns {() => void} функция отписки
 */
export function on(event, handler) {
  if (!isBrowser || typeof handler !== 'function') return () => {};

  installNativeEmitter();
  bindWindowEvent(event);

  if (!listeners.has(event)) listeners.set(event, new Set());
  listeners.get(event).add(handler);

  return () => {
    const handlers = listeners.get(event);
    if (handlers) handlers.delete(handler);
  };
}

/** Ручная отправка события (используется веб-моком в браузере). */
export function emitLocal(event, detail) {
  deliver(event, detail);
}

installNativeEmitter();
