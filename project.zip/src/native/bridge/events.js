/**
 * Имена событий, которые native шлёт в веб.
 * Зеркало Kotlin-файла: android/.../bridge/BridgeChannel.kt (object BridgeEvents)
 *
 * ВАЖНО: строки должны совпадать один-в-один с Kotlin-стороной.
 */
export const NativeEvents = {
  /** Мост подключился, пришло стартовое состояние. */
  READY: 'native:ready',

  /** Изменились безопасные отступы (status bar / nav bar / вырез / клавиатура). */
  INSETS: 'native:insets',

  /** Состояние нативной карты: loading | loaded | error | offline | released. */
  MAP: 'native:map',

  /** Тема изменилась. */
  THEME: 'native:theme',

  /** Пришли координаты. */
  LOCATION: 'native:location',

  /** Ответ на запрос разрешения геолокации. */
  LOCATION_PERMISSION: 'native:locationPermission',

  /**
   * Meteo OS — OTA-обновления веб-бандла.
   * detail: { status: 'available'|'requiresAppUpdate'|'upToDate'|'downloading'|
   *           'downloaded'|'applying'|'reset'|'error',
   *           version?, progress?, notes?, error? }
   *
   * 'requiresAppUpdate' — новая Meteo OS существует, но требует более свежий
   * APK: качать нельзя, UI рекомендует обновить основное приложение.
   */
  METEO_OS: 'native:meteoOs',
};

/** Старые события — их всё ещё слушает существующий UI. */
export const LegacyEvents = {
  THEME: 'androidThemeChanged',
  LOCATION: 'androidLocationUpdate',
  LOCATION_PERMISSION: 'androidLocationPermissionResult',
  AD_FREE: 'adFreeStateChanged',
  REWARDED: 'rewardedAdStateChanged',
  UPDATE_AVAILABLE: 'updateAvailable',
  UPDATE_STARTED: 'updateStarted',
  UPDATE_PROGRESS: 'updateProgress',
  UPDATE_DOWNLOADED: 'updateDownloaded',
  UPDATE_ERROR: 'updateError',
  IS_LATEST_VERSION: 'isLatestVersion',
};

/** Статусы нативной карты. */
export const MapStatus = {
  IDLE: 'idle',
  LOADING: 'loading',
  LOADED: 'loaded',
  ERROR: 'error',
  OFFLINE: 'offline',
  RELEASED: 'released',
};
