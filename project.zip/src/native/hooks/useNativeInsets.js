import { useEffect, useState } from 'react';
import AndroidBridge, { EMPTY_INSETS } from '../bridge/androidBridge';

/**
 * Системные отступы Android в React-виде.
 *
 *   const insets = useNativeInsets();
 *   <div style={{ paddingBottom: insets.bottom }} />
 *
 * В браузере всегда возвращает нули (EMPTY_INSETS), поэтому обычная веб-версия
 * ничего не замечает.
 */
export function useNativeInsets() {
  const [insets, setInsets] = useState(() =>
    AndroidBridge.isNative ? AndroidBridge.insets.get() : EMPTY_INSETS
  );

  useEffect(() => {
    if (!AndroidBridge.isNative) return undefined;

    const unsubscribe = AndroidBridge.insets.subscribe(setInsets);
    AndroidBridge.insets.request();

    return unsubscribe;
  }, []);

  return insets;
}

export default useNativeInsets;
