import { useCallback, useEffect, useRef, useState } from 'react';
import AndroidBridge from '../bridge/androidBridge';
import { MapStatus } from '../bridge/events';

/**
 * Держит нативный WebView карты ровно в границах DOM-элемента («слота»).
 *
 * Идея: React ничего не считает руками — он просто рисует пустой div нужного
 * размера, а хук раз за разом отдаёт native его getBoundingClientRect().
 * Native переводит CSS-px в пиксели устройства по РЕАЛЬНОМУ размеру
 * WebView-вьюпорта, поэтому раскладка одинаково корректна на любом экране,
 * при любом зуме, в портрете и в ландшафте.
 *
 * Использование:
 *   const slotRef = useRef(null);
 *   const { status, retry } = useNativeMapView({ slotRef, url, active: tab === 'map' });
 *   <div ref={slotRef} className="flex-1" />
 */
export function useNativeMapView({
  slotRef,
  url,
  active = true,
  visible = true,
  insetsMode = 'auto',
  /** Уничтожать нативный WebView при уходе со страницы (экономит память). */
  releaseOnUnmount = false,
}) {
  const isNative = AndroidBridge.isNative;

  const [status, setStatus] = useState(MapStatus.IDLE);
  const [errorDescription, setErrorDescription] = useState(null);

  const lastPayloadRef = useRef('');
  const frameRef = useRef(0);
  const shouldShowRef = useRef(false);

  shouldShowRef.current = Boolean(isNative && active && visible && url);

  // ── Отправка геометрии ────────────────────────────────────────────────────

  const push = useCallback(
    (force = false) => {
      if (!isNative) return;

      const node = slotRef.current;
      if (!node) return;

      if (!shouldShowRef.current) {
        AndroidBridge.map.hide();
        return;
      }

      const rect = node.getBoundingClientRect();

      // Слот скрыт / схлопнут — карту показывать нечего.
      if (rect.width < 2 || rect.height < 2) {
        AndroidBridge.map.hide();
        return;
      }

      const payload = {
        url,
        rect: { x: rect.left, y: rect.top, width: rect.width, height: rect.height },
        viewport: { width: window.innerWidth, height: window.innerHeight },
        insetsMode,
        visible: true,
      };

      const signature = JSON.stringify(payload);
      if (!force && signature === lastPayloadRef.current) return;
      lastPayloadRef.current = signature;

      AndroidBridge.map.update(payload);
    },
    [insetsMode, isNative, slotRef, url]
  );

  /** Планирует пересчёт на следующий кадр (защита от «шторма» событий). */
  const schedule = useCallback(
    (force = false) => {
      if (!isNative) return;
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
      frameRef.current = requestAnimationFrame(() => {
        frameRef.current = 0;
        push(force);
      });
    },
    [isNative, push]
  );

  // ── Слежение за размерами и позицией слота ────────────────────────────────

  useEffect(() => {
    if (!isNative) return undefined;

    const node = slotRef.current;
    const onChange = () => schedule(false);

    // 1. Размер самого слота (сворачивание тулбара, смена контента и т.п.)
    let resizeObserver = null;
    if (node && typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(onChange);
      resizeObserver.observe(node);
    }

    // 2. Размер окна / поворот / появление клавиатуры
    window.addEventListener('resize', onChange);
    window.addEventListener('orientationchange', onChange);

    // 3. visualViewport — самый честный источник в WebView
    const vv = window.visualViewport;
    if (vv) {
      vv.addEventListener('resize', onChange);
      vv.addEventListener('scroll', onChange);
    }

    // 4. Любая прокрутка (страница скроллится в контейнере, capture обязателен)
    window.addEventListener('scroll', onChange, true);

    // 5. Изменились системные отступы (жесты ↔ кнопки, вырез, клавиатура)
    const unsubscribeInsets = AndroidBridge.insets.subscribe(() => schedule(true));

    // 6. Страховка: раз в секунду сверяем позицию (анимации, лениво загруженные
    //    шрифты и прочее, что не ловится наблюдателями)
    const interval = window.setInterval(() => schedule(false), 1000);

    schedule(true);

    return () => {
      if (resizeObserver) resizeObserver.disconnect();
      window.removeEventListener('resize', onChange);
      window.removeEventListener('orientationchange', onChange);
      if (vv) {
        vv.removeEventListener('resize', onChange);
        vv.removeEventListener('scroll', onChange);
      }
      window.removeEventListener('scroll', onChange, true);
      unsubscribeInsets();
      window.clearInterval(interval);
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
    };
  }, [isNative, schedule, slotRef]);

  // ── Реакция на смену url / активности / видимости ─────────────────────────

  useEffect(() => {
    if (!isNative) return;

    if (!shouldShowRef.current) {
      // Ушли со вкладки — глушим загрузку (WebView не убиваем, возврат должен
      // быть мгновенным). Просто перекрыли модалкой — достаточно спрятать.
      if (active) AndroidBridge.map.hide();
      else AndroidBridge.map.suspend();
      return;
    }

    setErrorDescription(null);
    schedule(true);
  }, [active, isNative, schedule, url, visible]);

  // ── Статус от native ──────────────────────────────────────────────────────

  useEffect(() => {
    if (!isNative) return undefined;

    return AndroidBridge.map.subscribe((detail) => {
      if (!detail || !detail.status) return;
      setStatus(detail.status);
      setErrorDescription(
        detail.status === MapStatus.ERROR || detail.status === MapStatus.OFFLINE
          ? detail.description || null
          : null
      );
    });
  }, [isNative]);

  // ── Размонтирование ───────────────────────────────────────────────────────

  useEffect(() => {
    if (!isNative) return undefined;
    return () => {
      if (releaseOnUnmount) AndroidBridge.map.release();
      else AndroidBridge.map.suspend();
    };
  }, [isNative, releaseOnUnmount]);

  // ── Действия ──────────────────────────────────────────────────────────────

  const retry = useCallback(() => {
    if (!isNative) return;
    setStatus(MapStatus.LOADING);
    setErrorDescription(null);
    lastPayloadRef.current = '';
    AndroidBridge.map.show();
    AndroidBridge.map.reload();
    schedule(true);
  }, [isNative, schedule]);

  const refreshLayout = useCallback(() => schedule(true), [schedule]);

  return {
    isNative,
    status,
    errorDescription,
    isLoading: status === MapStatus.LOADING,
    hasError: status === MapStatus.ERROR || status === MapStatus.OFFLINE,
    isOffline: status === MapStatus.OFFLINE,
    retry,
    refreshLayout,
  };
}

export default useNativeMapView;
