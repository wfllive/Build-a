import { useCallback, useEffect, useRef } from 'react';
import AndroidBridge from '../bridge/androidBridge';

/**
 * Измеряет реальную занятую высоту нижней панели вкладок и публикует её
 * в CSS-переменную `--tabbar-space`.
 *
 * ЗАЧЕМ ЭТО НУЖНО
 * Нативный WebView карты физически рисуется ПОВЕРХ веба, поэтому всё, что
 * веб рисует в этой зоне (панель вкладок и особенно круг активной вкладки,
 * который торчит ВЫШЕ панели), будет перекрыто/обрезано.
 *
 * Считать «64px высота панели + отступ» нельзя: круг выступает над панелью,
 * размеры зависят от масштаба шрифта системы, а нижний отступ приходит из
 * Android (жесты / 3 кнопки). Поэтому меряем по факту:
 *
 *   space = высота окна − самая верхняя точка панели (с учётом выступа) + зазор
 *
 * Полученное значение используют:
 *   • слот карты (`marginBottom: var(--tabbar-space)`) — карта заканчивается
 *     ВЫШЕ круга, ничего не задевая;
 *   • утилиты `.pb-tabbar` / `.mb-tabbar` на других страницах.
 *
 * @param {object}   refs
 * @param {React.RefObject} refs.containerRef  внешний контейнер панели
 * @param {React.RefObject} [refs.overhangRef] элемент, выступающий над панелью (круг)
 * @param {number}   [refs.gap=8]              дополнительный зазор в px
 */
export function useTabBarSpace({ containerRef, overhangRef, gap = 8 }) {
  const lastValueRef = useRef(-1);

  const measure = useCallback(() => {
    const container = containerRef.current;
    if (!container || typeof document === 'undefined') return;

    const tops = [container.getBoundingClientRect().top];

    // Круг активной вкладки позиционирован абсолютно и вылезает за границы
    // панели — getBoundingClientRect() контейнера его НЕ учитывает.
    if (overhangRef && overhangRef.current) {
      tops.push(overhangRef.current.getBoundingClientRect().top);
    }

    const top = Math.min(...tops.filter((value) => Number.isFinite(value)));
    const viewportHeight = window.visualViewport?.height || window.innerHeight;

    const space = Math.max(0, Math.round(viewportHeight - top + gap));
    if (space === lastValueRef.current) return;
    lastValueRef.current = space;

    document.documentElement.style.setProperty('--tabbar-space', `${space}px`);
  }, [containerRef, overhangRef, gap]);

  useEffect(() => {
    let frame = 0;
    const schedule = () => {
      if (frame) cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        frame = 0;
        measure();
      });
    };

    schedule();

    let observer = null;
    if (containerRef.current && typeof ResizeObserver !== 'undefined') {
      observer = new ResizeObserver(schedule);
      observer.observe(containerRef.current);
    }

    window.addEventListener('resize', schedule);
    window.addEventListener('orientationchange', schedule);
    window.visualViewport?.addEventListener('resize', schedule);

    // Отступ снизу приходит из Android (жесты ↔ 3 кнопки) — панель сдвигается.
    const unsubscribeInsets = AndroidBridge.insets.subscribe(schedule);

    // Страховка: шрифты/анимации могут поменять высоту уже после монтирования.
    const timeout = window.setTimeout(schedule, 400);

    return () => {
      if (frame) cancelAnimationFrame(frame);
      if (observer) observer.disconnect();
      window.removeEventListener('resize', schedule);
      window.removeEventListener('orientationchange', schedule);
      window.visualViewport?.removeEventListener('resize', schedule);
      unsubscribeInsets();
      window.clearTimeout(timeout);
    };
  }, [containerRef, measure]);

  return measure;
}

export default useTabBarSpace;
