/**
 * Ранняя инициализация — импортируется САМЫМ ПЕРВЫМ в src/index.jsx,
 * до i18n и остальных модулей.
 *
 * Задача: сделать окружение file:// (release-сборка Android грузит бандл как
 * file:///android_asset/dist/index.html) безопасным для кода, который писался
 * в расчёте на обычный http-origin.
 */

/**
 * localStorage на «непрозрачном» origin может быть недоступен и бросать
 * SecurityError уже при обращении к свойству. Любой такой бросок на старте
 * (например, внутри детектора языка i18next) убивает всё приложение —
 * получаем белый экран.
 *
 * Проверяем доступность один раз и при необходимости подменяем на
 * in-memory реализацию: приложение продолжит работать, просто настройки
 * не переживут перезапуск.
 *
 * @returns {boolean} true, если пришлось ставить заглушку
 */
export function installStorageFallback() {
  if (typeof window === 'undefined') return false;

  try {
    const probe = '__meteo_storage_probe__';
    window.localStorage.setItem(probe, '1');
    window.localStorage.removeItem(probe);
    return false;
  } catch (error) {
    console.warn('[bootstrap] localStorage недоступен, включаю память:', error?.message);
  }

  const memory = new Map();
  const shim = {
    getItem: (key) => (memory.has(String(key)) ? memory.get(String(key)) : null),
    setItem: (key, value) => { memory.set(String(key), String(value)); },
    removeItem: (key) => { memory.delete(String(key)); },
    clear: () => memory.clear(),
    key: (index) => Array.from(memory.keys())[index] ?? null,
    get length() { return memory.size; },
  };

  try {
    Object.defineProperty(window, 'localStorage', {
      configurable: true,
      get: () => shim,
    });
  } catch (error) {
    try {
      window.localStorage = shim;
    } catch {
      /* совсем безнадёжно — оставляем как есть */
    }
  }

  return true;
}

/**
 * Пробрасывает необработанные ошибки JS в Logcat через мост.
 *
 * В release WebView-отладка выключена и консоль не видна, поэтому белый экран
 * невозможно диагностировать. Теперь любая такая ошибка видна в
 * `adb logcat | grep WebViewConsole`.
 */
export function installErrorReporter() {
  if (typeof window === 'undefined') return;

  const report = (kind, message, stack) => {
    const text = `[${kind}] ${message}${stack ? `\n${stack}` : ''}`;
    try {
      const bridge = window.AndroidBridge || window.Android;
      if (bridge && typeof bridge.log === 'function') {
        bridge.log('js-error', text.slice(0, 4000));
      }
    } catch {
      /* мост может быть недоступен — не мешаем */
    }
    console.error(text);
  };

  window.addEventListener('error', (event) => {
    report('error', event.message || String(event.error), event.error?.stack);
  });

  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    report('unhandledrejection', reason?.message || String(reason), reason?.stack);
  });
}

installStorageFallback();
installErrorReporter();
