/**
 * Мост JS ↔ Android — единая точка импорта.
 *
 *   import { AndroidBridge, useNativeInsets, useNativeMapView } from '@/native';
 *
 * Ничего, кроме этого модуля, не должно трогать window.Android напрямую.
 */

export { default as AndroidBridge, EMPTY_INSETS } from './bridge/androidBridge';
export { NativeEvents, LegacyEvents, MapStatus } from './bridge/events';
export {
  isNativeApp,
  bridgeVersion,
  supports as nativeSupports,
  on as onNativeEvent,
} from './bridge/core';

export { default as initSafeArea, applyInsetsToCss } from './safeArea';
export { default as useNativeInsets } from './hooks/useNativeInsets';
export { default as useNativeMapView } from './hooks/useNativeMapView';
export { default as useTabBarSpace } from './hooks/useTabBarSpace';
