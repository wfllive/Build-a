/**
 * Пробрасывает системные отступы Android в CSS.
 *
 * ЗАЧЕМ: в Android WebView `env(safe-area-inset-bottom)` почти всегда равен 0,
 * даже когда окно реально идёт под навбар. Поэтому вёрстка, рассчитанная на
 * env(), уезжала под кнопки навигации. Теперь значения приходят из native.
 *
 * После init() доступны переменные (в CSS-пикселях):
 *   --safe-area-top / --safe-area-bottom / --safe-area-left / --safe-area-right
 *   --safe-area-keyboard   — высота клавиатуры
 *   --nav-inset            — сколько реально «занято» навигацией снизу:
 *                            жесты → 0, кнопки → высота панели
 *   --app-bottom-gap       — готовый отступ для плавающих панелей
 *
 * И атрибуты на <html>:
 *   data-native="true|false"
 *   data-nav-mode="gesture|buttons|none|unknown"
 *   data-keyboard="open|closed"
 */

import AndroidBridge, { EMPTY_INSETS } from './bridge/androidBridge';

const MIN_FLOATING_GAP = 8; // px, чтобы панель не липла к самому краю

let unsubscribe = null;
let initialized = false;

function px(value) {
  return `${Math.max(0, Math.round(Number(value) || 0))}px`;
}

export function applyInsetsToCss(insets) {
  if (typeof document === 'undefined') return;

  const root = document.documentElement;
  const style = root.style;

  style.setProperty('--safe-area-top', px(insets.top));
  style.setProperty('--safe-area-bottom', px(insets.bottom));
  style.setProperty('--safe-area-left', px(insets.left));
  style.setProperty('--safe-area-right', px(insets.right));
  style.setProperty('--safe-area-keyboard', px(insets.imeBottom));

  // ХИТРОСТЬ: под жестовую «пилюлю» лезть можно (она прозрачная и ничего не
  // перекрывает), под реальные кнопки — нельзя. tappableBottom как раз и равен
  // нулю при жестах и высоте панели при трёх кнопках.
  const navInset = insets.navigationMode === 'buttons'
    ? Math.max(insets.tappableBottom, insets.bottom)
    : insets.tappableBottom;

  style.setProperty('--nav-inset', px(navInset));
  style.setProperty(
    '--app-bottom-gap',
    px(Math.max(navInset, insets.navigationMode === 'gesture' ? MIN_FLOATING_GAP : 0) + MIN_FLOATING_GAP)
  );

  root.setAttribute('data-native', String(Boolean(insets.isNative)));
  root.setAttribute('data-nav-mode', insets.navigationMode || 'unknown');
  root.setAttribute('data-keyboard', insets.keyboardVisible ? 'open' : 'closed');
}

/**
 * Подключить синхронизацию отступов. Вызывается один раз при старте приложения.
 * @returns {() => void} остановить синхронизацию
 */
export function initSafeArea() {
  if (initialized) return () => {};
  initialized = true;

  applyInsetsToCss(AndroidBridge.isNative ? AndroidBridge.insets.get() : EMPTY_INSETS);

  unsubscribe = AndroidBridge.insets.subscribe(applyInsetsToCss);

  // Native мог прислать insets ещё до того, как React смонтировался.
  AndroidBridge.insets.request();

  const refresh = () => {
    if (AndroidBridge.isNative) {
      AndroidBridge.insets.request();
    } else {
      applyInsetsToCss(EMPTY_INSETS);
    }
  };

  window.addEventListener('orientationchange', refresh);
  window.addEventListener('resize', refresh);

  return () => {
    if (unsubscribe) unsubscribe();
    window.removeEventListener('orientationchange', refresh);
    window.removeEventListener('resize', refresh);
    initialized = false;
  };
}

export default initSafeArea;
