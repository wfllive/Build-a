/**
 * Эмулятор Android-моста для обычного браузера.
 *
 * Включается параметром в адресной строке:
 *   ?nativeMock=1            — жестовая навигация (по умолчанию)
 *   ?nativeMock=buttons      — три кнопки навигации
 *   ?nativeMock=1&mockTop=48 — свой статус-бар
 *
 * Зачем: раскладку нативной карты и поведение safe-area можно проверить
 * в десктопном браузере, не собирая APK. Мок повторяет ту же математику,
 * что и MapViewportGeometry.kt (режим insetsMode="auto"), и рисует на экране
 * системные бары и «нативный» WebView карты.
 *
 * В продакшн-бандл не попадает: импортируется динамически и только по флагу.
 */

const STYLE_ID = 'native-mock-style';
const EDGE_SNAP = 48;

function readConfig() {
  const params = new URLSearchParams(window.location.search);
  const mode = params.get('nativeMock');
  const buttons = mode === 'buttons' || mode === 'button' || mode === '3';

  return {
    navigationMode: buttons ? 'buttons' : 'gesture',
    top: Number(params.get('mockTop') || 36),
    bottom: buttons ? 48 : 24,
    tappableBottom: buttons ? 48 : 0,
  };
}

function buildInsets(config) {
  const isLandscape = window.innerWidth > window.innerHeight;
  return {
    px: {},
    css: {
      top: config.top,
      bottom: config.bottom,
      left: 0,
      right: 0,
      tappableBottom: config.tappableBottom,
      tappableLeft: 0,
      tappableRight: 0,
      imeBottom: 0,
      cutoutTop: 0,
      cutoutBottom: 0,
    },
    density: window.devicePixelRatio || 1,
    navigationMode: config.navigationMode,
    isLandscape,
    keyboardVisible: false,
    edgeToEdge: true,
  };
}

function injectStyles() {
  if (document.getElementById(STYLE_ID)) return;
  const style = document.createElement('style');
  style.id = STYLE_ID;
  style.textContent = `
    .native-mock-bar {
      position: fixed; left: 0; right: 0; z-index: 2147483000;
      pointer-events: none; font: 600 10px/1 system-ui, sans-serif;
      display: flex; align-items: center; justify-content: center;
      letter-spacing: .08em; text-transform: uppercase;
    }
    .native-mock-status { top: 0; background: rgba(15,23,42,.55); color: #cbd5f5; }
    .native-mock-nav { bottom: 0; background: rgba(15,23,42,.8); color: #94a3b8; }
    .native-mock-nav.gesture { background: rgba(15,23,42,.25); }
    .native-mock-nav .pill {
      width: 120px; height: 4px; border-radius: 999px; background: rgba(226,232,240,.7);
    }
    .native-mock-map {
      position: fixed; z-index: 2147482000; overflow: hidden;
      background:
        linear-gradient(135deg, rgba(37,99,235,.92), rgba(79,70,229,.92)),
        repeating-linear-gradient(45deg, rgba(255,255,255,.08) 0 12px, transparent 12px 24px);
      color: #fff; font: 500 12px/1.45 system-ui, sans-serif;
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      gap: 6px; text-align: center; padding: 12px;
      box-shadow: inset 0 0 0 2px rgba(255,255,255,.35);
    }
    .native-mock-map b { font-size: 14px; letter-spacing: .04em; }
    .native-mock-map span { opacity: .85; word-break: break-all; }
  `;
  document.head.appendChild(style);
}

function renderSystemBars(config) {
  injectStyles();

  let status = document.querySelector('.native-mock-status');
  if (!status) {
    status = document.createElement('div');
    status.className = 'native-mock-bar native-mock-status';
    status.textContent = 'status bar (mock)';
    document.body.appendChild(status);
  }
  status.style.height = `${config.top}px`;

  let nav = document.querySelector('.native-mock-nav');
  if (!nav) {
    nav = document.createElement('div');
    nav.className = 'native-mock-bar native-mock-nav';
    document.body.appendChild(nav);
  }
  nav.classList.toggle('gesture', config.navigationMode === 'gesture');
  nav.style.height = `${config.bottom}px`;
  nav.innerHTML = config.navigationMode === 'gesture'
    ? '<div class="pill"></div>'
    : '◀ &nbsp; ● &nbsp; ■';
}

/** Та же логика, что в MapViewportGeometry.kt (режим AUTO). */
function resolveRect(rect, viewport, insets, mode) {
  const scaleX = viewport.width > 0 ? window.innerWidth / viewport.width : 1;
  const scaleY = viewport.height > 0 ? window.innerHeight / viewport.height : 1;

  let left = rect.x * scaleX;
  let top = rect.y * scaleY;
  let right = (rect.x + rect.width) * scaleX;
  let bottom = (rect.y + rect.height) * scaleY;

  const hostWidth = window.innerWidth;
  const hostHeight = window.innerHeight;

  left = Math.min(Math.max(left, 0), hostWidth);
  right = Math.min(Math.max(right, 0), hostWidth);
  top = Math.min(Math.max(top, 0), hostHeight);
  bottom = Math.min(Math.max(bottom, 0), hostHeight);

  if (mode === 'safe') {
    top = Math.max(top, insets.css.top);
    bottom = Math.min(bottom, hostHeight - insets.css.bottom);
  } else {
    bottom = Math.min(bottom, hostHeight - insets.css.tappableBottom);
    if (insets.css.tappableBottom === 0 && bottom >= hostHeight - insets.css.bottom - EDGE_SNAP) {
      bottom = hostHeight;
    }
  }

  return { left, top, width: Math.max(0, right - left), height: Math.max(0, bottom - top) };
}

export function installNativeMock() {
  if (typeof window === 'undefined' || window.AndroidBridge) return;

  const config = readConfig();
  let insets = buildInsets(config);
  let lastRequest = null;
  let visible = true;
  // Состояние мока Meteo OS (сбрасывается перезагрузкой страницы).
  const mockOs = { active: null, pending: null };

  const emit = (event, detail) => {
    if (typeof window.__nativeBridgeEmit === 'function') window.__nativeBridgeEmit(event, detail);
    window.dispatchEvent(new CustomEvent(event, { detail }));
  };

  const paint = () => {
    injectStyles();
    renderSystemBars(config);

    let node = document.querySelector('.native-mock-map');
    if (!lastRequest || !visible) {
      if (node) node.remove();
      return;
    }
    if (!node) {
      node = document.createElement('div');
      node.className = 'native-mock-map';
      document.body.appendChild(node);
    }

    const box = resolveRect(lastRequest.rect, lastRequest.viewport, insets, lastRequest.insetsMode);
    node.style.left = `${box.left}px`;
    node.style.top = `${box.top}px`;
    node.style.width = `${box.width}px`;
    node.style.height = `${box.height}px`;
    node.innerHTML =
      `<b>NATIVE MAP (mock)</b>` +
      `<span>${lastRequest.url || ''}</span>` +
      `<span>${Math.round(box.width)} × ${Math.round(box.height)} @ ` +
      `${Math.round(box.left)}, ${Math.round(box.top)}</span>` +
      `<span>insetsMode: ${lastRequest.insetsMode} · nav: ${config.navigationMode}</span>`;
  };

  window.AndroidBridge = {
    bridgeVersion: () => 2,
    ping: () => JSON.stringify({ ok: true, version: 2, mock: true }),
    log: (tag, message) => console.debug(`[native-mock/${tag}]`, message),

    getAppVersion: () => 'mock-9.0.0',
    getDeviceInfo: () =>
      JSON.stringify({
        manufacturer: 'Mock',
        model: 'Browser',
        androidVersion: '15',
        sdkVersion: 35,
        density: window.devicePixelRatio || 1,
        isTablet: window.innerWidth >= 600,
      }),

    getInsets: () => JSON.stringify(insets),
    requestInsets: () => emit('native:insets', insets),
    isDarkMode: () => window.matchMedia('(prefers-color-scheme: dark)').matches,

    getLocationStatus: () => 'granted',
    requestLocationPermission: () => emit('native:locationPermission', { granted: true }),

    mapUpdate: (payload) => {
      lastRequest = JSON.parse(payload);
      visible = lastRequest.visible !== false;
      paint();
      emit('native:map', { status: 'loaded', url: lastRequest.url, visible });
      return JSON.stringify({ ok: true });
    },
    mapSetUrl: (url) => {
      if (lastRequest) lastRequest.url = url;
      paint();
      emit('native:map', { status: 'loaded', url });
    },
    mapShow: () => { visible = true; paint(); },
    mapHide: () => { visible = false; paint(); },
    mapReload: () => emit('native:map', { status: 'loaded', url: lastRequest?.url }),
    mapSuspend: () => { visible = false; paint(); },
    mapRelease: () => { lastRequest = null; paint(); },
    mapStatus: () => JSON.stringify({ status: 'loaded', visible }),

    getAdFreeState: () =>
      JSON.stringify({ adsDisabled: false, adsRemainingMs: 0, cooldownRemainingMs: 0, canActivate: true }),
    isRewardedAdReady: () => false,
    showRewardedAd: () => JSON.stringify({ success: false, reason: 'mock' }),
    activateAdFreeFor5Minutes: () => JSON.stringify({ ok: true }),

    checkForUpdates: () => emit('isLatestVersion'),
    checkIsLatestVersion: () => emit('isLatestVersion'),
    startFlexibleUpdate: () => emit('updateStarted'),
    installUpdate: () => {},

    // ── Meteo OS (OTA веб-бандла) — эмуляция полного цикла ───────────────────
    //
    // У Meteo OS СВОЯ линейка версий (1.x), независимая от версии APK.
    // Дополнительно: ?osMock=requiresAppUpdate — эмулировать случай, когда
    // новая Meteo OS требует более свежее приложение.
    meteoOsGetState: () =>
      JSON.stringify({
        builtinVersion: '1.0.0',
        activeVersion: mockOs.active,
        currentVersion: mockOs.active || '1.0.0',
        source: mockOs.active ? 'ota' : 'builtin',
        pendingVersion: mockOs.pending,
        lastGoodVersion: mockOs.active,
        trialActive: false,
        lastError: null,
        manifestUrl: 'mock://meteo-os.json',
      }),
    meteoOsCheckForUpdates: () => {
      const params = new URLSearchParams(window.location.search);
      const scenario = params.get('osMock');
      setTimeout(() => {
        if (scenario === 'requiresAppUpdate') {
          emit('native:meteoOs', {
            status: 'requiresAppUpdate',
            version: '1.2.0-mock',
            notes: 'Обновление использует новые возможности приложения.',
          });
          return;
        }
        emit('native:meteoOs', {
          status: 'available',
          version: '1.1.0-mock',
          size: 4 * 1024 * 1024,
          notes: 'Тестовое OTA-обновление (эмуляция).\n• Новый установщик\n• Мелкие исправления',
        });
      }, 600);
    },
    meteoOsDownloadUpdate: () => {
      let progress = 0;
      const timer = setInterval(() => {
        progress += 10;
        if (progress >= 100) {
          clearInterval(timer);
          // Прогресс дошёл до 100 — «проверяем подпись/распаковываем»,
          // событие downloaded приходит с задержкой, как в реальности.
          emit('native:meteoOs', { status: 'downloading', progress: 100 });
          setTimeout(() => {
            mockOs.pending = '1.1.0-mock';
            emit('native:meteoOs', { status: 'downloaded' });
          }, 1400);
        } else {
          emit('native:meteoOs', { status: 'downloading', progress });
        }
      }, 300);
    },
    meteoOsApplyUpdate: () => {
      emit('native:meteoOs', { status: 'applying' });
      setTimeout(() => {
        mockOs.active = mockOs.pending || '1.1.0-mock';
        mockOs.pending = null;
        window.location.reload();
      }, 1600);
    },
    meteoOsReportHealthy: () => console.debug('[native-mock] meteoOs.reportHealthy'),
    meteoOsResetToBuiltin: () => {
      mockOs.active = null;
      mockOs.pending = null;
      emit('native:meteoOs', { status: 'reset' });
      setTimeout(() => window.location.reload(), 500);
    },
  };

  window.Android = window.AndroidBridge;
  window.AndroidTheme = {
    setTheme: (theme) => emit('native:theme', { theme, isDark: theme === 'dark' }),
    getCurrentTheme: () => 'auto',
    getSystemTheme: () => (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'),
    isDarkMode: () => window.matchMedia('(prefers-color-scheme: dark)').matches,
  };

  const onResize = () => {
    insets = buildInsets(config);
    emit('native:insets', insets);
    paint();
  };

  window.addEventListener('resize', onResize);
  window.addEventListener('orientationchange', onResize);

  const start = () => {
    renderSystemBars(config);
    emit('native:ready', { version: 2, insets });
    emit('native:insets', insets);
    paint();
  };

  if (document.body) start();
  else document.addEventListener('DOMContentLoaded', start);

  console.info(
    `%c[native-mock] мост эмулируется: навигация = ${config.navigationMode}`,
    'color:#2563eb;font-weight:600'
  );
}

export default installNativeMock;
