


import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

import azTranslations from './locales/az.json';
import beTranslations from './locales/be.json';
import bgTranslations from './locales/bg.json';
import deTranslations from './locales/de.json';
import enTranslations from './locales/en.json';
import esTranslations from './locales/es.json';
import frTranslations from './locales/fr.json';
import hyTranslations from './locales/hy.json';
import jaTranslations from './locales/ja.json';
import kaTranslations from './locales/ka.json';
import kkTranslations from './locales/kk.json';
import kyTranslations from './locales/ky.json';
import ptTranslations from './locales/pt.json';
import ruTranslations from './locales/ru.json';
import tgTranslations from './locales/tg.json';
import uzTranslations from './locales/uz.json';
import zhCNTranslations from './locales/zh-CN.json';
import zhTWTranslations from './locales/zh-TW.json';

const resources = {
  az: { translation: azTranslations },
  be: { translation: beTranslations },
  bg: { translation: bgTranslations },
  de: { translation: deTranslations },
  en: { translation: enTranslations },
  es: { translation: esTranslations },
  fr: { translation: frTranslations },
  hy: { translation: hyTranslations },
  ja: { translation: jaTranslations },
  ka: { translation: kaTranslations },
  kk: { translation: kkTranslations },
  ky: { translation: kyTranslations },
  pt: { translation: ptTranslations },
  ru: { translation: ruTranslations },
  tg: { translation: tgTranslations },
  uz: { translation: uzTranslations },
  'zh-CN': { translation: zhCNTranslations },
  'zh-TW': { translation: zhTWTranslations },
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    supportedLngs: Object.keys(resources),
    nonExplicitSupportedLngs: false,
    fallbackLng: {
      'zh': ['zh-CN'],
      'zh-CN': ['zh-CN'],
      'zh-TW': ['zh-TW'],
      'default': ['ru'],
    },
    interpolation: {
      escapeValue: false,
    },
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage'],
    },
  });

export default i18n;