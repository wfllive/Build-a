


/*
 * ПЕРВЫМ делом — bootstrap: он должен отработать раньше i18n и всего остального.
 * Делает окружение file:// (release-сборка грузит бандл из assets) безопасным:
 * страхует localStorage и отправляет необработанные ошибки JS в Logcat.
 */
import '@/native/bootstrap';

import { initTracerError, initTracerErrorUploader } from '@apptracer/sdk';
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import 'localization/i18n';
import DrawerMenu from 'drawer/Drawer';
import PrivacyPolicy from './PrivacyPolicy';
import LocationPermission from './LocationPermission';
import AppRouter from './router';
import { initSafeArea, AndroidBridge } from '@/native';

initTracerError();
initTracerErrorUploader({
  versionName: '1.0.0',
  versionCode: 1,
  appToken: '8w4sfvU7DvxhArXtv3vTz8Wmy0AqLxopqLsPZMk16w91',
  environment: 'production',
});

/*
 * Мост JS ↔ Android.
 *
 * initSafeArea() подписывается на системные отступы Android и раскладывает их
 * в CSS-переменные (--safe-area-*, --nav-inset, --app-bottom-gap), чтобы вёрстка
 * никогда не оказывалась под статус-баром или кнопками навигации.
 *
 * Всё остальное общение с native — через AndroidBridge (src/native).
 *
 * Отладка в браузере: добавьте ?nativeMock=1 (жесты) или ?nativeMock=buttons
 * (три кнопки) — мост будет эмулирован вместе с раскладкой нативной карты.
 */
if (/[?&]nativeMock=/.test(window.location.search)) {
  import('@/native/devMock').then(({ installNativeMock }) => installNativeMock());
}

initSafeArea();

/*
 * Legacy-колбэки: старые сборки Android зовут именно их.
 * Новый мост шлёт события сам, но эти обёртки оставлены для совместимости.
 */
window.onAndroidLocationPermissionResult = (granted) => {
  window.dispatchEvent(
    new CustomEvent('androidLocationPermissionResult', { detail: granted })
  );
};

window.onAndroidLocationData = (locationData) => {
  window.dispatchEvent(
    new CustomEvent('androidLocationUpdate', { detail: locationData })
  );
};

window.onAndroidLocationError = (errorData) => {
  window.dispatchEvent(
    new CustomEvent('androidLocationError', { detail: errorData })
  );
};

window.receiveAndroidTheme = (theme) => {
  window.dispatchEvent(new CustomEvent('androidThemeApplied', { detail: theme }));
};

const REMIND_HOURS = 24;

const getRemindHoursPassed = () => {
  const saved = parseInt(localStorage.getItem('locationRemindLater'), 10);
  if (!saved) return null;
  return (Date.now() - saved) / (1000 * 60 * 60);
};

const App = () => {
  const [isDrawerOpen,           setIsDrawerOpen]           = useState(false);
  const [showPrivacyPolicy,      setShowPrivacyPolicy]      = useState(false);
  const [showLocationPermission, setShowLocationPermission] = useState(false);
  const [userLocation,           setUserLocation]           = useState(null);
  const [locationDecided,        setLocationDecided]        = useState(false);

  useEffect(() => {
    const hasSeenPrivacy       = !!localStorage.getItem('hasSeenPrivacyPolicy');
    const hasRequestedLocation = !!localStorage.getItem('hasRequestedLocation');
    const hoursPassed          = getRemindHoursPassed();

    if (hasRequestedLocation) {
      setLocationDecided(true);
    }

    if (!hasSeenPrivacy) {
      setShowPrivacyPolicy(true);
      return;
    }

    if (!hasRequestedLocation) {
      if (hoursPassed === null) {
        setTimeout(() => setShowLocationPermission(true), 1000);
      } else if (hoursPassed >= REMIND_HOURS) {
        localStorage.removeItem('locationRemindLater');
        setTimeout(() => setShowLocationPermission(true), 1000);
      } else {
        setLocationDecided(true);
      }
    }
  }, []);

  const toggleDrawer = () => setIsDrawerOpen((prev) => !prev);

  const handlePrivacyClose = () => {
    setShowPrivacyPolicy(false);
    localStorage.setItem('hasSeenPrivacyPolicy', 'true');

    setTimeout(() => {
      const hasRequested = !!localStorage.getItem('hasRequestedLocation');
      const hoursPassed  = getRemindHoursPassed();

      if (!hasRequested && hoursPassed === null) {
        setShowLocationPermission(true);
      } else if (hoursPassed !== null) {
        setLocationDecided(true);
      }
    }, 500);
  };

  const handleLocationClose = () => {
    setShowLocationPermission(false);
    setLocationDecided(true);
  };

  const handleLocationGranted = (location) => {
    setUserLocation(location);
    setLocationDecided(true);
    localStorage.setItem('hasRequestedLocation', 'true');
    localStorage.removeItem('locationRemindLater');
    setShowLocationPermission(false);
  };

  const handleRemindLater = () => {
    localStorage.setItem('locationRemindLater', Date.now().toString());
    setShowLocationPermission(false);
    setLocationDecided(true);
  };

  const openPrivacyPolicy      = () => setShowPrivacyPolicy(true);
  const openLocationPermission = () => {
    localStorage.removeItem('locationRemindLater');
    setShowLocationPermission(true);
  };

  return (
    <DrawerMenu
      isOpen={isDrawerOpen}
      onToggle={toggleDrawer}
      onOpenPrivacyPolicy={openPrivacyPolicy}
      onOpenLocationSettings={openLocationPermission}
    >
      <AppRouter
        toggleDrawer={toggleDrawer}
        isDrawerOpen={isDrawerOpen}
        userLocation={userLocation}
        locationDecided={locationDecided}
      />

      <PrivacyPolicy
        isOpen={showPrivacyPolicy}
        onClose={handlePrivacyClose}
        lastUpdatedDate="16 октября 2025 года"
      />

      <LocationPermission
        isOpen={showLocationPermission}
        onClose={handleLocationClose}
        onGrantPermission={handleLocationGranted}
        onRemindLater={handleRemindLater}
      />
    </DrawerMenu>
  );
};

ReactDOM.createRoot(document.getElementById('root')).render(<App />);

/*
 * Meteo OS: подтверждение работоспособности.
 *
 * Если этот бандл доставлен OTA-обновлением, native ждёт сигнала «интерфейс
 * реально запустился». Без него при следующем старте произойдёт авто-откат
 * на предыдущую рабочую версию. Небольшая задержка — чтобы поймать не только
 * успешный render(), но и мгновенные падения эффектов после монтирования.
 */
setTimeout(() => {
  try {
    const root = document.getElementById('root');
    if (root && root.childElementCount > 0) {
      AndroidBridge.meteoOs.reportHealthy();
    }
  } catch {
    /* моста нет (браузер) — ничего не делаем */
  }
}, 3000);



