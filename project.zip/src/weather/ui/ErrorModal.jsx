

import React from 'react';
import { FaExclamationTriangle, FaMapMarkerAlt, FaRedo, FaCity } from 'react-icons/fa';

const ErrorModal = ({ 
  error, 
  isLoading, 
  setError, 
  locationError, 
  useDefaultLocation,
  getCurrentLocation,
  t
}) => {
  if ((!error && !locationError) || isLoading) return null;

  const handleRetry = () => {
    // Сбрасываем ошибку
    setError(null);
    
    // Если есть функция получения геолокации — вызываем её
    if (getCurrentLocation) {
      getCurrentLocation(true);
    }
  };

  const handleUseDefault = () => {
    setError(null);
    useDefaultLocation();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-5">
      <div className="bg-gray-900/90 rounded-2xl p-6 max-w-sm w-full shadow-2xl border border-white/10">
        
        {/* Иконка */}
        <div className="flex justify-center mb-4">
          {locationError ? (
            <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center">
              <FaMapMarkerAlt className="text-3xl text-red-400" />
            </div>
          ) : (
            <div className="w-16 h-16 bg-yellow-500/20 rounded-full flex items-center justify-center">
              <FaExclamationTriangle className="text-3xl text-yellow-400" />
            </div>
          )}
        </div>

        {/* Текст ошибки */}
        <p className="text-center text-white text-base mb-6 leading-relaxed">
          {error || t('locationError')}
        </p>

        {/* Кнопки */}
        <div className="flex flex-col gap-3">
          {/* Попробовать снова — всегда повторяет запрос геолокации */}
          <button 
            className="w-full px-6 py-3 bg-blue-500 hover:bg-blue-600 active:bg-blue-700 
                       text-white rounded-xl transition-colors flex items-center justify-center gap-2
                       font-medium"
            onClick={handleRetry}
          >
            <FaRedo className="text-sm" />
            {t('tryAgain')}
          </button>

          {/* Использовать Москву */}
          <button 
            className="w-full px-6 py-3 bg-gray-700 hover:bg-gray-600 active:bg-gray-500 
                       text-white rounded-xl transition-colors flex items-center justify-center gap-2
                       font-medium"
            onClick={handleUseDefault}
          >
            <FaCity className="text-sm" />
            {t('useDefaultLocation')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ErrorModal;