// components/LoadingIndicator.jsx
import React from 'react';
import { FaCircleNotch } from 'react-icons/fa';

const LoadingIndicator = ({ isLoading, t }) => {
  if (!isLoading) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/70 backdrop-blur-md">
      <FaCircleNotch className="text-5xl text-blue-400 animate-spin mb-4" />
      <p className="text-xl text-white">{t('loading')}</p>
    </div>
  );
};

export default LoadingIndicator;