


import React, { useEffect, useState } from 'react';
import { FaSearch, FaTimes, FaPlus, FaMapMarkerAlt, FaLocationArrow } from 'react-icons/fa';

// Упрощенная, более строгая подсветка текста (без цветных фонов)
const HighlightedText = ({ text, highlight }) => {
  if (!highlight || !text) return <span>{text}</span>;
  const parts = text.split(new RegExp(`(${highlight})`, 'gi'));
  
  return (
    <span>
      {parts.map((part, i) => 
        part.toLowerCase() === highlight.toLowerCase() ? (
          <span key={i} className="text-white font-semibold">{part}</span>
        ) : (
          <span key={i} className="text-white/60">{part}</span>
        )
      )}
    </span>
  );
};

const SearchModal = ({ 
  showSearch, 
  setShowSearch, 
  searchQuery, 
  setSearchQuery, 
  searchResults, 
  addSavedCity, 
  savedCities, 
  removeSavedCity, 
  fetchWeather, 
  setActiveTab,
  t
}) => {
  const [render, setRender] = useState(false);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (showSearch) {
      setRender(true);
      setTimeout(() => setVisible(true), 10);
    } else {
      setVisible(false);
      setTimeout(() => {
        setRender(false);
        setSearchQuery('');
      }, 300);
    }
  }, [showSearch, setSearchQuery]);

  if (!render) return null;

  const handleCitySelect = (name, country) => {
    fetchWeather(`${name}, ${country}`);
    setActiveTab('home');
    setShowSearch(false);
  };

  return (
    <div 
      className={`fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4 transition-all duration-300
        ${visible ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}
      `}
    >
      {/* Строгий темный фон */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
        onClick={() => setShowSearch(false)}
      />

      <div 
        // Чистое матовое стекло без свечений, с тонкой белой рамкой
        className={`relative w-full max-w-lg max-h-[90vh] sm:max-h-[85vh] flex flex-col
          bg-[#1C1C1E]/80 backdrop-blur-2xl border border-white/10 shadow-2xl
          rounded-t-[2rem] sm:rounded-[2rem] overflow-hidden transition-transform duration-400 ease-out
          ${visible ? 'translate-y-0 sm:scale-100' : 'translate-y-full sm:translate-y-8 sm:scale-95'}
        `}
      >
        {/* iOS-стиль индикатор свайпа */}
        <div className="w-10 h-1.5 bg-white/20 rounded-full mx-auto mt-3 sm:hidden" />

        <div className="flex-shrink-0 px-5 pt-4 pb-3 sm:pt-6">
          <div className="flex justify-between items-center mb-5">
            <h2 className="text-xl sm:text-2xl font-semibold text-white tracking-tight">{t('searchCity')}</h2>
            <button 
              className="p-2 rounded-full bg-white/5 hover:bg-white/15 active:scale-95 transition-all"
              onClick={() => setShowSearch(false)}
            >
              <FaTimes className="text-lg text-white/70" />
            </button>
          </div>
          
          <div className="relative">
            <FaSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/40 text-base" />
            <input
              type="text"
              placeholder={t('enterCityName')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full py-3.5 pl-11 pr-10 bg-white/10 rounded-xl text-white text-[17px] placeholder-white/40 focus:outline-none focus:bg-white/15 transition-colors"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1.5 rounded-full text-white/40 hover:text-white/80 transition-colors"
              >
                <FaTimes className="text-sm" />
              </button>
            )}
          </div>
        </div>
        
        {/* Контент: Группированные списки (iOS List Style) */}
        <div className="flex-1 overflow-y-auto px-5 pb-8 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          
          {searchQuery && (
            <div className="mb-8">
              <h3 className="text-[13px] font-semibold uppercase tracking-wider text-white/40 mb-2 ml-1">{t('results', 'Результаты')}</h3>
              
              {searchResults.length > 0 ? (
                <div className="bg-white/5 rounded-2xl overflow-hidden border border-white/5 divide-y divide-white/5">
                  {searchResults.map((location, i) => (
                    <div 
                      key={i} 
                      className="group flex justify-between items-center p-4 hover:bg-white/5 active:bg-white/10 cursor-pointer transition-colors"
                      onClick={() => handleCitySelect(location.name, location.country)}
                    >
                      <div className="flex items-center gap-4">
                        <FaLocationArrow className="text-white/30 transform -rotate-45 text-lg" />
                        <div>
                          <div className="text-[17px]">
                            <HighlightedText text={location.name} highlight={searchQuery} />
                          </div>
                          <div className="text-sm text-white/40 mt-0.5">{location.country}, {location.region}</div>
                        </div>
                      </div>
                      
                      {!savedCities.some(c => c.name === location.name && c.country === location.country) && (
                        <button 
                          className="p-2 text-blue-400 hover:text-blue-300 active:scale-90 transition-all"
                          onClick={(e) => {
                            e.stopPropagation();
                            addSavedCity({
                              name: location.name,
                              country: location.country,
                              region: location.region,
                              lat: location.lat,
                              lon: location.lon
                            });
                          }}
                        >
                          <FaPlus className="text-xl" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-white/40 bg-white/5 rounded-2xl border border-white/5">
                  <span className="text-[15px]">{t('noResults', 'Ничего не найдено')}</span>
                </div>
              )}
            </div>
          )}
          
          <div>
            <h3 className="text-[13px] font-semibold uppercase tracking-wider text-white/40 mb-2 ml-1">{t('savedCities')}</h3>
            
            {savedCities.length > 0 ? (
              <div className="bg-white/5 rounded-2xl overflow-hidden border border-white/5 divide-y divide-white/5">
                {savedCities.map((city, i) => (
                  <div 
                    key={i} 
                    className="group flex items-center p-4 hover:bg-white/5 active:bg-white/10 cursor-pointer transition-colors"
                    onClick={() => handleCitySelect(city.name, city.country)}
                  >
                    <FaMapMarkerAlt className="text-blue-400/80 text-xl mr-4" />
                    <div className="flex-1">
                      <div className="text-[17px] font-medium text-white/90">{city.name}</div>
                      <div className="text-sm text-white/40 mt-0.5">{city.country}{city.region && `, ${city.region}`}</div>
                    </div>
                    <button 
                      className="p-2 text-white/20 hover:text-red-400 active:scale-90 transition-all"
                      onClick={(e) => {
                        e.stopPropagation();
                        removeSavedCity(i);
                      }}
                    >
                      <FaTimes className="text-lg" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-white/40 bg-white/5 rounded-2xl border border-white/5">
                <span className="text-[15px]">{t('noSavedCities')}</span>
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};

export default SearchModal;