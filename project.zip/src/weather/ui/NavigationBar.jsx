import React, { useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate, useLocation } from 'react-router-dom';
import { FaHome, FaMapMarkerAlt, FaStar, FaCog } from 'react-icons/fa';
import TabButton from './TabButton';
import { animated, useSpring } from '@react-spring/web';
import { useTabBarSpace } from '@/native';

const TABS = [
  { id: 'home',      path: '/',          icon: <FaHome className="text-xl" />,         labelKey: 'tabs.home'      },
  { id: 'map',       path: '/map',       icon: <FaMapMarkerAlt className="text-xl" />, labelKey: 'tabs.map'       },
  { id: 'favorites', path: '/favorites', icon: <FaStar className="text-xl" />,         labelKey: 'tabs.favorites' },
  { id: 'settings',  path: '/settings',  icon: <FaCog className="text-xl" />,          labelKey: 'tabs.settings'  },
];

const NavigationBar = () => {
  const { t }        = useTranslation();
  const navigate     = useNavigate();
  const { pathname } = useLocation();

  const containerRef = useRef(null);
  const circleRef    = useRef(null);

  /*
   * Панель вкладок — единственный веб-элемент, который живёт в той же зоне,
   * что и нативный WebView карты. Нативный WebView рисуется ПОВЕРХ веба,
   * поэтому карта обязана заканчиваться выше панели И выше круга активной
   * вкладки (он выступает над панелью).
   *
   * Хук меряет фактическую занятую высоту (панель + выступ круга + системный
   * отступ снизу) и кладёт её в CSS-переменную --tabbar-space, которой
   * пользуется слот карты. Никаких магических констант.
   */
  useTabBarSpace({ containerRef, overhangRef: circleRef, gap: 10 });

  const activeIndex = Math.max(
    0,
    TABS.findIndex((tab) => tab.path === pathname)
  );

  const circleSpring = useSpring({
    x: activeIndex * (100 / TABS.length) + (50 / TABS.length),
    config: { tension: 300, friction: 20 },
  });

  const handleTabChange = (tab) => {
    navigate(tab.path, { replace: true });
  };

  return (
    <div
      ref={containerRef}
      className="fixed bottom-0 left-0 right-0 z-50 px-4"
      // --app-bottom-gap приходит из Android (см. src/native/safeArea.js):
      // при жестовой навигации это небольшой отступ, при 3 кнопках — высота
      // системной панели, чтобы вкладки не оказались под кнопками.
      style={{ paddingBottom: 'var(--app-bottom-gap, calc(env(safe-area-inset-bottom, 0px) + 8px))' }}
    >
      <div className="mx-auto w-full max-w-md">
        <div className="relative h-16 rounded-[24px] border border-white/20 bg-white/10 backdrop-blur-lg dark:border-gray-600/50 dark:bg-gray-800/40">

          {/* Скользящий круг (выступает над панелью — его тоже измеряем) */}
          <animated.div
            ref={circleRef}
            className="absolute bottom-9 w-12 h-12 rounded-full bg-blue-500 -translate-x-1/2"
            style={{
              left: circleSpring.x.to((x) => `${x}%`),
            }}
          />

          {/* Табы */}
          <div
            className="grid h-full items-end"
            style={{ gridTemplateColumns: `repeat(${TABS.length}, minmax(0, 1fr))` }}
          >
            {TABS.map((tab) => (
              <TabButton
                key={tab.id}
                item={{ ...tab, label: t(tab.labelKey) }}
                isActive={pathname === tab.path}
                onClick={() => handleTabChange(tab)}
              />
            ))}
          </div>

        </div>
      </div>
    </div>
  );
};

export default NavigationBar;
