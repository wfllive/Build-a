
import React from 'react';
import { FaBars, FaLocationArrow, FaSearch, FaSync, FaTimes } from 'react-icons/fa';
import { useTranslation } from 'react-i18next';

const Header = ({ 
  toggleDrawer, 
  getCurrentLocation, 
  setShowSearch, 
  locationName,
  handleRefresh,
  isRefreshing,
  lastUpdateTime,
  isDrawerOpen
}) => {
  const { t } = useTranslation();

  const formatRelativeTime = (timestamp) => {
    if (!timestamp) return t('neverUpdated');
    
    const now = new Date().getTime();
    const diffInSeconds = Math.floor((now - timestamp) / 1000);
    
    if (diffInSeconds < 60) {
      return t('justNow');
    }
    
    const diffInMinutes = Math.floor(diffInSeconds / 60);
    if (diffInMinutes < 60) {
      return t('minutesAgo', { count: diffInMinutes });
    }
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) {
      return t('hoursAgo', { count: diffInHours });
    }
    
    const diffInDays = Math.floor(diffInHours / 24);
    return t('daysAgo', { count: diffInDays });
  };

  return (
    <div className="sticky top-0 z-50">
      <div className="container mx-auto px-4 pt-3">
        <div className="flex items-center justify-between">
          <div className="flex space-x-3">
            <button 
              onClick={toggleDrawer}
              className="text-2xl p-2 text-white hover:text-blue-200 transition-colors"
              aria-label={isDrawerOpen ? "Close menu" : "Open menu"}
            >
              {isDrawerOpen ? (
                <FaTimes className="text-white-400 hover:text-white-300" />
              ) : (
                <FaBars />
              )}
            </button>
            <button 
              onClick={() => getCurrentLocation(true)}
              className="text-2xl p-2 text-white hover:text-blue-200 transition-colors"
              aria-label="Current location"
            >
              <FaLocationArrow />
            </button>
          </div>

          <div className="flex space-x-3">
            <button 
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="text-2xl p-2 text-white hover:text-blue-200 transition-colors"
              aria-label="Refresh"
            >
              <FaSync className={isRefreshing ? 'animate-spin' : ''} />
            </button>
            <button 
              onClick={() => setShowSearch(true)}
              className="text-2xl p-2 text-white hover:text-blue-200 transition-colors"
              aria-label="Search"
            >
              <FaSearch />
            </button>
          </div>
        </div>

        <div className="flex justify-center mt-2 pb-3">
          <div className="text-center">
            <h1 
              className="font-bold text-white"
              style={{ fontSize: 'clamp(1rem, 4vw, 1.5rem)' }}
            >
              {locationName || t('selectLocation')}
            </h1>
            {lastUpdateTime && (
              <p className="text-xs text-white/80 mt-1">
                {t('lastUpdated')}: {formatRelativeTime(lastUpdateTime)}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;



