


// раб

import React from 'react';
import { animated, useSpring } from '@react-spring/web';

const TabButton = ({ item, isActive, onClick }) => {
  // Анимация иконки
  const iconSpring = useSpring({
    scale: isActive ? 1.2 : 1,
    translateY: isActive ? -12 : 7,
    config: { tension: 300, friction: 20 }
  });

  // Анимация текста
  const textSpring = useSpring({
    opacity: isActive ? 1 : 0.6,
    scale: isActive ? 1 : 0.9,
    config: { tension: 300, friction: 20 }
  });

  return (
    <button
      onClick={onClick}
      className="relative flex flex-col items-center justify-end h-full pb-2 w-full focus:outline-none z-10"
    >
      <animated.div
        className="relative mb-1"
        style={{
          scale: iconSpring.scale,
          translateY: iconSpring.translateY
        }}
      >
        <animated.div 
          className="relative z-10 flex items-center justify-center w-12 h-8 rounded-full text-white"
          style={{
            opacity: textSpring.opacity
          }}
        >
          {item.icon}
        </animated.div>
      </animated.div>
      
      <animated.div
        className="text-xs font-medium text-white"
        style={{
          opacity: textSpring.opacity,
          scale: textSpring.scale
        }}
      >
        {item.label}
      </animated.div>
    </button>
  );
};

export default TabButton;