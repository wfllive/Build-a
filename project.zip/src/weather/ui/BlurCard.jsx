import React from 'react';

const BlurCard = ({ children }) => (
  <div className="bg-white/20 dark:bg-gray-800/40 backdrop-blur-lg rounded-2xl p-4 mb-4 shadow-lg">
    {children}
  </div>
);

export default BlurCard;