import React, { useState, useEffect } from 'react';
import { animated, useSpring } from '@react-spring/web';

const TemperatureColorBar = ({ minTemp, maxTemp, currentTemp, units }) => {
  const [gradientColors, setGradientColors] = useState([]);

  const barAnimation = useSpring({
    from: { width: '0%' },
    to: { width: '100%' },
    config: { duration: 1000 }
  });

  // ✅ Исправлено: просто отображаем значение, без повторной конвертации
  const formatTemp = (temp) => {
    const unit = units === 'metric' ? '°C' : '°F';
    return `${Math.round(temp)}${unit}`;
  };

  // ✅ Исправлено: для градиента нужны Celsius-значения
  // Если units === 'imperial', конвертируем обратно в Celsius для расчёта цвета
  const toCelsius = (temp) => {
    if (units === 'metric') return temp;
    return (temp - 32) * 5 / 9;
  };

  useEffect(() => {
    const minCelsius = toCelsius(minTemp);
    const maxCelsius = toCelsius(maxTemp);
    const steps = 100;
    const colors = [];
    const tempRange = maxCelsius - minCelsius;

    // Защита от деления на 0
    if (tempRange === 0) {
      const hue = minCelsius < 0
        ? 240 - ((minCelsius + 40) / 40) * 120
        : 120 - (minCelsius / 40) * 120;
      colors.push(`hsl(${Math.max(0, Math.min(240, hue))}, 100%, 50%)`);
      setGradientColors(colors);
      return;
    }

    for (let i = 0; i <= steps; i++) {
      const temp = minCelsius + (tempRange * i) / steps;
      const hue = temp < 0
        ? 240 - ((temp + 40) / 40) * 120
        : 120 - (temp / 40) * 120;
      colors.push(`hsl(${Math.max(0, Math.min(240, hue))}, 100%, 50%)`);
    }

    setGradientColors(colors);
  }, [minTemp, maxTemp, units]);

  return (
    <div className="w-full mb-4">
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-white min-w-[50px] text-left">
          {formatTemp(minTemp)}
        </span>

        <div className="flex-1 relative h-3 bg-gray-300/20 rounded-full overflow-hidden">
          <animated.div
            className="absolute h-full rounded-full"
            style={{
              ...barAnimation,
              background: gradientColors.length > 0
                ? `linear-gradient(to right, ${gradientColors.join(', ')})`
                : 'transparent'
            }}
          />
        </div>

        <span className="text-sm font-medium text-white min-w-[50px] text-right">
          {formatTemp(maxTemp)}
        </span>
      </div>
    </div>
  );
};

export default TemperatureColorBar;