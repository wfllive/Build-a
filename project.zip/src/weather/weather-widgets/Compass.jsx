

import React, { useMemo } from 'react';

const DIRECTIONS = [
  { key: 'N', shortRu: 'С', longRu: 'Севера' },
  { key: 'NNE', shortRu: 'ССВ', longRu: 'Северо-северо-востока' },
  { key: 'NE', shortRu: 'СВ', longRu: 'Северо-востока' },
  { key: 'ENE', shortRu: 'ВСВ', longRu: 'Востоко-северо-востока' },
  { key: 'E', shortRu: 'В', longRu: 'Востока' },
  { key: 'ESE', shortRu: 'ВЮВ', longRu: 'Востоко-юго-востока' },
  { key: 'SE', shortRu: 'ЮВ', longRu: 'Юго-востока' },
  { key: 'SSE', shortRu: 'ЮЮВ', longRu: 'Юго-юго-востока' },
  { key: 'S', shortRu: 'Ю', longRu: 'Юга' },
  { key: 'SSW', shortRu: 'ЮЮЗ', longRu: 'Юго-юго-запада' },
  { key: 'SW', shortRu: 'ЮЗ', longRu: 'Юго-запада' },
  { key: 'WSW', shortRu: 'ЗЮЗ', longRu: 'Западо-юго-запада' },
  { key: 'W', shortRu: 'З', longRu: 'Запада' },
  { key: 'WNW', shortRu: 'ЗСЗ', longRu: 'Западо-северо-запада' },
  { key: 'NW', shortRu: 'СЗ', longRu: 'Северо-запада' },
  { key: 'NNW', shortRu: 'ССЗ', longRu: 'Северо-северо-запада' },
];

const DIRECTION_MAP = Object.fromEntries(
  DIRECTIONS.map((item, index) => [item.key, { ...item, degrees: index * 22.5 }])
);

const normalizeDegrees = (value) => ((value % 360) + 360) % 360;

const parseNumeric = (value) => {
  if (typeof value === 'number') return Number.isFinite(value) ? value : NaN;
  if (typeof value === 'string') {
    const match = value.trim().replace(',', '.').match(/-?\d+(\.\d+)?/);
    return match ? Number(match[0]) : NaN;
  }
  return NaN;
};

const parseWindDirection = (value) => {
  const numeric = parseNumeric(value);
  if (Number.isFinite(numeric)) return normalizeDegrees(numeric);
  if (typeof value === 'string') {
    const normalized = value.trim().toUpperCase();
    return DIRECTION_MAP[normalized]?.degrees ?? null;
  }
  return null;
};

const getDirectionMeta = (degrees) => {
  if (!Number.isFinite(degrees)) return null;
  return DIRECTIONS[Math.round(normalizeDegrees(degrees) / 22.5) % 16];
};

const formatSpeed = (value) => {
  const numeric = parseNumeric(value);
  if (!Number.isFinite(numeric)) return '--';
  return Number.isInteger(numeric) ? String(numeric) : numeric.toFixed(1);
};

const getWindState = (value) => {
  const speed = parseNumeric(value);
  if (!Number.isFinite(speed)) return { label: 'Нет данных', color: '#94a3b8', icon: '—' };
  if (speed < 1.5) return { label: 'Штиль', color: '#cbd5e1', icon: '○' };
  if (speed < 12) return { label: 'Слабый ветер', color: '#7dd3fc', icon: '~' };
  if (speed < 25) return { label: 'Умеренный ветер', color: '#38bdf8', icon: '≈' };
  if (speed < 40) return { label: 'Сильный ветер', color: '#22d3ee', icon: '≋' };
  return { label: 'Очень сильный', color: '#f59e0b', icon: '⚡' };
};

const WindArrow = ({ degrees, color, isCalm }) => {
  if (isCalm) {
    return (
      <svg viewBox="0 0 48 48" className="h-12 w-12" aria-hidden="true">
        <circle
          cx="24"
          cy="24"
          r="8"
          fill="none"
          stroke={color}
          strokeWidth="2"
          opacity="0.5"
        />
        <circle cx="24" cy="24" r="3" fill={color} opacity="0.7" />
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 48 48"
      className="h-12 w-12"
      style={{ transform: `rotate(${degrees + 180}deg)` }}
      aria-hidden="true"
    >
      <line
        x1="24"
        y1="38"
        x2="24"
        y2="12"
        stroke={color}
        strokeWidth="2.5"
        strokeLinecap="round"
      />
      <path
        d="M16 20 L24 10 L32 20"
        fill="none"
        stroke={color}
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

const Compass = ({ windSpeed, windDirection, unit = 'км/ч' }) => {
  const speedValue = useMemo(() => parseNumeric(windSpeed), [windSpeed]);
  const speedText = useMemo(() => formatSpeed(windSpeed), [windSpeed]);
  const state = useMemo(() => getWindState(windSpeed), [windSpeed]);
  const degrees = useMemo(() => parseWindDirection(windDirection), [windDirection]);
  const fromMeta = useMemo(() => getDirectionMeta(degrees), [degrees]);

  const isCalm = Number.isFinite(speedValue) && speedValue < 1.5;
  const hasDirection = Number.isFinite(degrees);

  return (
    <div className="p-4">
      {/* Заголовок */}
      <h3 className="mb-3 text-center text-xl font-semibold text-white">
        Ветер
      </h3>

      {/* Основной блок: стрелка + скорость */}
      <div className="flex items-center justify-center gap-4">
        <WindArrow
          degrees={degrees}
          color={state.color}
          isCalm={isCalm}
        />

        <div>
          <div className="text-3xl font-bold leading-none text-white">
            {speedText}
          </div>
          <div className="mt-1 text-xs text-gray-400">
            {unit}
          </div>
        </div>
      </div>

      {/* Статус */}
      <div className="mt-3 text-center">
        <span
          className="inline-block rounded-full px-3 py-1 text-xs font-medium"
          style={{
            color: state.color,
            backgroundColor: `${state.color}15`,
            border: `1px solid ${state.color}30`,
          }}
        >
          {state.label}
        </span>
      </div>

      {/* Направление */}
      {!isCalm && hasDirection && fromMeta && (
        <p className="mt-2 text-center text-sm text-gray-300">
          Дует с {fromMeta.longRu}
        </p>
      )}

      {isCalm && (
        <p className="mt-2 text-center text-sm text-gray-400">
          Воздух почти неподвижен
        </p>
      )}
    </div>
  );
};

export default Compass;