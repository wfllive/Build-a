

import React from 'react';
import { FaWind, FaTint, FaCloudRain } from 'react-icons/fa';
import BlurCard from 'weather-ui/BlurCard';
import { getWeatherIcon } from 'weather-icons/WeatherIcons';

const WeatherDisplay = ({ weatherData, forecastData, t, getTemp, getWindSpeed, getPrecip }) => {
  if (!weatherData?.current || !forecastData?.forecast?.forecastday?.[0]) {
    return (
      <div className="text-center text-gray-400 py-8">
        {t('common.loading')}
      </div>
    );
  }

  const { current } = weatherData;
  const todayForecast = forecastData.forecast.forecastday[0];

  return (
    <>
      <div className="flex flex-col items-center">
        <div className="text-6xl my-4">
          {getWeatherIcon(current.condition.code, current.is_day === 1, 'large')}
        </div>
        <div className="text-7xl font-light my-2 text-white">
          {getTemp(current.temp_c, current.temp_f)}°
        </div>
        <div className="text-xl text-center my-2 text-white">
          {current.condition.text}
        </div>
        <div className="text-lg text-gray-200 my-1">
          {t('feelsLike')} {getTemp(current.feelslike_c, current.feelslike_f)}°
        </div>
      </div>
      
      <div className="flex justify-around mt-6 pt-6 border-t border-white/20">
        {[
          { 
            icon: <FaWind className="text-xl text-white" />, 
            value: getWindSpeed(current.wind_kph || 0), 
            label: t('wind') 
          },
          { 
            icon: <FaTint className="text-xl text-white" />, 
            value: `${current.humidity || 0}%`, 
            label: t('humidity') 
          },
          { 
            icon: <FaCloudRain className="text-xl text-white" />, 
            value: getPrecip(todayForecast.day.totalprecip_mm || 0), 
            label: t('precipitation') 
          }
        ].map((item, index) => (
          <div key={index} className="flex flex-col items-center mb-5">
            {item.icon}
            <div className="font-semibold mt-1 text-white mt-5">{item.value}</div>
            <div className="text-sm text-gray-200 mt-1">{item.label}</div>
          </div>
        ))}
      </div>
    </>
  );
};

export default WeatherDisplay;
