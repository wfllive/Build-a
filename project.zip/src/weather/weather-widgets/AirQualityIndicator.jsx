


import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
// Импортируем иконки, соответствующие дизайну
import { FaLeaf, FaSun, FaCloudSun, FaSmog, FaBolt, FaBiohazard, FaExclamationTriangle } from 'react-icons/fa';

// ИЗМЕНЕНО: Ключи в labelKey обновлены, чтобы соответствовать вашей новой структуре JSON
const AIR_LEVELS = [
  { // Excellent
    color: '#00FF88',
    icon: <FaLeaf />,
    labelKey: 'airQuality.excellent', // Ключ теперь 'airQuality.excellent'
    textColor: '#000'
  },
  { // Good
    color: '#FFEA00',
    icon: <FaSun />,
    labelKey: 'airQuality.good', // Ключ теперь 'airQuality.good'
    textColor: '#000'
  },
  { // Moderate
    color: '#FF9500',
    icon: <FaCloudSun />,
    labelKey: 'airQuality.moderate', // и так далее...
    textColor: '#000'
  },
  { // Poor
    color: '#FF3B30',
    icon: <FaSmog />,
    labelKey: 'airQuality.poor',
    textColor: '#FFF'
  },
  { // Very Poor
    color: '#AF52DE',
    icon: <FaBolt />,
    labelKey: 'airQuality.veryPoor',
    textColor: '#FFF'
  },
  { // Hazardous
    color: '#FF2D55',
    icon: <FaBiohazard />,
    labelKey: 'airQuality.hazardous',
    textColor: '#FFF'
  }
];

const AirQualityIndicator = ({ epaIndex }) => {
  const { t } = useTranslation();

  const levelIndex = epaIndex ? Math.max(0, Math.min(Math.floor(epaIndex) - 1, AIR_LEVELS.length - 1)) : null;

  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (levelIndex !== null && epaIndex) {
        const calculatedProgress = (epaIndex / AIR_LEVELS.length) * 100;
        setProgress(Math.min(calculatedProgress, 100));
      } else {
        setProgress(0);
      }
    }, 100);

    return () => clearTimeout(timer);
  }, [epaIndex, levelIndex]);

  // --- Состояние "Нет данных" ---
  if (levelIndex === null || epaIndex === undefined) {
    return (
      <div className="flex flex-col items-center justify-center rounded-2xl p-5 bg-zinc-800">
        <FaExclamationTriangle size={32} className="text-white/80" />
        <p className="mt-3 text-white/90 text-base font-semibold" style={{ textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}>
          {/* ИЗМЕНЕНО: Ключ для сообщения "Нет данных" */}
          {t('airQuality.noData')}
        </p>
      </div>
    );
  }

  const currentLevel = AIR_LEVELS[levelIndex];

  return (
    <div className="rounded-2xl p-5">
      {/* Заголовок */}
      <div className="flex items-center mb-4">
        <div 
          className="w-11 h-11 rounded-full flex justify-center items-center mr-3 border-2 border-white/30"
          style={{ backgroundColor: `${currentLevel.color}80` }}
        >
          {React.cloneElement(currentLevel.icon, { size: 24, color: currentLevel.textColor })}
        </div>
        <h2 
          className="text-lg font-extrabold text-white"
          style={{ textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}
        >
          {/* ИЗМЕНЕНО: Ключ для заголовка */}
          {t('airQualityv')}
        </h2>
      </div>

      {/* Основной контент */}
      <div className="flex justify-between items-center mb-5">
        <p 
          className="text-2xl font-extrabold flex-1"
          style={{ color: currentLevel.color, textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}
        >
          {/* Здесь ничего менять не нужно, `labelKey` уже обновлен в массиве */}
          {t(currentLevel.labelKey)}
        </p>
        <p 
          className="text-5xl font-black ml-4"
          style={{ color: currentLevel.color, textShadow: '0 2px 4px rgba(0,0,0,0.5)' }}
        >
          {epaIndex}
        </p>
      </div>

      {/* Прогресс-бар и шкала */}
      <div className="mt-2.5">
        <div 
          className="h-2.5 rounded-full overflow-hidden"
          style={{ backgroundColor: `${currentLevel.color}30` }}
        >
          <div 
            className="h-full rounded-full transition-all duration-1500 ease-out"
            style={{
              width: `${progress}%`,
              backgroundColor: currentLevel.color,
              boxShadow: `0 0 8px ${currentLevel.color}, 0 0 4px ${currentLevel.color}`
            }}
          />
        </div>
        <div className="flex justify-between px-0.5 mt-2">
          {AIR_LEVELS.map((level, i) => (
            <div 
              key={i} 
              className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ease-in-out ${i <= levelIndex ? 'scale-125' : ''}`}
              style={{ backgroundColor: i <= levelIndex ? currentLevel.color : 'rgba(255, 255, 255, 0.2)' }}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default AirQualityIndicator;

