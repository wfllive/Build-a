


import React, { useCallback, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { FaSun } from 'react-icons/fa';

const SunriseSunsetCard = ({
  sunrise,
  sunset,
  currentTime,
  timeFormat = 24,
  timezone,
}) => {
  const { t } = useTranslation();

  const parseTimeString = useCallback((timeStr) => {
    if (!timeStr) return { hours: 6, minutes: 0 };

    const [timePart, period] = timeStr.split(' ');
    let [hours, minutes] = timePart.split(':').map(Number);

    if (period === 'PM' && hours !== 12) hours += 12;
    else if (period === 'AM' && hours === 12) hours = 0;

    return { hours, minutes };
  }, []);

  const formatTime = useCallback(
    (timeStr) => {
      if (!timeStr) return '--:--';

      try {
        const { hours, minutes } = parseTimeString(timeStr);

        if (timeFormat === 12) {
          const date = new Date();
          date.setHours(hours, minutes);
          return date.toLocaleTimeString([], {
            hour: 'numeric',
            minute: '2-digit',
            hour12: true,
            timeZone: timezone,
          });
        }

        return `${hours.toString().padStart(2, '0')}:${minutes
          .toString()
          .padStart(2, '0')}`;
      } catch (error) {
        console.error('Error formatting time:', error);
        return '--:--';
      }
    },
    [timeFormat, parseTimeString, timezone]
  );

  const calculateArcProgress = useCallback(() => {
    if (!sunrise || !sunset || !currentTime) return 0.5;

    try {
      const now = new Date(currentTime);
      const { hours: sunriseHours, minutes: sunriseMinutes } = parseTimeString(sunrise);
      const { hours: sunsetHours, minutes: sunsetMinutes } = parseTimeString(sunset);

      const sunriseTime = new Date(now);
      sunriseTime.setHours(sunriseHours, sunriseMinutes, 0, 0);

      const sunsetTime = new Date(now);
      sunsetTime.setHours(sunsetHours, sunsetMinutes, 0, 0);

      if (sunsetTime < sunriseTime) sunsetTime.setDate(sunsetTime.getDate() + 1);

      const totalDayLength = sunsetTime - sunriseTime;
      const currentProgress = now - sunriseTime;

      return Math.min(Math.max(currentProgress / totalDayLength, 0), 1);
    } catch (error) {
      console.error('Error calculating arc progress:', error);
      return 0.5;
    }
  }, [currentTime, sunrise, sunset, parseTimeString]);

  const daylightDuration = useMemo(() => {
    if (!sunrise || !sunset) return '--:--';

    try {
      const { hours: sunriseHours, minutes: sunriseMinutes } = parseTimeString(sunrise);
      const { hours: sunsetHours, minutes: sunsetMinutes } = parseTimeString(sunset);

      const sunriseTotal = sunriseHours * 60 + sunriseMinutes;
      const sunsetTotal = sunsetHours * 60 + sunsetMinutes;

      let diff = sunsetTotal - sunriseTotal;
      if (diff < 0) diff += 24 * 60;

      const hours = Math.floor(diff / 60);
      const minutes = diff % 60;

      return `${hours.toString().padStart(2, '0')}:${minutes
        .toString()
        .padStart(2, '0')}`;
    } catch (error) {
      console.error('Error calculating daylight duration:', error);
      return '--:--';
    }
  }, [sunrise, sunset, parseTimeString]);

  const progress = calculateArcProgress();
  const arcColor = `hsl(${30 + (210 - 30) * (1 - progress)}, 100%, 50%)`;

  if (!sunrise || !sunset) {
    return (
      <div className="p-2">
        <h2 className="mb-3 text-center text-base font-semibold text-white">
          {t('sun.sunriseSunset')}
        </h2>
        <div className="text-center text-sm text-gray-400">
          {t('common.noData')}
        </div>
      </div>
    );
  }

  return (
    <div className="p-2">
      <h2 className="mb-3 text-center text-base font-semibold text-white">
        {t('sun.sunriseSunset')}
      </h2>

      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-xl border border-yellow-400/15 bg-yellow-400/5 px-3 py-2 text-center">
          <div className="mx-auto mb-1 flex h-8 w-8 items-center justify-center rounded-full bg-yellow-400/10">
            <FaSun className="text-sm text-yellow-400" />
          </div>
          <p className="text-[10px] uppercase tracking-[0.16em] text-gray-400">
            {t('sun.sunrise')}
          </p>
          <p className="mt-0.5 text-sm font-semibold text-white">
            {formatTime(sunrise)}
          </p>
        </div>

        <div className="rounded-xl border border-orange-400/15 bg-orange-400/5 px-3 py-2 text-center">
          <div className="mx-auto mb-1 flex h-8 w-8 items-center justify-center rounded-full bg-orange-400/10">
            <FaSun className="text-sm text-orange-400" />
          </div>
          <p className="text-[10px] uppercase tracking-[0.16em] text-gray-400">
            {t('sun.sunset')}
          </p>
          <p className="mt-0.5 text-sm font-semibold text-white">
            {formatTime(sunset)}
          </p>
        </div>
      </div>

      <div className="mt-3 rounded-xl border border-white/10 bg-white/5 px-3 py-3">
        <div className="relative flex justify-center">
          <svg
            width="180"
            height="100"
            viewBox="0 0 180 100"
            className="mx-auto overflow-visible"
          >
            <defs>
              <filter id="sunGlow" x="-80%" y="-80%" width="260%" height="260%">
                <feGaussianBlur stdDeviation="3.5" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            <path
              d="M10,90 A80,80 0 0,1 170,90"
              stroke="rgba(255,255,255,0.16)"
              strokeWidth="7"
              fill="none"
              strokeLinecap="round"
            />

            <path
              d="M10,90 A80,80 0 0,1 170,90"
              stroke={arcColor}
              strokeWidth="7"
              fill="none"
              strokeDasharray="282.743"
              strokeDashoffset={282.743 * (1 - progress)}
              strokeLinecap="round"
            />

            <circle cx="10" cy="90" r="3.5" fill="#facc15" opacity="0.9" />
            <circle cx="170" cy="90" r="3.5" fill="#f97316" opacity="0.9" />

            <circle
              cx={10 + 160 * progress}
              cy={90 - 80 * Math.sin(progress * Math.PI)}
              r="6.5"
              fill="white"
              stroke={arcColor}
              strokeWidth="2"
              filter="url(#sunGlow)"
            />
          </svg>
        </div>

        <div className="mt-1 flex justify-between px-1 text-[10px] text-gray-400">
          <span>{formatTime(sunrise)}</span>
          <span>{formatTime(sunset)}</span>
        </div>
      </div>

      <div className="mt-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-center">
        <p className="text-[10px] uppercase tracking-[0.16em] text-gray-400">
          {t('sun.daylight')}
        </p>
        <p className="mt-0.5 text-sm font-semibold text-white">
          {daylightDuration}
        </p>
      </div>
    </div>
  );
};

export default SunriseSunsetCard;
