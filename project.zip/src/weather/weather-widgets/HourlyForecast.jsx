
import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { getWeatherIcon } from 'weather-icons/WeatherIcons';
import { WeatherDataUtils } from '@/api/WeatherDataMapper';

const HourlyForecast = ({ forecastData, formatTime, getTemp }) => {
  const { t } = useTranslation();

  const hourlyForecast = useMemo(() => {
    return WeatherDataUtils.getHourlyForecast(forecastData);
  }, [forecastData]);

  const visibleHours = useMemo(() => {
    if (!hourlyForecast || hourlyForecast.length === 0) return [];

    const nowTs = Date.now();

    let startIndex = hourlyForecast.findIndex(
      (item) => new Date(item.time).getTime() >= nowTs
    );

    if (startIndex === -1) startIndex = 0;

    const todaySlice = hourlyForecast.slice(startIndex, startIndex + 24);

    if (todaySlice.length < 24 && forecastData?.forecast?.forecastday?.[1]) {
      const remaining = 24 - todaySlice.length;

      const tomorrowHours = WeatherDataUtils.getHourlyForecast({
        forecast: {
          forecastday: [forecastData.forecast.forecastday[1]],
        },
      });

      return [...todaySlice, ...tomorrowHours.slice(0, remaining)];
    }

    return todaySlice;
  }, [hourlyForecast, forecastData]);

  if (!visibleHours || visibleHours.length === 0) {
    return (
      <>
        <h2 className="mb-3 text-xl font-semibold text-white">
          {t('hourlyForecast')}
        </h2>
        <div className="text-center text-white">{t('noForecastData')}</div>
      </>
    );
  }

  const displayedHours = visibleHours.slice(0, 12);

  return (
    <>
      <h2 className="mb-3 text-xl font-semibold text-white">
        {t('hourlyForecast')}
      </h2>

      <div className="flex gap-3 overflow-x-auto px-1 py-1">
        {displayedHours.map((hour, i) => (
          <div
            key={`${hour.time}_${i}`}
            className="flex min-w-[5rem] flex-col items-center"
          >
            <div className="text-sm text-white">
              {i === 0 ? t('now') : formatTime(hour.time)}
            </div>

            <div className="my-2 flex h-10 items-center justify-center text-white">
              {getWeatherIcon(
                hour.condition.code,
                hour.is_day === 1,
                'medium'
              )}
            </div>

            <div className="font-medium text-white">
              {getTemp(hour.temp_c, hour.temp_f)}°
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default React.memo(HourlyForecast);

