

import React from 'react';
import { getWeatherIcon } from 'weather-icons/WeatherIcons';
import TemperatureColorBar from './TemperatureColorBar';
import { WeatherDataUtils } from '@/api/WeatherDataMapper';

const DailyForecast = ({ forecastData, t, currentLocale, formatShortDate, units, language }) => {
  // Используем WeatherDataUtils для получения ежедневного прогноза
  const dailyForecast = WeatherDataUtils.getDailyForecast(forecastData);
  
  if (!dailyForecast || dailyForecast.length === 0) return null;

  // Функция с явным указанием языка через пропс
  const getShortWeekday = (dateStr) => {
    const date = new Date(dateStr);
    const dayOfWeek = date.getDay();
    
    // Явные сокращения для поддержания единого стиля
    const weekdays = {
      ru: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'],
      en: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
      default: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] // fallback
    };

    return weekdays[language]?.[dayOfWeek] || weekdays.default[dayOfWeek];
  };

  return (
    <>
      <h2 className="text-xl font-semibold mb-3 text-white">{t('dailyForecast')} тест</h2>
      <div className="space-y-3">
        {dailyForecast.map((day, i) => (
          <div key={i} className="flex items-center gap-2 p-1">
            <div className="flex items-center min-w-[80px]">
              <span className="font-medium text-white text-sm min-w-[2.5rem]">
                {getShortWeekday(day.date)}
              </span>
              <span className="mr-2 scale-90">
                {getWeatherIcon(day.day.condition.code, true, 'medium')}
              </span>
            </div>

            <div className="flex-1 min-w-0">
              <TemperatureColorBar 
                minTemp={units === 'metric' ? day.day.mintemp_c : day.day.mintemp_f} 
                maxTemp={units === 'metric' ? day.day.maxtemp_c : day.day.maxtemp_f} 
                currentTemp={units === 'metric' ? day.day.avgtemp_c : day.day.avgtemp_f}
                units={units}
                compact
              />
            </div>


          </div>
        ))}
      </div>
    </>
  );
};

export default DailyForecast;


