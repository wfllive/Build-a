



import React from 'react';
import { useTranslation } from 'react-i18next';
import {
  Shirt,
  Snowflake,
  Wind,
  Umbrella,
  Droplets,
  BookOpen,
  Zap,
  Eye,
  PersonStanding,
  House,
  Trees,
  Sun,
  HeartPulse,
  Waves,
} from 'lucide-react';

const pushUnique = (list, item) => {
  if (!list.some((entry) => entry.id === item.id)) {
    list.push(item);
  }
};

const Section = ({ title, items }) => {
  if (!items.length) return null;

  return (
    <section className="space-y-3">
      {/* Стилизовано под ваш пример: чистый белый цвет и полужирный шрифт для аккуратности */}
      <h3 className="text-sm font-semibold text-white">
        {title}
      </h3>

      <ul className="space-y-2.5">
        {items.map(({ id, text, Icon, color }) => (
          <li key={id} className="flex items-start gap-3 text-white">
            <Icon
              className={`mt-[2px] h-5 w-5 shrink-0 ${color}`}
              strokeWidth={1.9}
            />
            <span className="min-w-0 break-words text-sm font-medium leading-5">
              {text}
            </span>
          </li>
        ))}
      </ul>
    </section>
  );
};

const ClothingRecommendation = ({
  weatherConditionCode = 0,
  temperature = 20,
  windSpeed = 0,
}) => {
  const { t } = useTranslation();

  const clothingItems = [];
  const activityItems = [];
  const healthItems = [];

  const thunderCodes = [1087, 1273, 1276, 1279, 1282];
  const fogCodes = [1030, 1135, 1147];
  const snowCodes = [
    1066, 1069, 1114, 1117,
    1204, 1207,
    1210, 1213, 1216, 1219, 1222, 1225,
    1249, 1252, 1255, 1258,
  ];
  const rainCodes = [
    1063, 1072,
    1150, 1153, 1168, 1171,
    1180, 1183, 1186, 1189, 1192, 1195, 1198, 1201,
    1240, 1243, 1246,
  ];

  // Температура
  if (temperature <= -10) {
    pushUnique(clothingItems, {
      id: 'veryCold',
      text: t('clothing.veryCold'),
      Icon: Snowflake,
      color: 'text-cyan-300',
    });
    pushUnique(activityItems, {
      id: 'skiing',
      text: t('activities.skiing'),
      Icon: Snowflake,
      color: 'text-cyan-300',
    });
    pushUnique(healthItems, {
      id: 'frostbiteWarning',
      text: t('health.frostbiteWarning'),
      Icon: HeartPulse,
      color: 'text-cyan-300',
    });
  } else if (temperature <= 0) {
    pushUnique(clothingItems, {
      id: 'cold',
      text: t('clothing.cold'),
      Icon: Snowflake,
      color: 'text-sky-300',
    });
    pushUnique(activityItems, {
      id: 'snowman',
      text: t('activities.snowman'),
      Icon: Snowflake,
      color: 'text-sky-300',
    });
    pushUnique(healthItems, {
      id: 'coldWarning',
      text: t('health.coldWarning'),
      Icon: Wind,
      color: 'text-sky-300',
    });
  } else if (temperature <= 10) {
    pushUnique(clothingItems, {
      id: 'cool',
      text: t('clothing.cool'),
      Icon: Shirt,
      color: 'text-emerald-300',
    });
    pushUnique(activityItems, {
      id: 'parkWalk',
      text: t('activities.parkWalk'),
      Icon: PersonStanding,
      color: 'text-emerald-300',
    });
    pushUnique(healthItems, {
      id: 'scarfWarning',
      text: t('health.scarfWarning'),
      Icon: Wind,
      color: 'text-emerald-300',
    });
  } else if (temperature <= 20) {
    pushUnique(clothingItems, {
      id: 'comfortable',
      text: t('clothing.comfortable'),
      Icon: Shirt,
      color: 'text-lime-300',
    });
    pushUnique(activityItems, {
      id: 'picnic',
      text: t('activities.picnic'),
      Icon: Trees,
      color: 'text-lime-300',
    });
    pushUnique(healthItems, {
      id: 'sweatWarning',
      text: t('health.sweatWarning'),
      Icon: Droplets,
      color: 'text-lime-300',
    });
  } else if (temperature <= 30) {
    pushUnique(clothingItems, {
      id: 'hot',
      text: t('clothing.hot'),
      Icon: Shirt,
      color: 'text-amber-300',
    });
    pushUnique(activityItems, {
      id: 'beach',
      text: t('activities.beach'),
      Icon: Sun,
      color: 'text-amber-300',
    });
    pushUnique(healthItems, {
      id: 'hydrationWarning',
      text: t('health.hydrationWarning'),
      Icon: Droplets,
      color: 'text-amber-300',
    });
  } else {
    pushUnique(clothingItems, {
      id: 'veryHot',
      text: t('clothing.veryHot'),
      Icon: Sun,
      color: 'text-orange-300',
    });
    pushUnique(activityItems, {
      id: 'pool',
      text: t('activities.pool'),
      Icon: Waves,
      color: 'text-orange-300',
    });
    pushUnique(healthItems, {
      id: 'sunburnWarning',
      text: t('health.sunburnWarning'),
      Icon: Sun,
      color: 'text-orange-300',
    });
  }

  // Погодные условия
  if (thunderCodes.includes(weatherConditionCode)) {
    pushUnique(clothingItems, {
      id: 'thunderstorm',
      text: t('clothing.thunderstorm'),
      Icon: Zap,
      color: 'text-yellow-300',
    });
    pushUnique(activityItems, {
      id: 'stayHome',
      text: t('activities.stayHome'),
      Icon: House,
      color: 'text-yellow-300',
    });
    pushUnique(healthItems, {
      id: 'lightningWarning',
      text: t('health.lightningWarning'),
      Icon: Zap,
      color: 'text-yellow-300',
    });
  } else if (fogCodes.includes(weatherConditionCode)) {
    pushUnique(clothingItems, {
      id: 'fog',
      text: t('clothing.fog'),
      Icon: Eye,
      color: 'text-zinc-300',
    });
    pushUnique(activityItems, {
      id: 'fogWalk',
      text: t('activities.fogWalk'),
      Icon: PersonStanding,
      color: 'text-zinc-300',
    });
    pushUnique(healthItems, {
      id: 'visibilityWarning',
      text: t('health.visibilityWarning'),
      Icon: Eye,
      color: 'text-zinc-300',
    });
  } else if (snowCodes.includes(weatherConditionCode)) {
    pushUnique(clothingItems, {
      id: 'snowfall',
      text: t('clothing.snowfall'),
      Icon: Snowflake,
      color: 'text-blue-300',
    });
    pushUnique(activityItems, {
      id: 'snowFort',
      text: t('activities.snowFort'),
      Icon: Snowflake,
      color: 'text-blue-300',
    });
    pushUnique(healthItems, {
      id: 'slipWarning',
      text: t('health.slipWarning'),
      Icon: Snowflake,
      color: 'text-blue-300',
    });
  } else if (rainCodes.includes(weatherConditionCode)) {
    pushUnique(clothingItems, {
      id: 'rain',
      text: t('clothing.rain'),
      Icon: Umbrella,
      color: 'text-cyan-300',
    });
    pushUnique(activityItems, {
      id: 'readBook',
      text: t('activities.readBook'),
      Icon: BookOpen,
      color: 'text-cyan-300',
    });
    pushUnique(healthItems, {
      id: 'slipperyWarning',
      text: t('health.slipperyWarning'),
      Icon: Umbrella,
      color: 'text-cyan-300',
    });
  }

  // Ветер
  if (windSpeed > 20) {
    pushUnique(clothingItems, {
      id: 'strongWind',
      text: t('clothing.strongWind'),
      Icon: Wind,
      color: 'text-violet-300',
    });
    pushUnique(activityItems, {
      id: 'avoidWalks',
      text: t('activities.avoidWalks'),
      Icon: Wind,
      color: 'text-violet-300',
    });
    pushUnique(healthItems, {
      id: 'dustWarning',
      text: t('health.dustWarning'),
      Icon: Wind,
      color: 'text-violet-300',
    });
  } else if (windSpeed < 5) {
    pushUnique(clothingItems, {
      id: 'calmWeather',
      text: t('clothing.calmWeather'),
      Icon: Wind,
      color: 'text-teal-300',
    });
    pushUnique(activityItems, {
      id: 'picnic-calm',
      text: t('activities.picnic'),
      Icon: Trees,
      color: 'text-teal-300',
    });
  }

  return (
    <div className="w-full min-w-0 space-y-4 sm:space-y-5">
      <Section title={t('clothing.title')} items={clothingItems} />
      <Section title={t('activities.title')} items={activityItems} />
      <Section title={t('health.title')} items={healthItems} />
    </div>
  );
};

export default React.memo(ClothingRecommendation);