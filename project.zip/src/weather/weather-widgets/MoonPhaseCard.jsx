import React from 'react';
import { WeatherDataUtils } from '@/api';

/* ─── constants ─────────────────────────────────────────── */

const PHASE_ALIASES = { lastquarter: 'thirdquarter' };

const PHASE_ACCENTS = {
  newmoon: '#8b5cf6',
  waxingcrescent: '#60a5fa',
  firstquarter: '#22d3ee',
  waxinggibbous: '#a78bfa',
  fullmoon: '#f8fafc',
  waninggibbous: '#f9a8d4',
  thirdquarter: '#fb7185',
  waningcrescent: '#f59e0b',
};

const PHASE_DATA = {
  newmoon: { frac: 0.0, waning: false },
  waxingcrescent: { frac: 0.25, waning: false },
  firstquarter: { frac: 0.5, waning: false },
  waxinggibbous: { frac: 0.75, waning: false },
  fullmoon: { frac: 1.0, waning: false },
  waninggibbous: { frac: 0.75, waning: true },
  thirdquarter: { frac: 0.5, waning: true },
  waningcrescent: { frac: 0.25, waning: true },
};

const CX = 60;
const CY = 60;
const R = 28;

/* ─── helpers ───────────────────────────────────────────── */

const normalizePhase = (phase = '') =>
  phase.toLowerCase().trim().replace(/[\s_-]+/g, '');

const getPhaseKey = (phase) => {
  const n = normalizePhase(phase);
  return PHASE_ALIASES[n] || n;
};

const parseMoonTime = (timeStr) => {
  if (!timeStr || typeof timeStr !== 'string') return null;
  const m = timeStr.trim().match(/^(\d{1,2}):(\d{2})(?:\s*([APap][Mm]))?$/);
  if (!m) return null;

  let h = Number(m[1]);
  const min = Number(m[2]);
  const p = m[3]?.toUpperCase();

  if (min > 59) return null;

  if (p) {
    if (h < 1 || h > 12) return null;
    if (p === 'PM' && h < 12) h += 12;
    if (p === 'AM' && h === 12) h = 0;
  } else if (h > 23) {
    return null;
  }

  const d = new Date();
  d.setHours(h, min, 0, 0);
  return Number.isNaN(d.getTime()) ? null : d;
};

const parseIllumination = (v) => {
  if (v == null) return null;
  const n = Number(typeof v === 'string' ? v.replace('%', '').trim() : v);
  return Number.isFinite(n) ? n : null;
};

const getMoonPhaseName = (phase, t) => {
  if (!phase) return t('moon.unknown');
  const key = getPhaseKey(phase);
  const tk = `moon.${key}`;
  const tr = t(tk);
  return tr && tr !== tk ? tr : phase;
};

/* ─── SVG path builder ──────────────────────────────────── */

const buildLitPath = (frac, waning) => {
  if (frac <= 0) return null;
  if (frac >= 1)
    return `M${CX},${CY - R}a${R},${R} 0 1,1 0,${R * 2}a${R},${R} 0 1,1 0,${-R * 2}z`;

  const top = { x: CX, y: CY - R };
  const bot = { x: CX, y: CY + R };

  const innerRx = Math.abs(frac - 0.5) * 2 * R;
  const innerSweep = frac > 0.5 ? 1 : 0;
  const outerSweep = 1;

  if (!waning) {
    return [
      `M${top.x},${top.y}`,
      `A${R},${R} 0 0,${outerSweep} ${bot.x},${bot.y}`,
      `A${innerRx},${R} 0 0,${innerSweep} ${top.x},${top.y}`,
      'Z',
    ].join(' ');
  }

  return [
    `M${top.x},${top.y}`,
    `A${R},${R} 0 0,0 ${bot.x},${bot.y}`,
    `A${innerRx},${R} 0 0,${1 - innerSweep} ${top.x},${top.y}`,
    'Z',
  ].join(' ');
};

/* ─── SVG icons ─────────────────────────────────────────── */

const MoonriseIcon = () => (
  <svg viewBox="0 0 16 16" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M8 12V4" />
    <path d="M4.5 7.5L8 4l3.5 3.5" />
    <path d="M2 14h12" />
  </svg>
);

const MoonsetIcon = () => (
  <svg viewBox="0 0 16 16" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M8 4v8" />
    <path d="M4.5 8.5L8 12l3.5-3.5" />
    <path d="M2 14h12" />
  </svg>
);

/* ─── small components ──────────────────────────────────── */

const StatItem = ({ label, value, icon }) => (
  <div className="flex items-center gap-2.5 rounded-xl border border-white/10 px-3 py-2.5">
    <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white/5 text-indigo-300">
      {icon}
    </div>
    <div className="min-w-0 text-left">
      <p className="text-[10px] uppercase tracking-[0.15em] text-indigo-200/60">
        {label}
      </p>
      <p className="truncate text-sm font-medium text-white">{value}</p>
    </div>
  </div>
);

/* ─── Moon Orb ──────────────────────────────────────────── */

const Craters = () => (
  <g opacity="0.22">
    <circle cx="50" cy="50" r="3.5" fill="#94a3b8" />
    <circle cx="68" cy="54" r="2.2" fill="#94a3b8" />
    <circle cx="55" cy="70" r="2.8" fill="#94a3b8" />
    <circle cx="64" cy="42" r="1.6" fill="#94a3b8" />
    <circle cx="72" cy="66" r="1.8" fill="#94a3b8" />
    <circle cx="47" cy="62" r="1.3" fill="#94a3b8" />
  </g>
);

const Stars = ({ accent }) => (
  <g>
    <circle cx="25" cy="28" r="1.8" fill="#fff" opacity="0.9" />
    <circle cx="94" cy="24" r="1.4" fill={accent} opacity="0.85" />
    <circle cx="97" cy="91" r="1.6" fill="#fff" opacity="0.75" />
    <circle cx="20" cy="88" r="1.3" fill={accent} opacity="0.8" />
    <circle cx="14" cy="55" r="1" fill="#fff" opacity="0.55" />
    <circle cx="106" cy="60" r="1.1" fill={accent} opacity="0.5" />

    <path
      d="M22 84l1.5 3 3 1.5-3 1.5-1.5 3-1.5-3-3-1.5 3-1.5z"
      fill={accent}
      opacity="0.95"
    />
    <path
      d="M95 40l1 2 2 1-2 1-1 2-1-2-2-1 2-1z"
      fill="#fff"
      opacity="0.9"
    />
  </g>
);

const MoonPhaseOrb = ({ phaseKey = 'newmoon' }) => {
  const uid = React.useId();

  const safeKey = Object.prototype.hasOwnProperty.call(PHASE_DATA, phaseKey)
    ? phaseKey
    : 'newmoon';

  const { frac, waning } = PHASE_DATA[safeKey];
  const accent = PHASE_ACCENTS[safeKey] || PHASE_ACCENTS.newmoon;
  const litPath = buildLitPath(frac, waning);

  const auraId = `${uid}-aura`;
  const baseId = `${uid}-base`;
  const surfId = `${uid}-surf`;
  const glowId = `${uid}-glow`;
  const clipId = `${uid}-clip`;
  const termId = `${uid}-term`;

  return (
    <div className="relative flex items-center justify-center">
      <div
        className="absolute inset-0 rounded-full blur-xl opacity-50"
        style={{
          background: `radial-gradient(circle, ${accent}30 0%, transparent 70%)`,
        }}
      />

      <svg
        viewBox="0 0 120 120"
        className="relative h-24 w-24 drop-shadow-lg"
        role="img"
        aria-label={safeKey}
      >
        <defs>
          <radialGradient id={auraId} cx="50%" cy="42%" r="60%">
            <stop offset="0%" stopColor={accent} stopOpacity="0.35" />
            <stop offset="100%" stopColor={accent} stopOpacity="0" />
          </radialGradient>

          <radialGradient id={baseId} cx="40%" cy="32%" r="80%">
            <stop offset="0%" stopColor="#1e293b" />
            <stop offset="100%" stopColor="#0b1220" />
          </radialGradient>

          <radialGradient
            id={surfId}
            cx={waning ? '35%' : '65%'}
            cy="38%"
            r="72%"
          >
            <stop offset="0%" stopColor="#fffef5" />
            <stop offset="40%" stopColor="#f5f3ff" />
            <stop offset="80%" stopColor="#e2d9f3" />
            <stop offset="100%" stopColor="#c4b5fd" />
          </radialGradient>

          <linearGradient
            id={termId}
            x1={waning ? '100%' : '0%'}
            y1="0%"
            x2={waning ? '0%' : '100%'}
            y2="0%"
          >
            <stop offset="0%" stopColor="#0b1220" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#0b1220" stopOpacity="0" />
          </linearGradient>

          <filter id={glowId} x="-40%" y="-40%" width="180%" height="180%">
            <feGaussianBlur stdDeviation="2.5" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>

          <clipPath id={clipId}>
            <circle cx={CX} cy={CY} r={R} />
          </clipPath>
        </defs>

        <circle cx={CX} cy={CY} r="44" fill={`url(#${auraId})`} />
        <circle
          cx={CX}
          cy={CY}
          r="42"
          fill="none"
          stroke={accent}
          strokeOpacity="0.18"
          strokeDasharray="3 7"
        />

        <circle
          cx={CX}
          cy={CY}
          r={R}
          fill={`url(#${baseId})`}
          stroke="#e9d5ff"
          strokeOpacity="0.18"
          strokeWidth="1.2"
        />

        {litPath && (
          <g clipPath={`url(#${clipId})`} filter={`url(#${glowId})`}>
            <path d={litPath} fill={`url(#${surfId})`} />
            <path d={litPath} fill={`url(#${termId})`} opacity="0.4" />
          </g>
        )}

        {frac > 0.3 && (
          <g clipPath={`url(#${clipId})`}>
            {litPath && (
              <clipPath id={`${uid}-lit-clip`}>
                <path d={litPath} />
              </clipPath>
            )}
            <g clipPath={litPath ? `url(#${uid}-lit-clip)` : undefined}>
              <Craters />
            </g>
          </g>
        )}

        {safeKey === 'newmoon' && (
          <circle
            cx={CX}
            cy={CY}
            r={R}
            fill="none"
            stroke="#c4b5fd"
            strokeOpacity="0.2"
            strokeWidth="1.6"
          />
        )}

        {litPath && frac < 1 && (
          <g clipPath={`url(#${clipId})`}>
            <circle
              cx={CX}
              cy={CY}
              r={R - 0.6}
              fill="none"
              stroke="#fffef5"
              strokeOpacity="0.25"
              strokeWidth="0.8"
            />
          </g>
        )}

        {safeKey === 'fullmoon' && (
          <circle
            cx={CX}
            cy={CY}
            r={R + 4}
            fill="none"
            stroke="#f8fafc"
            strokeOpacity="0.12"
            strokeWidth="3"
          />
        )}

        <Stars accent={accent} />
      </svg>
    </div>
  );
};

/* ─── Main Card ─────────────────────────────────────────── */

const MoonPhaseCard = ({ forecastData, t, formatTime }) => {
  if (!forecastData) return null;

  const moonrise = WeatherDataUtils.getMoonrise(forecastData);
  const moonset = WeatherDataUtils.getMoonset(forecastData);
  const moonPhase = WeatherDataUtils.getMoonPhase(forecastData);
  const moonIllumination = WeatherDataUtils.getMoonIllumination(forecastData);

  const moonriseTime = parseMoonTime(moonrise);
  const moonsetTime = parseMoonTime(moonset);

  const phaseKey = getPhaseKey(moonPhase) || 'newmoon';
  const phaseName = getMoonPhaseName(moonPhase, t);

  const illuminationValue = parseIllumination(moonIllumination);
  const hasIllumination = illuminationValue !== null;

  return (
    <div className="flex flex-col items-center text-center">
      <h2 className="mb-2 text-lg font-semibold text-white">
        {t('moonPhase')}
      </h2>

      <MoonPhaseOrb phaseKey={phaseKey} />

      <p className="mt-2 text-base font-semibold text-white">{phaseName}</p>

      {hasIllumination && (
        <div className="mt-1.5 inline-flex items-center gap-1.5 rounded-full border border-white/10 px-2.5 py-0.5 text-xs text-gray-100">
          <span
            className="h-2 w-2 rounded-full"
            style={{ backgroundColor: PHASE_ACCENTS[phaseKey] || '#c4b5fd' }}
          />
          {illuminationValue}% {t('illuminated')}
        </div>
      )}

      <div className="mt-4 grid w-full grid-cols-2 gap-2.5">
        <StatItem
          label={t('moonrise')}
          value={moonriseTime ? formatTime(moonriseTime) : t('noMoonrise')}
          icon={<MoonriseIcon />}
        />
        <StatItem
          label={t('moonset')}
          value={moonsetTime ? formatTime(moonsetTime) : t('noMoonset')}
          icon={<MoonsetIcon />}
        />
      </div>
    </div>
  );
};

export default MoonPhaseCard;