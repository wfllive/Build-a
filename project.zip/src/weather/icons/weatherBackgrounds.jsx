
import React, { useState, useEffect, useRef, useMemo } from 'react';

// ===================================================================================
// 1. КОНСТАНТЫ
// ===================================================================================

const WEATHER_TYPES = {
  CLEAR: 'clear', 
  PARTLY_CLOUDY: 'partly-cloudy', 
  CLOUDY: 'cloudy',
  RAINY: 'rainy', 
  SNOWY: 'snowy', 
  THUNDERSTORM: 'thunderstorm',
  FOG: 'fog',
  MIST: 'mist',
};

// ===================================================================================
// 2. CSS (ИСПРАВЛЕНО: Туман больше не уезжает вбок)
// ===================================================================================

const globalCSS = `
  /* --- Базовые анимации --- */
  @keyframes float { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-10px); } }
  @keyframes rotate { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
  @keyframes pulse { 0%, 100% { transform: scale(1); opacity: 0.9; } 50% { transform: scale(1.05); opacity: 1; } }
  @keyframes cloudMove { from { transform: translateX(-200px); } to { transform: translateX(120vw); } }
  @keyframes twinkle { 0%, 100% { opacity: 0.4; } 50% { opacity: 1; } }
  
  /* Деревья - покачивание */
  @keyframes windSway { 0% { transform: rotate(0deg); } 33% { transform: rotate(2deg); } 66% { transform: rotate(-1.5deg); } 100% { transform: rotate(0deg); } }
  @keyframes heavyWindSway { 0% { transform: rotate(0deg); } 25% { transform: rotate(6deg); } 75% { transform: rotate(-4deg); } 100% { transform: rotate(0deg); } }
  
  @keyframes flash { 0% { opacity: 0; } 10% { opacity: 0.6; } 20% { opacity: 0.1; } 30% { opacity: 0.8; } 100% { opacity: 0; } }
  @keyframes strike { 0% { opacity: 0; } 10% { opacity: 1; } 100% { opacity: 0; } }

  @keyframes shoot {
    0% { transform: translateX(0) translateY(0) rotate(-45deg) scale(1); opacity: 1; }
    100% { transform: translateX(-200px) translateY(200px) rotate(-45deg) scale(0.1); opacity: 0; }
  }
  @keyframes birdFly {
    0% { transform: translateX(-10vw) translateY(10vh) scale(0.5); }
    100% { transform: translateX(110vw) translateY(0vh) scale(0.4); }
  }
  @keyframes wingFlap {
    0%, 100% { d: path("M0,10 Q5,0 10,10"); }
    50% { d: path("M0,5 Q5,15 10,5"); }
  }
  @keyframes fireflyMove {
    0%, 100% { transform: translate(0, 0); opacity: 0; }
    20% { opacity: 1; }
    50% { transform: translate(15px, -20px); opacity: 0.8; }
    80% { opacity: 1; }
    90% { transform: translate(-10px, -10px); opacity: 0; }
  }

  /* Анимация ТУМАНА */
  @keyframes fogBreathe { 
    0% { transform: scaleY(1); opacity: 0.9; } 
    50% { transform: scaleY(1.1); opacity: 1; } 
    100% { transform: scaleY(1); opacity: 0.9; } 
  }

  /* --- Контейнеры --- */
  .wb-container {
    position: relative; width: 100%; height: 100vh; overflow: hidden;
    font-family: sans-serif; transition: background 1.5s ease-in-out;
    will-change: background; 
  }
  
  .wb-vignette { position: absolute; inset: 0; background: radial-gradient(circle at center, transparent 40%, rgba(0,0,0,0.2) 100%); z-index: 10; pointer-events: none; }

  /* Небесные тела */
  .wb-celestial { 
    position: absolute; top: 5%; left: 8%; z-index: 2; 
    width: 140px; height: 140px; 
    display: flex; align-items: center; justify-content: center; 
    animation: float 7s ease-in-out infinite; 
  }

  @media (max-width: 768px) {
    .wb-celestial { width: 100px; height: 100px; top: 3%; left: 5%; }
  }

  .wb-sun-glow { position: absolute; width: 100%; height: 100%; border-radius: 50%; background: radial-gradient(circle, rgba(255,215,0,0.3) 0%, transparent 70%); animation: pulse 5s infinite; }
  .wb-sun-rays { animation: rotate 25s linear infinite; transform-origin: center; will-change: transform; }
  .wb-star { position: absolute; background: white; border-radius: 50%; }
  
  .wb-cloud-wrapper { position: absolute; will-change: transform; z-index: 4; }
  
  /* ЛАНДШАФТ */
  .wb-landscape-container { 
    position: absolute; bottom: 0; left: 0; width: 100%; 
    height: 75vh; 
    z-index: 6; pointer-events: none; 
  }
  
  .wb-landscape-svg {
    width: 100%; height: 100%; display: block;
    transform-origin: bottom center;
    transition: fill 1s ease;
  }

  @media (max-width: 768px) {
    .wb-landscape-container { height: 60vh; }
  }
  
  /* --- ИСПРАВЛЕННЫЙ ТУМАН --- */
  .wb-fog-overlay { 
    position: absolute; 
    bottom: 0; 
    left: 0; /* Прижато к левому краю */
    width: 100%; /* Ровно по ширине экрана, без сдвигов */
    height: 80%; 
    z-index: 20; 
    pointer-events: none; 
    transform-origin: bottom; /* Растет снизу вверх */
    animation: fogBreathe 10s ease-in-out infinite; /* Анимация пульсации */
  }
  
  .wb-tree-foliage { transform-box: fill-box; transform-origin: 50% 90%; will-change: transform; }
  
  .wb-lightning-flash { position: absolute; inset: 0; background: rgba(255,255,255,0.3); z-index: 40; pointer-events: none; animation: flash 0.4s ease-out forwards; }
  .wb-bolt-container { position: absolute; top: 0; left: 0; width: 100%; height: 60%; z-index: 3; pointer-events: none; }
  
  .wb-shooting-star {
    position: absolute; width: 80px; height: 2px;
    background: linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,1) 50%, rgba(255,255,255,0) 100%);
    animation: shoot 2s ease-out forwards;
    opacity: 0; z-index: 1;
  }

  .wb-firefly {
    position: absolute; width: 4px; height: 4px;
    background: #FFD700; border-radius: 50%;
    box-shadow: 0 0 6px #FFD700;
    z-index: 7;
  }

  .wb-bird-container {
    position: absolute; top: 15%; left: -10%; width: 25px; height: 25px; z-index: 5;
    animation: birdFly 25s linear infinite; opacity: 0.9;
  }
  .wb-bird-wing { fill: none; stroke: #333; stroke-width: 2; animation: wingFlap 0.4s ease-in-out infinite; }

  .wb-content { position: relative; z-index: 30; height: 100%; }
`;

const GlobalStylesComponent = React.memo(() => {
  useEffect(() => {
    if (document.getElementById('wb-styles')) return;
    const style = document.createElement('style');
    style.id = 'wb-styles';
    style.innerHTML = globalCSS;
    document.head.appendChild(style);
    return () => {
        const styleEl = document.getElementById('wb-styles');
        if (styleEl) styleEl.remove();
    };
  }, []);
  return null;
});

// ===================================================================================
// 3. SVG КОМПОНЕНТЫ
// ===================================================================================

const Sun = React.memo(() => (
    <div style={{ width: '100%', height: '100%', position: 'relative' }}>
        <div className="wb-sun-glow" />
        <svg viewBox="0 0 100 100" style={{ overflow: 'visible', width: '100%', height: '100%' }}>
            <g className="wb-sun-rays" style={{ transformOrigin: '50px 50px' }}>
                {Array.from({ length: 12 }).map((_, i) => (
                    <line key={i} x1="50" y1="50" x2="50" y2="10" transform={`rotate(${i * 30} 50 50)`} stroke="#FFD700" strokeWidth="3" strokeLinecap="round" opacity="0.5" strokeDasharray="4 15" strokeDashoffset="5" />
                ))}
            </g>
            <defs><radialGradient id="sunGrad"><stop offset="0%" stopColor="#FFF9D9" /><stop offset="60%" stopColor="#FFD700" /><stop offset="100%" stopColor="#FF8C00" /></radialGradient></defs>
            <circle cx="50" cy="50" r="26" fill="url(#sunGrad)" />
        </svg>
    </div>
));

const Moon = React.memo(() => (
    <div style={{ width: '100%', height: '100%', position: 'relative' }}>
         <div className="wb-sun-glow" style={{ background: 'radial-gradient(circle, rgba(255,255,255,0.15) 0%, transparent 70%)' }}/>
         <svg viewBox="0 0 100 100" style={{ width: '100%', height: '100%' }}>
            <defs>
                <filter id="moonGlow" x="-50%" y="-50%" width="200%" height="200%">
                    <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
                    <feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge>
                </filter>
                <linearGradient id="moonSurf" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#ffffff" /><stop offset="100%" stopColor="#cbd5e0" /></linearGradient>
            </defs>
            <circle cx="50" cy="50" r="35" fill="url(#moonSurf)" filter="url(#moonGlow)" />
            <circle cx="38" cy="45" r="5" fill="rgba(0,0,0,0.07)" /><circle cx="62" cy="65" r="8" fill="rgba(0,0,0,0.07)" />
        </svg>
    </div>
));

const CloudSVG = React.memo(({ width, color, opacity }) => (
    <svg width={width} viewBox="0 0 120 60" preserveAspectRatio="none" style={{ opacity: Math.min((opacity || 0.8) + 0.1, 1), filter: 'drop-shadow(0 2px 3px rgba(0,0,0,0.1))' }}>
        <path d="M10,45 Q20,25 40,30 Q50,10 70,25 Q85,15 95,30 Q115,35 105,50 Q110,60 90,60 L30,60 Q10,60 10,45 Z" fill={color} />
    </svg>
));

const LightningBolt = React.memo(({ xPos }) => (
    <div className="wb-bolt-container" style={{ left: `${xPos}%` }}>
         <svg width="150" height="400" viewBox="0 0 100 200" style={{ animation: 'strike 0.3s ease-out' }}>
            <path d="M50,0 L30,50 L60,50 L35,120 L70,120 L40,200" stroke="white" strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round" />
         </svg>
    </div>
));

// ===================================================================================
// 4. ДОП ЭЛЕМЕНТЫ
// ===================================================================================

const Bird = React.memo(() => (
    <div className="wb-bird-container">
        <svg viewBox="0 0 10 10" width="100%" height="100%" style={{ overflow: 'visible' }}>
            <path className="wb-bird-wing" d="M0,5 Q5,15 10,5" />
        </svg>
    </div>
));

const Fireflies = React.memo(() => {
    const flies = useMemo(() => Array.from({ length: 8 }).map((_, i) => ({
        left: Math.random() * 100 + '%',
        top: Math.random() * 30 + 60 + '%',
        delay: Math.random() * 5 + 's',
        duration: Math.random() * 5 + 5 + 's'
    })), []);

    return <>{flies.map((f, i) => <div key={i} className="wb-firefly" style={{ left: f.left, top: f.top, animation: `fireflyMove ${f.duration} ease-in-out infinite ${f.delay}` }} />)}</>;
});

const ShootingStarManager = React.memo(() => {
    const [star, setStar] = useState(null);
    useEffect(() => {
        let appearTimeout;
        let removeTimeout;
        const scheduleStar = () => {
            appearTimeout = setTimeout(() => {
                setStar({ id: Date.now(), top: Math.random() * 30 + '%', left: Math.random() * 50 + 40 + '%' });
                removeTimeout = setTimeout(() => setStar(null), 2000);
                scheduleStar();
            }, Math.random() * 15000 + 10000);
        };
        scheduleStar();
        return () => { clearTimeout(appearTimeout); clearTimeout(removeTimeout); };
    }, []);
    if (!star) return null;
    return <div className="wb-shooting-star" style={{ top: star.top, left: star.left }} />;
});

// ===================================================================================
// 5. ЛАНДШАФТ
// ===================================================================================

const Landscape = React.memo(({ timeOfDay, weatherType }) => {
    const isNight = timeOfDay === 'night';
    const isStorm = [WEATHER_TYPES.RAINY, WEATHER_TYPES.THUNDERSTORM].includes(weatherType);
    const isSnow = weatherType === WEATHER_TYPES.SNOWY;
    const isFoggy = [WEATHER_TYPES.FOG, WEATHER_TYPES.MIST].includes(weatherType);

    const palette = useMemo(() => {
        if (isSnow) return isNight ? { bg: '#212F3C', mid: '#283747', fg: '#34495E' } : { bg: '#95A5A6', mid: '#BDC3C7', fg: '#ECF0F1' };
        
        if (isFoggy) {
            return isNight 
                ? { bg: '#1B2631', mid: '#212F3C', fg: '#283747' }
                : { bg: '#AAB7B8', mid: '#B3B6B7', fg: '#BDC3C7' };
        }

        if (isStorm) return { bg: '#17202A', mid: '#1C2833', fg: '#212F3D' };
        if (isNight) return { bg: '#0A1823', mid: '#0E2233', fg: '#132E42' }; 
        return { bg: '#2E865F', mid: '#27AE60', fg: '#2ECC71' };
    }, [isSnow, isStorm, isNight, isFoggy]);

    const treeColors = useMemo(() => {
        if (isSnow) return { foliage: '#F4F6F7', trunk: '#3E2723' };
        if (isFoggy) return { foliage: isNight ? '#17202A' : '#5F6A6A', trunk: '#424949' };
        if (isNight) return { foliage: '#0B3B2E', trunk: '#3E2723' };
        return { foliage: '#0E6251', trunk: '#3E2723' };
    }, [isSnow, isFoggy, isNight]);

    const windClass = isStorm ? 'heavyWindSway' : 'windSway';
    const animDuration = isStorm ? '2s' : '5s';

    const renderTree = (x, y, scale, i) => {
        const finalScale = scale * 1.2; 
        return (
            <g key={i} transform={`translate(${x}, ${y}) scale(${finalScale})`}>
                <rect x="-6" y="-5" width="12" height="35" fill={treeColors.trunk} />
               <g className="wb-tree-foliage" style={{ 
    animationName: windClass,
    animationDuration: animDuration,
    animationTimingFunction: 'ease-in-out',
    animationIterationCount: 'infinite',
    animationDirection: 'alternate',
    animationDelay: `${i * 0.4}s`
}}>
                    <path d="M-35,0 L0,-50 L35,0 Z" fill={treeColors.foliage} />
                    <path d="M-28,-25 L0,-70 L28,-25 Z" fill={treeColors.foliage} />
                    <path d="M-20,-50 L0,-85 L20,-50 Z" fill={treeColors.foliage} />
                </g>
            </g>
        );
    };

    return (
        <div className="wb-landscape-container">
            <svg className="wb-landscape-svg" viewBox="0 0 1440 600" preserveAspectRatio="xMidYMax slice">
                <path fill={palette.bg} d="M-100,600 L-100,250 Q300,50 750,250 T1540,200 L1540,600 Z" />
                <path fill={palette.mid} d="M-100,600 L-100,450 Q200,280 700,380 T1540,350 L1540,600 Z" />
                
                {renderTree(100, 480, 1.4, 1)} 
                {renderTree(300, 420, 1.0, 2)} 
                {renderTree(580, 390, 1.8, 3)} 
                {renderTree(750, 410, 1.3, 6)} 
                {renderTree(920, 440, 1.1, 4)}
                {renderTree(1150, 400, 1.5, 7)}
                {renderTree(1350, 460, 1.3, 5)}
                
                <path fill={palette.fg} d="M-100,600 L-100,500 Q400,350 900,450 T1540,420 L1540,600 Z" />
            </svg>
        </div>
    );
});

// ===================================================================================
// 6. ОСАДКИ
// ===================================================================================

const CanvasPrecipitation = React.memo(({ type, count, wind = 0, speed = 1 }) => {
    const canvasRef = useRef(null);
    const animationFrameId = useRef(null);
    
    useEffect(() => {
        const canvas = canvasRef.current;
        if(!canvas) return;
        const ctx = canvas.getContext('2d');
        const isMobile = window.innerWidth < 768;
        const safeCount = isMobile ? Math.floor(count / 3) : count;

        const resizeCanvas = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        };
        window.addEventListener('resize', resizeCanvas);
        resizeCanvas();

        let w = canvas.width;
        let h = canvas.height;
        const particles = Array.from({ length: safeCount }, () => ({
            x: Math.random() * w,
            y: Math.random() * h,
            z: Math.random() * 0.5 + 0.5,
            speed: (Math.random() * 1 + 0.5) * speed,
            length: Math.random() * 15 + 5 
        }));

        const draw = () => {
            w = canvas.width;
            h = canvas.height;
            ctx.clearRect(0, 0, w, h);
            const alpha = type === 'snow' ? 0.8 : 0.5; 
            ctx.fillStyle = type === 'snow' ? `rgba(255,255,255,${alpha})` : `rgba(174,194,224,${alpha})`;
            ctx.strokeStyle = `rgba(174,194,224,${alpha})`;
            
            for (let i = 0; i < particles.length; i++) {
                const p = particles[i];
                p.y += p.speed * 4; 
                p.x += wind * 2 * p.z;
                if (p.y > h) { p.y = -20; p.x = Math.random() * w; }
                if (p.x > w) p.x = -10;
                if (p.x < -10) p.x = w + 10;
                if (type === 'rain') {
                    ctx.beginPath();
                    ctx.lineWidth = 1.5 * p.z;
                    ctx.moveTo(p.x, p.y);
                    ctx.lineTo(p.x + wind * 4, p.y + p.length * p.z);
                    ctx.stroke();
                } else {
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, (2.5 * p.z), 0, Math.PI * 2);
                    ctx.fill();
                }
            }
            animationFrameId.current = requestAnimationFrame(draw);
        };
        draw();
        return () => { cancelAnimationFrame(animationFrameId.current); window.removeEventListener('resize', resizeCanvas); };
    }, [type, count, wind, speed]);

    return <canvas ref={canvasRef} style={{ position: 'absolute', top: 0, left: 0, width: '100vw', height: '100vh', zIndex: 3, pointerEvents: 'none' }} />;
});

// ===================================================================================
// 7. ОБЛАКА
// ===================================================================================


const CloudManager = React.memo(({ weatherType }) => {
    const cloudData = useMemo(() => {
        const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
        const scaleMod = isMobile ? 0.6 : 1; 

        let config = [];
        switch(weatherType) {
            case WEATHER_TYPES.CLEAR: config = []; break;
            case WEATHER_TYPES.PARTLY_CLOUDY: config = [{ count: 3, opacity: 0.95, color: '#fff', speed: 40 }]; break;
            case WEATHER_TYPES.CLOUDY: 
            case WEATHER_TYPES.FOG: 
            case WEATHER_TYPES.MIST:
                config = [{ count: 4, opacity: 0.95, color: '#E2E8F0', speed: 50 }, { count: 3, opacity: 0.85, color: '#CBD5E0', speed: 30 }]; break;
            case WEATHER_TYPES.RAINY: 
            case WEATHER_TYPES.THUNDERSTORM: config = [{ count: 6, opacity: 1, color: '#566573', speed: 25 }, { count: 4, opacity: 0.9, color: '#2C3E50', speed: 15 }]; break;
            case WEATHER_TYPES.SNOWY: config = [{ count: 6, opacity: 0.95, color: '#ECF0F1', speed: 45 }]; break;
            default: config = [];
        }

        const generatedClouds = [];
        config.forEach((layer, layerIdx) => {
            for(let i = 0; i < layer.count; i++) {
                generatedClouds.push({
                    key: `${layerIdx}-${i}`,
                    top: Math.random() * 30 - 5,
                    scale: (0.6 + Math.random() * 0.8) * scaleMod,
                    speed: layer.speed + Math.random() * 20,
                    delay: -Math.random() * 60,
                    opacity: layer.opacity,
                    color: layer.color
                });
            }
        });
        return generatedClouds;
    }, [weatherType]);

    return (
        <>
            {cloudData.map((cloud) => (

                <div key={cloud.key} className="wb-cloud-wrapper" style={{
    top: `${cloud.top}%`,
    width: `${200 * cloud.scale}px`,
    opacity: cloud.opacity,
    // Разбиваем на отдельные свойства:
    animationName: 'cloudMove',
    animationDuration: `${cloud.speed}s`,
    animationTimingFunction: 'linear',
    animationIterationCount: 'infinite',
    animationDelay: `${cloud.delay}s`
}}>
                    <CloudSVG width="100%" color={cloud.color} />
                </div>
                

            ))}
        </>
    );
});

const Stars = React.memo(({ count = 60 }) => {
    const stars = useMemo(() => Array.from({ length: count }).map((_, i) => ({
        top: Math.random() * 65 + '%',
        left: Math.random() * 100 + '%',
        size: Math.random() * 2.5 + 1 + 'px',
        delay: Math.random() * 4 + 's'
    })), [count]);
    return <div style={{ position: 'absolute', inset: 0, zIndex: 1 }}>{stars.map((s, i) => <div key={i} className="wb-star" style={{ top: s.top, left: s.left, width: s.size, height: s.size, animation: `twinkle ${3 + Math.random()*2}s infinite ${s.delay}` }}/>)}</div>;
});

// ===================================================================================
// 8. ГЛАВНЫЙ КОМПОНЕНТ
// ===================================================================================

const WeatherBackground = ({ weatherType = WEATHER_TYPES.CLEAR, timeOfDay = 'day', children }) => {
    const [flash, setFlash] = useState(false);
    const [boltPos, setBoltPos] = useState(50);

    const backgroundGradient = useMemo(() => {
        const isNight = timeOfDay === 'night';
        switch (weatherType) {
            case WEATHER_TYPES.CLEAR: return isNight ? 'linear-gradient(180deg, #021B35 0%, #18446D 100%)' : 'linear-gradient(180deg, #2980B9 0%, #6DD5FA 100%)';
            case WEATHER_TYPES.PARTLY_CLOUDY: return isNight ? 'linear-gradient(180deg, #1C2833 0%, #424949 100%)' : 'linear-gradient(180deg, #56CCF2 0%, #2F80ED 100%)';
            case WEATHER_TYPES.CLOUDY: return isNight ? 'linear-gradient(180deg, #17202A 0%, #34495E 100%)' : 'linear-gradient(180deg, #606c88 0%, #3f4c6b 100%)';
            case WEATHER_TYPES.RAINY: return isNight ? 'linear-gradient(180deg, #000000 0%, #2C3E50 100%)' : 'linear-gradient(180deg, #283048 0%, #859398 100%)';
            case WEATHER_TYPES.SNOWY: return isNight ? 'linear-gradient(180deg, #0B151D 0%, #203A43 100%)' : 'linear-gradient(180deg, #83a4d4 0%, #b6fbff 100%)';
            case WEATHER_TYPES.THUNDERSTORM: return 'linear-gradient(180deg, #0F151E 0%, #283747 100%)';
            case WEATHER_TYPES.FOG: 
            case WEATHER_TYPES.MIST:
                return isNight ? 'linear-gradient(180deg, #2C3E50 0%, #4D5656 100%)' : 'linear-gradient(180deg, #BDC3C7 0%, #ECF0F1 100%)';
            default: return '#fff';
        }
    }, [weatherType, timeOfDay]);

    useEffect(() => {
        let loopTimeout;
        let flashOffTimeout;
        if (weatherType === WEATHER_TYPES.THUNDERSTORM) {
            const loop = () => { 
                const delay = Math.random() * 5000 + 3000; 
                loopTimeout = setTimeout(() => { 
                    setBoltPos(Math.random() * 80 + 10);
                    setFlash(true); 
                    flashOffTimeout = setTimeout(() => setFlash(false), 500);
                    loop(); 
                }, delay); 
            };
            loop();
        } else {
            setFlash(false);
        }
        return () => { clearTimeout(loopTimeout); clearTimeout(flashOffTimeout); setFlash(false); };
    }, [weatherType]);

    const precipitation = useMemo(() => {
        if (weatherType === WEATHER_TYPES.RAINY) return { type: 'rain', count: 180, speed: 1.6 };
        if (weatherType === WEATHER_TYPES.THUNDERSTORM) return { type: 'rain', count: 250, speed: 2.3 };
        if (weatherType === WEATHER_TYPES.SNOWY) return { type: 'snow', count: 120, speed: 0.9 };
        return null;
    }, [weatherType]);

    const wind = ([WEATHER_TYPES.RAINY, WEATHER_TYPES.THUNDERSTORM].includes(weatherType)) ? 1.2 : (weatherType === WEATHER_TYPES.SNOWY ? 0.4 : 0.1);
    
    const showBird = timeOfDay === 'day' && (weatherType === WEATHER_TYPES.CLEAR || weatherType === WEATHER_TYPES.PARTLY_CLOUDY);
    const showFireflies = timeOfDay === 'night' && (weatherType === WEATHER_TYPES.CLEAR || weatherType === WEATHER_TYPES.PARTLY_CLOUDY);
    const showShootingStar = timeOfDay === 'night' && weatherType === WEATHER_TYPES.CLEAR;

    const isFoggy = [WEATHER_TYPES.FOG, WEATHER_TYPES.MIST].includes(weatherType);
    
    const fogStyle = useMemo(() => {
        if (!isFoggy) return { display: 'none' };
        const color = timeOfDay === 'night' ? '40, 50, 60' : '255, 255, 255';
        return {
            background: `linear-gradient(to top, rgba(${color}, 1) 0%, rgba(${color}, 0.8) 40%, rgba(${color}, 0) 100%)`
        };
    }, [isFoggy, timeOfDay]);

    return (
        <div className="wb-container" style={{ background: backgroundGradient }}>
            <GlobalStylesComponent />
            <div className="wb-vignette" />
            {flash && <div className="wb-lightning-flash" />}
            {flash && weatherType === WEATHER_TYPES.THUNDERSTORM && <LightningBolt xPos={boltPos} />}
            {timeOfDay === 'night' && ![WEATHER_TYPES.THUNDERSTORM, WEATHER_TYPES.CLOUDY, WEATHER_TYPES.RAINY, WEATHER_TYPES.FOG, WEATHER_TYPES.MIST].includes(weatherType) && <Stars count={weatherType === WEATHER_TYPES.CLEAR ? 80 : 40} />}
            {showShootingStar && <ShootingStarManager />}
            {![WEATHER_TYPES.THUNDERSTORM, WEATHER_TYPES.RAINY, WEATHER_TYPES.CLOUDY, WEATHER_TYPES.FOG, WEATHER_TYPES.MIST].includes(weatherType) && (
                <div className="wb-celestial">{timeOfDay === 'day' ? <Sun /> : <Moon />}</div>
            )}
            {showBird && <Bird />}
            {precipitation && <CanvasPrecipitation type={precipitation.type} count={precipitation.count} speed={precipitation.speed} wind={wind} />}
            <CloudManager weatherType={weatherType} />
            <Landscape timeOfDay={timeOfDay} weatherType={weatherType} />
            
            <div className="wb-fog-overlay" style={fogStyle} />
            
            {showFireflies && <Fireflies />}
            <div className="wb-content">{children}</div>
        </div>
    );
};

export default WeatherBackground;