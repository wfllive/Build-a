

import React from 'react';
import Lottie from 'lottie-react';

// Импортируем все анимации напрямую
import sunnyDay from '@/assets/weather-icon/01d.json';
import sunnyNight from '@/assets/weather-icon/01n.json';
import partlyCloudyDay from '@/assets/weather-icon/02d.json';
import partlyCloudyNight from '@/assets/weather-icon/02n.json';
import cloudyDay from '@/assets/weather-icon/03d.json';
import cloudyNight from '@/assets/weather-icon/03n.json';
import brokenCloudsDay from '@/assets/weather-icon/04d.json';
import brokenCloudsNight from '@/assets/weather-icon/04n.json';
import mistDay from '@/assets/weather-icon/50d.json';
import mistNight from '@/assets/weather-icon/50n.json';
import rainDay from '@/assets/weather-icon/09d.json';
import rainNight from '@/assets/weather-icon/09n.json';
import heavyRainDay from '@/assets/weather-icon/10d.json';
import heavyRainNight from '@/assets/weather-icon/10n.json';
import snowDay from '@/assets/weather-icon/13d.json';
import snowNight from '@/assets/weather-icon/13n.json';
import thunderDay from '@/assets/weather-icon/11d.json';
import thunderNight from '@/assets/weather-icon/11n.json';

const WEATHER_ANIMATIONS = {
  // Ясно/Sunny
  '1000': { day: sunnyDay, night: sunnyNight },
  
  // Частичная облачность/Partly cloudy
  '1003': { day: partlyCloudyDay, night: partlyCloudyNight },
  
  // Облачно/Cloudy
  '1006': { day: cloudyDay, night: cloudyNight },
  
  // Пасмурно/Overcast
  '1009': { day: brokenCloudsDay, night: brokenCloudsNight },
  
  // Легкий туман/Mist
  '1030': { day: mistDay, night: mistNight },
  
  // Туман/Fog
  '1135': { day: mistDay, night: mistNight },
  
  // Сильный туман/Freezing fog
  '1147': { day: mistDay, night: mistNight },
  
  // Легкий дождь/Patchy rain possible
  '1063': { day: rainDay, night: rainNight },
  
  // Легкий моросящий дождь/Patchy light drizzle
  '1150': { day: rainDay, night: rainNight },
  
  // Моросящий дождь/Light drizzle
  '1153': { day: rainDay, night: rainNight },
  
  // Сильный моросящий дождь/Freezing drizzle
  '1168': { day: rainDay, night: rainNight },
  
  // Сильный моросящий дождь/Heavy freezing drizzle
  '1171': { day: heavyRainDay, night: heavyRainNight },
  
  // Легкий дождь/Patchy light rain
  '1180': { day: rainDay, night: rainNight },
  
  // Легкий дождь/Light rain
  '1183': { day: rainDay, night: rainNight },
  
  // Умеренный дождь/Moderate rain at times
  '1186': { day: heavyRainDay, night: heavyRainNight },
  
  // Умеренный дождь/Moderate rain
  '1189': { day: heavyRainDay, night: heavyRainNight },
  
  // Сильный дождь/Heavy rain at times
  '1192': { day: heavyRainDay, night: heavyRainNight },
  
  // Сильный дождь/Heavy rain
  '1195': { day: heavyRainDay, night: heavyRainNight },
  
  // Ледяной дождь/Freezing rain
  '1198': { day: rainDay, night: rainNight },
  
  // Сильный ледяной дождь/Heavy freezing rain
  '1201': { day: heavyRainDay, night: heavyRainNight },
  
  // Легкий ливневый дождь/Light sleet
  '1069': { day: heavyRainDay, night: heavyRainNight },
  
  // Умеренный ливневый дождь/Moderate or heavy sleet
  '1204': { day: heavyRainDay, night: heavyRainNight },
  
  // Легкий снег с дождем/Light sleet showers
  '1207': { day: heavyRainDay, night: heavyRainNight },
  
  // Умеренный снег с дождем/Moderate or heavy sleet showers
  '1240': { day: heavyRainDay, night: heavyRainNight },
  
  // Сильный ливневый дождь/Moderate or heavy showers of ice pellets
  '1243': { day: heavyRainDay, night: heavyRainNight },
  
  // Сильный ливневый дождь/Torrential rain shower
  '1246': { day: heavyRainDay, night: heavyRainNight },
  
  // Легкий снег/Patchy light snow
  '1066': { day: snowDay, night: snowNight },
  
  // Легкий снег/Light snow
  '1114': { day: snowDay, night: snowNight },
  
  // Сильный снег/Heavy snow
  '1117': { day: snowDay, night: snowNight },
  
  // Легкий снег/Light snow showers
  '1210': { day: snowDay, night: snowNight },
  
  // Легкий снег/Patchy moderate snow
  '1213': { day: snowDay, night: snowNight },
  
  // Умеренный снег/Moderate snow
  '1216': { day: snowDay, night: snowNight },
  
  // Сильный снег/Patchy heavy snow
  '1219': { day: snowDay, night: snowNight },
  
  // Сильный снег/Heavy snow
  '1222': { day: snowDay, night: snowNight },
  
  // Очень сильный снег/Ice pellets
  '1225': { day: snowDay, night: snowNight },
  
  // Легкий снегопад/Light snow showers
  '1237': { day: snowDay, night: snowNight },
  
  // Умеренный снегопад/Moderate or heavy snow showers
  '1249': { day: snowDay, night: snowNight },
  
  // Сильный снегопад/Moderate or heavy showers of ice pellets
  '1252': { day: snowDay, night: snowNight },
  
  // Легкий снегопад/Patchy light snow with thunder
  '1255': { day: snowDay, night: snowNight },
  
  // Умеренный снегопад/Moderate or heavy snow with thunder
  '1258': { day: snowDay, night: snowNight },
  
  // Легкий град/Light showers of ice pellets
  '1261': { day: snowDay, night: snowNight },
  
  // Умеренный град/Moderate or heavy showers of ice pellets
  '1264': { day: snowDay, night: snowNight },
  
  // Легкая гроза/Patchy light rain with thunder
  '1087': { day: thunderDay, night: thunderNight },
  
  // Умеренная гроза/Moderate or heavy rain with thunder
  '1273': { day: thunderDay, night: thunderNight },
  
  // Сильная гроза/Patchy light snow with thunder
  '1276': { day: thunderDay, night: thunderNight },
  
  // Гроза со снегом/Moderate or heavy snow with thunder
  '1279': { day: thunderDay, night: thunderNight },
  
  // Сильная гроза со снегом/Moderate or heavy snow with thunder
  '1282': { day: thunderDay, night: thunderNight }
};

const ICON_SIZES = {
  small: { width: 24, height: 24 },
  normal: { width: 40, height: 40 },
  large: { width: 80, height: 80 }
};

export const WeatherIcon = ({ conditionCode, isDay = true, size = 'normal' }) => {
  const animationData = WEATHER_ANIMATIONS[conditionCode] || WEATHER_ANIMATIONS['1000'];
  const animation = isDay ? animationData.day : animationData.night;
  const { width, height } = ICON_SIZES[size] || ICON_SIZES.normal;

  return (
    <div style={{ width, height }}>
      <Lottie
        animationData={animation}
        loop={true}
        autoplay={true}
        style={{ width, height }}
        rendererSettings={{
          preserveAspectRatio: 'xMidYMid slice'
        }}
      />
    </div>
  );
};

export const getWeatherIcon = (conditionCode, isDay = true, size = 'normal') => (
  <WeatherIcon conditionCode={conditionCode} isDay={isDay} size={size} />
);

export const getMoonPhaseIcon = (phase) => {
  const phases = {
    'New Moon': 'moon-new',
    'Waxing Crescent': 'moon-waxing-crescent',
    'First Quarter': 'moon-first-quarter',
    'Waxing Gibbous': 'moon-waxing-gibbous',
    'Full Moon': 'moon-full',
    'Waning Gibbous': 'moon-waning-gibbous',
    'Last Quarter': 'moon-last-quarter',
    'Waning Crescent': 'moon-waning-crescent'
  };
  return phases[phase] || 'moon-new';
};

export const getMoonPhaseName = (phase, t) => {
  return t(`moon.${phase.toLowerCase().replace(' ', '')}`);
};

// Экспорт по умолчанию для удобства
export default WeatherIcon;


