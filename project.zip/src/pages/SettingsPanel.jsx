


import React, {
  useState,
  useEffect,
  useCallback,
  useMemo
} from 'react';
import { createPortal } from 'react-dom';
import {
  FaSun,
  FaMoon,
  FaCircleNotch,
  FaSync,
  FaCheck,
  FaGlobe,
  FaClock,
  FaPalette,
  FaThermometerHalf,
  FaSearch,
  FaTimes,
  FaChevronRight
} from 'react-icons/fa';
import BlurCard from 'weather-ui/BlurCard';
import { useTranslation } from 'react-i18next';

const FALLBACK_LANGUAGE_META = {
  az: { nativeName: 'Azərbaycan', englishName: 'Azerbaijani' },
  be: { nativeName: 'Беларуская', englishName: 'Belarusian' },
  bg: { nativeName: 'Български', englishName: 'Bulgarian' },
  de: { nativeName: 'Deutsch', englishName: 'German' },
  en: { nativeName: 'English', englishName: 'English' },
  es: { nativeName: 'Español', englishName: 'Spanish' },
  fr: { nativeName: 'Français', englishName: 'French' },
  hy: { nativeName: 'Հայերեն', englishName: 'Armenian' },
  ja: { nativeName: '日本語', englishName: 'Japanese' },
  ka: { nativeName: 'ქართული', englishName: 'Georgian' },
  kk: { nativeName: 'Қазақша', englishName: 'Kazakh' },
  ky: { nativeName: 'Кыргызча', englishName: 'Kyrgyz' },
  pt: { nativeName: 'Português', englishName: 'Portuguese' },
  ru: { nativeName: 'Русский', englishName: 'Russian' },
  tg: { nativeName: 'Тоҷикӣ', englishName: 'Tajik' },
  uz: { nativeName: 'O‘zbek', englishName: 'Uzbek' },
  'zh-CN': { nativeName: '中文（简体）', englishName: 'Chinese (Simplified)' },
  'zh-TW': { nativeName: '中文（繁體）', englishName: 'Chinese (Traditional)' },
};

const FALLBACK_LANGUAGE_META_NORMALIZED = Object.entries(FALLBACK_LANGUAGE_META).reduce(
  (acc, [code, meta]) => {
    acc[String(code).toLowerCase()] = meta;
    return acc;
  },
  {}
);

const normalizeText = (value = '') => String(value).trim().toLowerCase();

const escapeRegExp = (value = '') =>
  String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const getBaseLanguageCode = (code = '') =>
  String(code).split('-')[0].toLowerCase();

const capitalizeFirstLetter = (value = '', locale = 'en') => {
  const text = String(value).trim();
  if (!text) return '';

  const chars = Array.from(text);
  const first = chars[0];
  const rest = chars.slice(1).join('');

  try {
    return first.toLocaleUpperCase(locale) + rest;
  } catch (error) {
    return first.toUpperCase() + rest;
  }
};

const LANGUAGE_ORDER = Object.keys(FALLBACK_LANGUAGE_META).reduce((acc, code, index) => {
  acc[String(code).toLowerCase()] = index;
  return acc;
}, {});

const getLanguageOrder = (code = '') => {
  const normalizedCode = String(code).toLowerCase();
  const baseCode = getBaseLanguageCode(normalizedCode);

  if (LANGUAGE_ORDER[normalizedCode] !== undefined) {
    return LANGUAGE_ORDER[normalizedCode];
  }

  if (LANGUAGE_ORDER[baseCode] !== undefined) {
    return LANGUAGE_ORDER[baseCode];
  }

  return Number.MAX_SAFE_INTEGER;
};

const isLanguageActive = (optionCode, currentCode) => {
  const option = normalizeText(optionCode);
  const current = normalizeText(currentCode);
  return option === current || option === getBaseLanguageCode(current);
};

const getLanguageMeta = (code) => {
  const normalizedCode = String(code).toLowerCase();
  const baseCode = getBaseLanguageCode(code);
  const region = String(code).split('-')[1];

  const exactFallback = FALLBACK_LANGUAGE_META_NORMALIZED[normalizedCode];
  const baseFallback = FALLBACK_LANGUAGE_META_NORMALIZED[baseCode];
  const fallback = exactFallback || baseFallback || {};

  let nativeName = fallback.nativeName || baseCode.toUpperCase();
  let englishName = fallback.englishName || baseCode.toUpperCase();

  try {
    if (!exactFallback && typeof Intl !== 'undefined' && Intl.DisplayNames) {
      const nativeDisplay = new Intl.DisplayNames([baseCode], { type: 'language' }).of(baseCode);
      const englishDisplay = new Intl.DisplayNames(['en'], { type: 'language' }).of(baseCode);

      if (nativeDisplay) nativeName = nativeDisplay;
      if (englishDisplay) englishName = englishDisplay;
    }
  } catch (error) {}

  nativeName = capitalizeFirstLetter(nativeName, baseCode);
  englishName = capitalizeFirstLetter(englishName, 'en');

  const codeLabel = region
    ? `${baseCode.toUpperCase()}-${region.toUpperCase()}`
    : baseCode.toUpperCase();

  return {
    code,
    baseCode,
    codeLabel,
    nativeName: region && !exactFallback ? `${nativeName} (${region.toUpperCase()})` : nativeName,
    englishName: region && !exactFallback ? `${englishName} (${region.toUpperCase()})` : englishName
  };
};

/*
const getAvailableLanguagesFromI18n = (i18n) => {
  const resources = i18n?.options?.resources || i18n?.services?.resourceStore?.data || {};
  return Object.keys(resources).filter(Boolean).filter((code) => code !== 'cimode');
};*/

const getAvailableLanguagesFromI18n = (i18n) => {
  // Берём прямо из options.resources — там всегда все языки
  const resources = i18n?.options?.resources || {};
  return Object.keys(resources)
    .filter(Boolean)
    .filter((code) => code !== 'cimode');
};

const HighlightedText = ({
  text,
  highlight,
  baseClassName = 'text-white/90',
  restClassName = 'text-white/60',
  matchClassName = 'text-white font-semibold'
}) => {
  if (!text) return null;

  const normalizedHighlight = String(highlight || '').trim();
  if (!normalizedHighlight) {
    return <span className={baseClassName}>{text}</span>;
  }

  const safeHighlight = escapeRegExp(normalizedHighlight);
  const parts = String(text).split(new RegExp(`(${safeHighlight})`, 'gi'));

  return (
    <span>
      {parts.map((part, i) =>
        part.toLowerCase() === normalizedHighlight.toLowerCase() ? (
          <span key={i} className={matchClassName}>{part}</span>
        ) : (
          <span key={i} className={restClassName}>{part}</span>
        )
      )}
    </span>
  );
};

const SectionCard = ({ icon: Icon, title, children }) => (
  <BlurCard>
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center">
          <Icon className="text-white" />
        </div>
        <h2 className="text-lg font-semibold text-white drop-shadow-md">{title}</h2>
      </div>
      {children}
    </div>
  </BlurCard>
);

const OptionButton = ({
  active,
  onClick,
  children,
  icon: Icon,
  disabled = false,
  loading = false
}) => (
  <button
    type="button"
    onClick={onClick}
    disabled={disabled}
    aria-pressed={active}
    aria-busy={loading}
    className={[
      'group relative w-full overflow-hidden rounded-2xl border px-4 py-3.5 text-left text-white transition-all duration-200',
      'focus:outline-none focus:ring-2 focus:ring-white/30',
      disabled ? 'cursor-not-allowed opacity-70' : 'hover:-translate-y-0.5 active:scale-[0.985]',
      active
        ? 'border-blue-300/40 bg-gradient-to-br from-blue-500 to-blue-600 shadow-lg shadow-blue-900/30'
        : 'border-white/10 bg-white/10 shadow-md shadow-black/10 hover:bg-white/15'
    ].join(' ')}
  >
    <span className="pointer-events-none absolute inset-0 bg-gradient-to-br from-white/10 to-transparent opacity-0 transition-opacity duration-200 group-hover:opacity-100" />
    <div className="relative flex items-center justify-between gap-3">
      <div className="flex min-w-0 items-center gap-3">
        {(Icon || loading) && (
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-black/10">
            {loading ? <FaCircleNotch className="animate-spin text-white" /> : <Icon className="text-white" />}
          </span>
        )}
        <span className="truncate font-medium text-white">{children}</span>
      </div>
      <span
        className={[
          'flex h-6 w-6 shrink-0 items-center justify-center rounded-full border transition-all duration-200',
          active ? 'border-white/20 bg-white/15 opacity-100' : 'border-white/10 bg-transparent opacity-0'
        ].join(' ')}
      >
        <FaCheck className="text-[10px] text-white" />
      </span>
    </div>
  </button>
);

const LanguageTriggerButton = ({
  onClick,
  currentLanguageLabel,
  currentLanguageCode,
  count,
  disabled = false,
  loading = false,
}) => {
  const { t } = useTranslation();
  
  return (
  <button
    type="button"
    onClick={onClick}
    disabled={disabled}
    className={[
      'group relative w-full overflow-hidden rounded-2xl border px-4 py-3.5 text-left text-white transition-all duration-200',
      'focus:outline-none focus:ring-2 focus:ring-white/30',
      disabled ? 'cursor-not-allowed opacity-70' : 'hover:-translate-y-0.5 active:scale-[0.985]',
      'border-white/10 bg-white/10 shadow-md shadow-black/10 hover:bg-white/15'
    ].join(' ')}
  >
    <span className="pointer-events-none absolute inset-0 bg-gradient-to-br from-white/10 to-transparent opacity-0 transition-opacity duration-200 group-hover:opacity-100" />
    <div className="relative flex items-center justify-between gap-3">
      <div className="flex min-w-0 items-center gap-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-black/10">
          {loading ? <FaCircleNotch className="animate-spin text-white" /> : <FaGlobe className="text-white" />}
        </span>
        <div className="min-w-0">
          <div className="truncate font-medium text-white">{currentLanguageLabel}</div>
          <div className="truncate text-sm text-white/60">
            {currentLanguageCode ? `${currentLanguageCode} • ` : ''}{count} {t('available')}
          </div>
        </div>
      </div>
      <FaChevronRight className="shrink-0 text-white/70 transition-transform duration-200 group-hover:translate-x-0.5" />
    </div>
  </button>
  )
};

const LanguagePickerModal = ({
  isOpen,
  onClose,
  languages,
  currentLanguage,
  onSelect,
  pendingLanguage,
  isChangingLanguage,
  t
}) => {
  const [query, setQuery] = useState('');
  const [render, setRender] = useState(false);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setRender(true);

      const timer = setTimeout(() => setVisible(true), 10);
      const prev = document.body.style.overflow;

      document.body.style.overflow = 'hidden';

      const onKey = (e) => {
        if (e.key === 'Escape') onClose();
      };

      document.addEventListener('keydown', onKey);

      return () => {
        clearTimeout(timer);
        document.body.style.overflow = prev;
        document.removeEventListener('keydown', onKey);
      };
    }

    setVisible(false);

    const timer = setTimeout(() => {
      setRender(false);
      setQuery('');
    }, 300);

    return () => clearTimeout(timer);
  }, [isOpen, onClose]);

  const filteredLanguages = useMemo(() => {
    const q = normalizeText(query);
    if (!q) return languages;
    return languages.filter((lang) => lang.searchValue.includes(q));
  }, [languages, query]);

  const currentLanguageItem = useMemo(
    () => languages.find((l) => isLanguageActive(l.code, currentLanguage)) || null,
    [languages, currentLanguage]
  );

  const otherLanguages = useMemo(() => {
    if (query || !currentLanguageItem) return filteredLanguages;
    return filteredLanguages.filter((l) => l.code !== currentLanguageItem.code);
  }, [filteredLanguages, currentLanguageItem, query]);

  if (!render) return null;

  const LanguageRow = ({ lang }) => {
    const active = isLanguageActive(lang.code, currentLanguage);
    const loading = pendingLanguage === lang.code;

    return (
      <div
        className={[
          'group flex items-center justify-between p-4 cursor-pointer transition-colors',
          active ? 'bg-white/[0.04]' : '',
          isChangingLanguage ? 'cursor-not-allowed opacity-70' : 'hover:bg-white/5 active:bg-white/10'
        ].join(' ')}
        onClick={() => {
          if (!isChangingLanguage) onSelect(lang.code);
        }}
      >
        <div className="flex min-w-0 items-center gap-4">
          <div
            className={[
              'flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border text-[11px] font-semibold uppercase tracking-wider',
              active
                ? 'border-blue-400/20 bg-blue-500/10 text-blue-300'
                : 'border-white/5 bg-white/[0.07] text-white/35'
            ].join(' ')}
          >
            {lang.baseCode.toUpperCase()}
          </div>

          <div className="min-w-0">
            <div className="truncate text-[17px] leading-tight">
              <HighlightedText
                text={lang.nativeName}
                highlight={query}
                baseClassName={active ? 'text-white font-medium' : 'text-white/90'}
                restClassName={active ? 'text-white/80' : 'text-white/60'}
                matchClassName="text-white font-semibold"
              />
            </div>

            <div className="mt-0.5 truncate text-sm text-white/40">
              {lang.englishName !== lang.nativeName ? (
                <>
                  <HighlightedText
                    text={lang.englishName}
                    highlight={query}
                    baseClassName="text-white/40"
                    restClassName="text-white/40"
                    matchClassName="text-white/70 font-medium"
                  />
                  <span className="text-white/25"> · {lang.codeLabel}</span>
                </>
              ) : (
                <span className="text-white/40">{lang.codeLabel}</span>
              )}
            </div>
          </div>
        </div>

        <div className="ml-3 flex h-9 w-9 shrink-0 items-center justify-center">
          {loading ? (
            <FaCircleNotch className="animate-spin text-base text-white/70" />
          ) : active ? (
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-blue-500">
              <FaCheck className="text-[10px] text-white" />
            </span>
          ) : null}
        </div>
      </div>
    );
  };

  return createPortal(
    <div
      className={`fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4 transition-all duration-300
        ${visible ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}
      `}
    >
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div
        role="dialog"
        aria-modal="true"
        aria-label={t('language')}
        onClick={(e) => e.stopPropagation()}
        className={`relative w-full max-w-lg max-h-[90vh] sm:max-h-[85vh] flex flex-col
          bg-[#1C1C1E]/80 backdrop-blur-2xl border border-white/10 shadow-2xl
          rounded-t-[2rem] sm:rounded-[2rem] overflow-hidden transition-transform duration-400 ease-out
          ${visible ? 'translate-y-0 sm:scale-100' : 'translate-y-full sm:translate-y-8 sm:scale-95'}
        `}
      >
        <div className="w-10 h-1.5 bg-white/20 rounded-full mx-auto mt-3 sm:hidden" />

        <div className="flex-shrink-0 px-5 pt-4 pb-3 sm:pt-6">
          <div className="flex justify-between items-center mb-5">
            <div>
              <h2 className="text-xl sm:text-2xl font-semibold text-white tracking-tight">
                {t('language')}
              </h2>
              <p className="mt-1 text-sm text-white/40">
                {languages.length} {t('available', { defaultValue: 'available' })}
              </p>
            </div>

            <button
              className="p-2 rounded-full bg-white/5 hover:bg-white/15 active:scale-95 transition-all"
              onClick={onClose}
            >
              <FaTimes className="text-lg text-white/70" />
            </button>
          </div>

          <div className="relative">
            <FaSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/40 text-base" />
            <input
              type="text"
              inputMode="search"
              placeholder={t('searchLanguage', { defaultValue: 'Search language or code' })}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full py-3.5 pl-11 pr-10 bg-white/10 rounded-xl text-white text-[17px] placeholder-white/40 focus:outline-none focus:bg-white/15 transition-colors"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1.5 rounded-full text-white/40 hover:text-white/80 transition-colors"
              >
                <FaTimes className="text-sm" />
              </button>
            )}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-5 pb-8 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          {query ? (
            <div>
              <h3 className="text-[13px] font-semibold uppercase tracking-wider text-white/40 mb-2 ml-1">
                {t('results', { defaultValue: 'Results' })}
              </h3>

              {filteredLanguages.length > 0 ? (
                <div className="bg-white/5 rounded-2xl overflow-hidden border border-white/5 divide-y divide-white/5">
                  {filteredLanguages.map((lang) => (
                    <LanguageRow key={lang.code} lang={lang} />
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-white/40 bg-white/5 rounded-2xl border border-white/5">
                  <span className="text-[15px]">
                    {t('noLanguagesFound', { defaultValue: 'No languages found' })}
                  </span>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-8">
              {currentLanguageItem && (
                <div>
                  <h3 className="text-[13px] font-semibold uppercase tracking-wider text-white/40 mb-2 ml-1">
                    {t('currentLanguage', { defaultValue: 'Current' })}
                  </h3>
                  <div className="bg-white/5 rounded-2xl overflow-hidden border border-white/5 divide-y divide-white/5">
                    <LanguageRow lang={currentLanguageItem} />
                  </div>
                </div>
              )}

              <div>
                <h3 className="text-[13px] font-semibold uppercase tracking-wider text-white/40 mb-2 ml-1">
                  {t('availableLanguages', { defaultValue: 'All languages' })}
                </h3>

                {otherLanguages.length > 0 ? (
                  <div className="bg-white/5 rounded-2xl overflow-hidden border border-white/5 divide-y divide-white/5">
                    {otherLanguages.map((lang) => (
                      <LanguageRow key={lang.code} lang={lang} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-white/40 bg-white/5 rounded-2xl border border-white/5">
                    <span className="text-[15px]">
                      {t('noLanguagesFound', { defaultValue: 'No languages found' })}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>,
    document.body
  );
};

const SettingsPanel = ({
  units,
  setUnits,
  theme,
  setTheme,
  timeFormat,
  setTimeFormat,
  language,
  handleLanguageChange,
  isChangingLanguage
}) => {
  const { t, i18n } = useTranslation();
  const [pendingLanguage, setPendingLanguage] = useState(null);
  const [isLanguagePickerOpen, setIsLanguagePickerOpen] = useState(false);

  const availableLanguages = useMemo(() => {
    return getAvailableLanguagesFromI18n(i18n)
      .map((code, index) => {
        const meta = getLanguageMeta(code);

        return {
          ...meta,
          originalIndex: index,
          searchValue: normalizeText(
            `${meta.code} ${meta.codeLabel} ${meta.nativeName} ${meta.englishName}`
          )
        };
      })
      .sort((a, b) => {
        const orderA = getLanguageOrder(a.code);
        const orderB = getLanguageOrder(b.code);

        if (orderA !== orderB) {
          return orderA - orderB;
        }

        return a.originalIndex - b.originalIndex;
      })
      .map(({ originalIndex, ...lang }) => lang);
  }, [i18n]);

  const currentLanguage = language || i18n.resolvedLanguage || i18n.language;

  const selectedLanguage =
    availableLanguages.find((lang) => isLanguageActive(lang.code, currentLanguage)) ||
    (currentLanguage ? getLanguageMeta(currentLanguage) : null);

  const getSystemTheme = useCallback(() => {
    if (window.AndroidTheme && window.AndroidTheme.getSystemTheme) {
      return window.AndroidTheme.getSystemTheme();
    }

    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
      ? 'dark'
      : 'light';
  }, []);

  const getActualTheme = useCallback(
    (themeValue) => (themeValue === 'auto' ? getSystemTheme() : themeValue),
    [getSystemTheme]
  );

  const applyThemeToDOM = useCallback(
    (themeValue) => {
      const actualTheme = getActualTheme(themeValue);
      const html = document.documentElement;

      html.classList.remove('light', 'dark');
      html.classList.add(actualTheme);
      html.setAttribute('data-theme', actualTheme);

      let metaThemeColor = document.querySelector('meta[name="theme-color"]');
      if (!metaThemeColor) {
        metaThemeColor = document.createElement('meta');
        metaThemeColor.name = 'theme-color';
        document.head.appendChild(metaThemeColor);
      }

      metaThemeColor.content = actualTheme === 'dark' ? '#1a1a1a' : '#f5f5f5';

      const root = document.documentElement;

      if (actualTheme === 'dark') {
        root.style.setProperty('--bg-primary', '#1a1a1a');
        root.style.setProperty('--bg-secondary', '#2d2d2d');
        root.style.setProperty('--text-primary', '#ffffff');
        root.style.setProperty('--text-secondary', '#a0a0a0');
      } else {
        root.style.setProperty('--bg-primary', '#f5f5f5');
        root.style.setProperty('--bg-secondary', '#ffffff');
        root.style.setProperty('--text-primary', '#1a1a1a');
        root.style.setProperty('--text-secondary', '#666666');
      }
    },
    [getActualTheme]
  );

  const changeTheme = useCallback(
    (newTheme) => {
      if (theme === newTheme) return;

      setTheme(newTheme);
      applyThemeToDOM(newTheme);
      localStorage.setItem('theme', newTheme);

      if (window.AndroidTheme && window.AndroidTheme.setTheme) {
        window.AndroidTheme.setTheme(newTheme);
      }
    },
    [theme, setTheme, applyThemeToDOM]
  );

  useEffect(() => {
    window.receiveInitialTheme = (androidTheme) => {
      if (androidTheme && androidTheme !== theme) {
        setTheme(androidTheme);
        applyThemeToDOM(androidTheme);
      }
    };

    window.onThemeChangeComplete = (confirmedTheme) =>
      console.log('Theme change confirmed:', confirmedTheme);

    applyThemeToDOM(theme);

    if (window.AndroidTheme && window.AndroidTheme.getCurrentTheme) {
      const androidTheme = window.AndroidTheme.getCurrentTheme();
      if (androidTheme && androidTheme !== theme) {
        setTheme(androidTheme);
        applyThemeToDOM(androidTheme);
      }
    }

    return () => {
      window.receiveInitialTheme = null;
      window.onThemeChangeComplete = null;
    };
  }, [theme, setTheme, applyThemeToDOM]);

  useEffect(() => {
    if (theme !== 'auto') return;

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = () => applyThemeToDOM('auto');

    if (mediaQuery.addEventListener) {
      mediaQuery.addEventListener('change', handleChange);
      return () => mediaQuery.removeEventListener('change', handleChange);
    }

    mediaQuery.addListener(handleChange);
    return () => mediaQuery.removeListener(handleChange);
  }, [theme, applyThemeToDOM]);

  const handleLanguageSelect = (lang) => {
    if (isLanguageActive(lang, currentLanguage)) return;
    if (!availableLanguages.some((item) => item.code === lang)) return;

    setPendingLanguage(lang);

    try {
      const result = handleLanguageChange(lang);

      if (result && typeof result.then === 'function') {
        result
          .then(() => setIsLanguagePickerOpen(false))
          .catch((err) => console.error('Language change failed:', err))
          .finally(() => setPendingLanguage(null));
      } else {
        setIsLanguagePickerOpen(false);
        setPendingLanguage(null);
      }
    } catch (err) {
      console.error('Language change failed:', err);
      setPendingLanguage(null);
    }
  };

  return (
    <>
      <div className="mx-auto max-w-3xl space-y-5 p-5">
        <div className="mb-1 flex items-center justify-between gap-4">
          <h1 className="text-3xl font-semibold text-white drop-shadow-md">
            {t('settings')}
          </h1>
        </div>

        <SectionCard icon={FaThermometerHalf} title={t('unitss')}>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <OptionButton active={units === 'metric'} onClick={() => setUnits('metric')}>
              °C, {t('units.kmh')}
            </OptionButton>
            <OptionButton active={units === 'imperial'} onClick={() => setUnits('imperial')}>
              °F, {t('units.mph')}
            </OptionButton>
          </div>
        </SectionCard>

        <SectionCard icon={FaPalette} title={t('theme')}>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <OptionButton active={theme === 'light'} onClick={() => changeTheme('light')} icon={FaSun}>
              {t('light')}
            </OptionButton>
            <OptionButton active={theme === 'dark'} onClick={() => changeTheme('dark')} icon={FaMoon}>
              {t('dark')}
            </OptionButton>
            <OptionButton active={theme === 'auto'} onClick={() => changeTheme('auto')} icon={FaSync}>
              {t('auto')}
            </OptionButton>
          </div>
        </SectionCard>

        <SectionCard icon={FaClock} title={t('timeFormat')}>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <OptionButton active={timeFormat === '24h'} onClick={() => setTimeFormat('24h')}>
              24 {t('units.hour')}
            </OptionButton>
            <OptionButton active={timeFormat === '12h'} onClick={() => setTimeFormat('12h')}>
              12 {t('units.hour')}
            </OptionButton>
          </div>
        </SectionCard>

        <SectionCard icon={FaGlobe} title={t('language')}>
          <LanguageTriggerButton
            onClick={() => setIsLanguagePickerOpen(true)}
            currentLanguageLabel={
              selectedLanguage?.nativeName ||
              t('selectLanguage', { defaultValue: 'Select language' })
            }
            currentLanguageCode={selectedLanguage?.codeLabel || ''}
            count={availableLanguages.length}
            disabled={availableLanguages.length === 0}
            loading={isChangingLanguage}
          />
        </SectionCard>
      </div>

      <LanguagePickerModal
        isOpen={isLanguagePickerOpen}
        onClose={() => setIsLanguagePickerOpen(false)}
        languages={availableLanguages}
        currentLanguage={currentLanguage}
        onSelect={handleLanguageSelect}
        pendingLanguage={pendingLanguage}
        isChangingLanguage={isChangingLanguage}
        t={t}
      />
    </>
  );
};

export default SettingsPanel;




