import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import CustomAlert from './CustomAlert';
import { AndroidBridge, useNativeMapView } from '@/native';

/**
 * Страница «Карты».
 *
 * Как это устроено:
 *   • в Android приложении карта — это ОТДЕЛЬНЫЙ нативный WebView поверх
 *     основного (иначе Windy/Blitzortung не откроются: они запрещают iframe);
 *   • React рисует только пустой «слот» нужного размера, а хук useNativeMapView
 *     непрерывно синхронизирует его getBoundingClientRect() с native;
 *   • в браузере тот же слот заполняется обычным <iframe>.
 *
 * Никаких window.Android в этом файле — только AndroidBridge.
 */

const defaultMenuItems = [
  { label: 'Blitzortung', color: '#FF5733', uri: 'https://map.blitzortung.org', isDefault: true },
  { label: 'Windy', color: '#34A853', uri: 'https://windy.com', isDefault: true },
  { label: 'LightningMaps', color: '#1877F2', uri: 'https://www.lightningmaps.org/', isDefault: true },
  { label: 'RainRadar', color: '#1DA1F2', uri: 'https://rainradar.ru/?54.018,39.271,5', isDefault: true },
  { label: 'Gismeteo', color: '#E1306C', uri: 'https://www.gismeteo.ru/nowcast-moscow-4368/', isDefault: true },
  { label: 'Спутниковые снимки', color: '#FF0000', uri: 'https://zelmeteo.ru', isDefault: true },
  { label: 'DWD', color: '#0A66C2', uri: 'https://www.dwd.de/DE/leistungen/hobbymet_wk_europa/hobbyeuropakarten.html', isDefault: true },
  { label: 'Meteociel', color: '#FF4500', uri: 'https://www.meteociel.fr/observations-meteo/temperatures.php', isDefault: true },
  { label: 'Pivotal Weather', color: '#FF9900', uri: 'http://www.pivotalweather.com/model.php', isDefault: true },
  { label: 'Skywarn', color: '#D3D3D3', uri: 'http://www.stormarchive.nl/#', isDefault: true },
];

const colorPalette = [
  '#FF5733', '#34A853', '#1877F2', '#1DA1F2', '#E1306C',
  '#FF0000', '#0A66C2', '#FF4500', '#FF9900', '#D3D3D3',
];

const PlusIcon = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 5v14M5 12h14" />
  </svg>
);

const RefreshIcon = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M20 11a8 8 0 1 0 2 5.3M20 4v7h-7" />
  </svg>
);

const BackIcon = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 18l-6-6 6-6" />
  </svg>
);

const ExpandIcon = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3m13-5v3a2 2 0 0 1-2 2h-3" />
  </svg>
);

const DefaultBadgeIcon = ({ className = 'w-3.5 h-3.5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round"
      d="M12 3l2.8 5.7 6.2.9-4.5 4.4 1.1 6.2L12 17.2 6.4 20.2l1.1-6.2L3 9.6l6.2-.9L12 3z" />
  </svg>
);

const WifiOffIcon = ({ className = 'w-16 h-16' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round"
      d="M1 1l22 22M16.72 11.06A10.94 10.94 0 0 1 19 12.55M5 12.55a10.94 10.94 0 0 1 5.17-2.39M10.71 5.05A16 16 0 0 1 22.56 9M1.42 9a15.91 15.91 0 0 1 4.7-2.88M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01" />
  </svg>
);

const GlobeErrorIcon = ({ className = 'w-16 h-16' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className}>
    <circle cx="12" cy="12" r="10" />
    <path strokeLinecap="round" strokeLinejoin="round"
      d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4M12 16h.01" />
  </svg>
);

const ActionButton = ({ onClick, title, children, variant = 'surface', className = '' }) => {
  const variants = {
    surface: 'border-slate-200/70 bg-white/85 text-slate-700 shadow-sm hover:-translate-y-0.5 hover:shadow-md dark:border-slate-700 dark:bg-slate-800/85 dark:text-slate-100',
    primary: 'border-blue-500/20 bg-gradient-to-br from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-600/20 hover:-translate-y-0.5 hover:shadow-xl',
    dark: 'border-white/10 bg-white/5 text-white hover:bg-white/10',
  };
  return (
    <button
      type="button" title={title} aria-label={title} onClick={onClick}
      className={`inline-flex h-11 w-11 items-center justify-center rounded-2xl border transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-blue-500/40 ${variants[variant]} ${className}`}
    >
      {children}
    </button>
  );
};

const ErrorScreen = ({ type = 'load', url = '', details = null, onRetry }) => {
  const { t } = useTranslation();
  const isOffline = type === 'offline';

  return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-6 bg-gradient-to-b from-slate-50 to-slate-400 px-8 dark:from-slate-900 dark:to-slate-950">
      <div className="flex h-28 w-28 items-center justify-center rounded-3xl bg-white shadow-xl dark:bg-slate-800">
        {isOffline
          ? <WifiOffIcon className="h-14 w-14 text-red-400 dark:text-red-500" />
          : <GlobeErrorIcon className="h-14 w-14 text-slate-400 dark:text-slate-500" />
        }
      </div>
      <div className="text-center">
        <h2 className="mb-2 text-xl font-semibold text-slate-800 dark:text-slate-100">
          {isOffline
            ? t('noInternetTitle', 'Нет подключения к интернету')
            : t('pageLoadErrorTitle', 'Не удалось загрузить страницу')}
        </h2>
        <p className="max-w-xs text-sm leading-relaxed text-slate-500 dark:text-slate-400">
          {isOffline
            ? t('noInternetDesc', 'Проверьте подключение к интернету и повторите попытку.')
            : t('pageLoadErrorDesc', 'Страница недоступна. Проверьте URL или попробуйте позже.')}
        </p>
        {url && (
          <p className="mt-2 max-w-xs truncate text-xs text-slate-800 dark:text-slate-600">{url}</p>
        )}
        {details && (
          <p className="mt-1 max-w-xs truncate text-[11px] text-slate-400 dark:text-slate-500">{details}</p>
        )}
      </div>
      <button
        type="button" onClick={onRetry}
        className="inline-flex items-center gap-2.5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-600/25 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl active:translate-y-0"
      >
        <RefreshIcon className="h-4 w-4" />
        {t('retry', 'Повторить')}
      </button>
    </div>
  );
};

const LoadingOverlay = () => (
  <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-4 bg-slate-50 dark:bg-slate-900">
    <div className="h-10 w-10 animate-spin rounded-full border-4 border-blue-500 border-t-transparent" />
    <p className="text-sm text-slate-400 dark:text-slate-500">Загрузка...</p>
  </div>
);

/** Веб-версия карты: обычный iframe в том же слоте. */
const IframeMap = ({ src, isConnected, onStatus }) => {
  const [status, setStatus] = useState('loading');
  const iframeRef = useRef(null);
  const timeoutRef = useRef(null);

  const startTimeout = useCallback(() => {
    clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      setStatus((prev) => (prev === 'loading' ? 'error' : prev));
    }, 20000);
  }, []);

  useEffect(() => {
    if (!isConnected) {
      setStatus('offline');
      return undefined;
    }
    setStatus('loading');
    startTimeout();
    return () => clearTimeout(timeoutRef.current);
  }, [src, isConnected, startTimeout]);

  useEffect(() => {
    if (onStatus) onStatus(status);
  }, [status, onStatus]);

  const handleRetry = () => {
    if (!navigator.onLine) {
      setStatus('offline');
      return;
    }
    setStatus('loading');
    if (iframeRef.current) iframeRef.current.src = src;
    startTimeout();
  };

  if (status === 'offline') {
    return <ErrorScreen type="offline" url={src} onRetry={handleRetry} />;
  }

  return (
    <div className="relative h-full w-full">
      {status === 'loading' && <LoadingOverlay />}
      {status === 'error' && (
        <div className="absolute inset-0 z-10">
          <ErrorScreen type="load" url={src} onRetry={handleRetry} />
        </div>
      )}
      <iframe
        ref={iframeRef}
        src={src}
        className="h-full w-full border-0"
        title="Weather Map"
        allow="geolocation *"
        onLoad={() => { clearTimeout(timeoutRef.current); setStatus('loaded'); }}
        onError={() => { clearTimeout(timeoutRef.current); setStatus('error'); }}
        style={{ visibility: status === 'loaded' ? 'visible' : 'hidden' }}
      />
    </div>
  );
};

const MapsPage = ({ activeTab = 'map' }) => {
  const { t } = useTranslation();

  const [isConnected, setIsConnected] = useState(
    typeof navigator === 'undefined' ? true : navigator.onLine
  );
  const [activeUri, setActiveUri] = useState(
    () => localStorage.getItem('activeUri') || defaultMenuItems[0].uri
  );

  const [modalVisible, setModalVisible] = useState(false);
  const [newLabel, setNewLabel] = useState('');
  const [newColor, setNewColor] = useState('#FF5733');
  const [newUri, setNewUri] = useState('');

  const [favorites, setFavorites] = useState(() => {
    const saved = localStorage.getItem('favorites');
    return saved ? JSON.parse(saved) : [];
  });

  const [isRemoveAlertVisible, setIsRemoveAlertVisible] = useState(false);
  const [itemToRemoveIndex, setItemToRemoveIndex] = useState(null);
  const [isErrorAlertVisible, setIsErrorAlertVisible] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const [isFullScreen, setIsFullScreen] = useState(false);
  const [iframeKey, setIframeKey] = useState(0);

  /** Слот, в границы которого native вписывает свой WebView. */
  const mapSlotRef = useRef(null);

  const isMapTab = activeTab === 'map';
  const anyOverlayOpen = modalVisible || isRemoveAlertVisible || isErrorAlertVisible;

  const {
    isNative,
    errorDescription,
    isLoading,
    hasError,
    isOffline,
    retry,
    refreshLayout,
  } = useNativeMapView({
    slotRef: mapSlotRef,
    url: activeUri,
    active: isMapTab,
    // Пока открыт модал или пропал интернет — нативная карта прячется,
    // иначе она перекроет собой веб-интерфейс (она физически поверх него).
    // При ошибке загрузки native прячет свой WebView сам.
    visible: !anyOverlayOpen && isConnected,
    insetsMode: 'auto',
  });

  // ── Сеть ──────────────────────────────────────────────────────────────────

  useEffect(() => {
    const onOnline = () => setIsConnected(true);
    const onOffline = () => setIsConnected(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  // ── Полноэкранный режим меняет геометрию слота ────────────────────────────

  useEffect(() => {
    refreshLayout();
  }, [isFullScreen, refreshLayout]);

  // ── Аппаратная кнопка «назад» выходит из полноэкранного режима ────────────

  useEffect(() => {
    if (!isFullScreen) return undefined;
    const onPopState = () => setIsFullScreen(false);
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, [isFullScreen]);

  // ── Handlers ──────────────────────────────────────────────────────────────

  const isValidUrl = (url) => {
    try {
      const parsed = new URL(url);
      return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch {
      return false;
    }
  };

  const handleMenuItemPress = (uri) => {
    if (uri === activeUri) return;
    setActiveUri(uri);
    localStorage.setItem('activeUri', uri);
    if (isNative) AndroidBridge.map.setUrl(uri);
  };

  const handleRefresh = () => {
    if (isNative) {
      retry();
    } else {
      setIframeKey((k) => k + 1);
    }
  };

  const handleAddToFavorites = () => {
    if (!newLabel || !newColor || !newUri) {
      setErrorMessage(t('fillAllFields'));
      setIsErrorAlertVisible(true);
      return;
    }
    if (!isValidUrl(newUri)) {
      setErrorMessage(t('invalidUrl'));
      setIsErrorAlertVisible(true);
      return;
    }
    const updated = [...favorites, { label: newLabel, color: newColor, uri: newUri, isDefault: false }];
    setFavorites(updated);
    localStorage.setItem('favorites', JSON.stringify(updated));
    setModalVisible(false);
    setNewLabel('');
    setNewColor('#FF5733');
    setNewUri('');
  };

  const showRemoveConfirmation = (i) => {
    setItemToRemoveIndex(i);
    setIsRemoveAlertVisible(true);
  };

  const handleRemoveFromFavorites = () => {
    setIsRemoveAlertVisible(false);
    if (itemToRemoveIndex !== null) {
      const updated = favorites.filter((_, i) => i !== itemToRemoveIndex);
      setFavorites(updated);
      localStorage.setItem('favorites', JSON.stringify(updated));
      setItemToRemoveIndex(null);
    }
  };

  const handleCancelRemove = () => {
    setIsRemoveAlertVisible(false);
    setItemToRemoveIndex(null);
  };

  const menuItems = useMemo(
    () => [...defaultMenuItems, ...favorites],
    [favorites]
  );

  const renderMenuItem = (item, index) => {
    const isActive = activeUri === item.uri;
    return (
      <div key={`${item.uri}-${index}`} className="shrink-0">
        <button
          type="button" title={item.label}
          className={`group relative flex items-center gap-2.5 rounded-2xl border px-4 py-3 transition-all duration-300 will-change-transform ${
            isActive
              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
              : 'bg-white/85 text-slate-700 hover:-translate-y-0.5 hover:shadow-md dark:bg-slate-800/90 dark:text-slate-200'
          }`}
          style={{
            borderColor: isActive ? item.color : 'rgba(148,163,184,0.22)',
            boxShadow: isActive
              ? `0 10px 30px rgba(15,23,42,0.18), 0 0 0 1px ${item.color}`
              : '0 4px 12px rgba(15,23,42,0.06)',
          }}
          onClick={() => handleMenuItemPress(item.uri)}
          onContextMenu={(e) => {
            e.preventDefault();
            if (!item.isDefault) showRemoveConfirmation(index - defaultMenuItems.length);
          }}
        >
          <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: item.color }} />
          <span className="max-w-[160px] truncate text-sm font-medium tracking-[0.01em]">{item.label}</span>
          {item.isDefault && (
            <span className={`inline-flex h-6 w-6 items-center justify-center rounded-xl border ${
              isActive
                ? 'border-white/15 bg-white/10 text-white dark:border-slate-300 dark:bg-slate-900/10 dark:text-slate-900'
                : 'border-slate-200 bg-slate-50 text-slate-500 dark:border-slate-700 dark:bg-slate-700/60 dark:text-slate-300'
            }`}>
              <DefaultBadgeIcon />
            </span>
          )}
        </button>
      </div>
    );
  };

  // ── Что показать в слоте ──────────────────────────────────────────────────

  const showOfflineScreen = !isConnected;
  const showNativeError = isNative && !showOfflineScreen && hasError;

  const slotContent = (() => {
    if (showOfflineScreen) {
      return <ErrorScreen type="offline" url={activeUri} onRetry={handleRefresh} />;
    }
    if (showNativeError) {
      return (
        <ErrorScreen
          type={isOffline ? 'offline' : 'load'}
          url={activeUri}
          details={errorDescription}
          onRetry={retry}
        />
      );
    }
    if (!isNative) {
      return (
        <IframeMap
          key={`${activeUri}-${iframeKey}`}
          src={activeUri}
          isConnected={isConnected}
        />
      );
    }
    // Нативный режим: слот остаётся ПУСТЫМ — в него native кладёт свой WebView.
    return isLoading ? <LoadingOverlay /> : null;
  })();

  // ── Render ────────────────────────────────────────────────────────────────

  if (isFullScreen) {
    return (
      <div className="fixed inset-0 z-50 flex flex-col bg-slate-900">
        <div
          className="flex items-center justify-between border-b border-white/10 bg-slate-950/80 px-4 backdrop-blur-xl"
          style={{ paddingTop: 'calc(var(--safe-area-top, 0px) + 12px)', paddingBottom: 12 }}
        >
          <button
            type="button"
            onClick={() => setIsFullScreen(false)}
            className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-3.5 py-2.5 text-sm font-medium text-white transition-all hover:bg-white/10"
          >
            <BackIcon className="h-4 w-4" /><span>{t('back')}</span>
          </button>
          <ActionButton title={t('refresh', 'Обновить')} variant="dark" onClick={handleRefresh}>
            <RefreshIcon />
          </ActionButton>
        </div>

        {/*
          Во весь экран: слот доходит до самого низа.
          Нативная сторона в режиме insetsMode="auto" сама решит, можно ли
          зайти под системную навигацию (жесты — можно, кнопки — нет).
        */}
        <div ref={mapSlotRef} className="relative w-full flex-1">
          {slotContent}
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      <div className="relative z-40 w-full border-b border-slate-200/60 bg-white/75 backdrop-blur-xl dark:border-slate-800/80 dark:bg-slate-950/75">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-blue-500/30 to-transparent" />
        <div className="flex items-center gap-3 px-3 py-3 sm:px-4">
          <div className="flex min-w-0 flex-1 gap-2 overflow-x-auto scrollbar-hide">
            {menuItems.map(renderMenuItem)}
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <ActionButton title={t('fullscreen', 'Во весь экран')} variant="surface" onClick={() => setIsFullScreen(true)}>
              <ExpandIcon />
            </ActionButton>
            <ActionButton title={t('add', 'Добавить')} variant="primary" onClick={() => setModalVisible(true)}>
              <PlusIcon />
            </ActionButton>
            <ActionButton title={t('refresh', 'Обновить')} variant="surface" onClick={handleRefresh}>
              <RefreshIcon />
            </ActionButton>
          </div>
        </div>
      </div>

      {/*
        Слот карты.
        Высота = всё оставшееся место МИНУС нижняя панель вкладок.
        --tabbar-space измеряется в рантайме (см. useTabBarSpace в
        NavigationBar): туда входит высота панели, ВЫСТУПАЮЩИЙ КРУГ активной
        вкладки и системный отступ снизу. Это важно: нативный WebView карты
        рисуется ПОВЕРХ веба, поэтому всё, что он накроет, станет невидимым.
      */}
      <div
        ref={mapSlotRef}
        className="relative w-full flex-1"
        style={{ marginBottom: 'var(--tabbar-space, 110px)' }}
      >
        {slotContent}
      </div>

      {modalVisible && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm">
          <div className="w-80 rounded-3xl border border-slate-200/70 bg-white/95 p-6 shadow-2xl dark:border-slate-700 dark:bg-slate-800/95">
            <h3 className="mb-4 text-lg font-semibold text-slate-900 dark:text-white">Добавить в избранное</h3>
            <input type="text" placeholder="Название" value={newLabel}
              onChange={(e) => setNewLabel(e.target.value)}
              className="mb-3 w-full rounded-2xl border border-slate-300 bg-white px-3 py-2.5 text-slate-900 outline-none transition focus:border-blue-500 dark:border-slate-600 dark:bg-slate-700 dark:text-white" />
            <input type="text" placeholder="URL" value={newUri}
              onChange={(e) => setNewUri(e.target.value)}
              className="mb-3 w-full rounded-2xl border border-slate-300 bg-white px-3 py-2.5 text-slate-900 outline-none transition focus:border-blue-500 dark:border-slate-600 dark:bg-slate-700 dark:text-white" />
            <div className="mb-4 flex flex-wrap gap-2">
              {colorPalette.map((c) => (
                <button key={c} type="button"
                  className={`h-7 w-7 rounded-full transition ${newColor === c ? 'ring-2 ring-blue-500 ring-offset-2 dark:ring-offset-slate-800' : ''}`}
                  style={{ backgroundColor: c }} onClick={() => setNewColor(c)} />
              ))}
            </div>
            <div className="flex gap-2">
              <button type="button" onClick={() => setModalVisible(false)}
                className="flex-1 rounded-2xl bg-slate-200 px-4 py-2.5 font-medium text-slate-900 transition hover:bg-slate-300 dark:bg-slate-700 dark:text-white dark:hover:bg-slate-600">
                Отмена</button>
              <button type="button" onClick={handleAddToFavorites}
                className="flex-1 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 px-4 py-2.5 font-medium text-white transition hover:opacity-95">
                Добавить</button>
            </div>
          </div>
        </div>
      )}

      <CustomAlert visible={isRemoveAlertVisible} title={t('removeFavorite')} message={t('removeConfirmation')}
        buttons={[
          { text: t('cancel'), onPress: handleCancelRemove, style: 'cancel' },
          { text: t('ok'), onPress: handleRemoveFromFavorites, style: 'confirm' },
        ]} />
      <CustomAlert visible={isErrorAlertVisible} title={t('error')} message={errorMessage}
        buttons={[{ text: t('ok'), onPress: () => setIsErrorAlertVisible(false), style: 'confirm' }]} />
    </div>
  );
};

export default MapsPage;
