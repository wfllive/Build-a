import React from 'react';

const CustomAlert = ({ visible, title, message, buttons }) => {
  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="w-4/5 max-w-md rounded-lg border border-gray-600 bg-gray-800 p-5 shadow-lg">
        <h2 className="mb-2 text-center text-lg font-bold text-white">
          {title}
        </h2>
        <p className="mb-5 text-center text-gray-200">
          {message}
        </p>
        <div className="flex justify-center space-x-3">
          {buttons.map((button, index) => (
            <button
              key={index}
              className={`rounded px-5 py-2 font-bold ${
                button.style === 'cancel'
                  ? 'bg-gray-600 text-gray-200 hover:bg-gray-500'
                  : button.style === 'confirm'
                  ? 'bg-blue-600 text-white hover:bg-blue-500'
                  : 'bg-gray-700 text-gray-200 hover:bg-gray-600'
              }`}
              onClick={button.onPress}
            >
              {button.text}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CustomAlert;