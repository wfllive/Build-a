

import React, { useRef, useEffect, useState, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { FaBars, FaSync, FaLocationArrow, FaSearch } from 'react-icons/fa';

import BlurCard from 'weather-ui/BlurCard';
import AirQualityIndicator from 'weather-widgets/AirQualityIndicator';
import ClothingRecommendation from 'weather-widgets/ClothingRecommendation';
import Compass from 'weather-widgets/Compass';
import NavigationBar from 'weather-ui/NavigationBar';
import SunriseSunsetCard from 'weather-widgets/SunriseSunsetCard';
import WeatherDisplay from 'weather-widgets/WeatherDisplay';
import HourlyForecast from 'weather-widgets/HourlyForecast';
import DailyForecast from 'weather-widgets/DailyForecast';
import SearchModal from 'weather-ui/SearchModal';
import MoonPhaseCard from 'weather-widgets/MoonPhaseCard';
import WeatherBackground from 'weather-icons/weatherBackgrounds';
import LoadingIndicator from 'weather-ui/LoadingIndicator';
import ErrorModal from 'weather-ui/ErrorModal';

import { useWeatherData } from '../hooks/useWeatherData';
import { useWeatherUI } from '../hooks/useWeatherUI';
import { WeatherDataUtils } from '@/api';

const TAB_PATHS = {
  home: '/',
  map: '/map',
  favorites: '/favorites',
  settings: '/settings',
};

const HeaderBar = ({
  showHeader,
  headerBlur,
  scrollProgress,
  headerCityOpacity,
  isRefreshing,
  cityName,
  weatherData,
  getTemp,
  toggleDrawer,
  handleRefresh,
  getCurrentLocation,
  setShowSearch,
  t,
}) => {
  if (!showHeader) return null;

  return (
    <div
      className={`
        fixed top-0 left-0 right-0 z-50 h-[60px] sm:h-[70px] flex items-center transition-all duration-500
        ${headerBlur > 0
          ? 'bg-white/20 dark:bg-gray-800/40 backdrop-blur-lg shadow-sm'
          : 'bg-transparent backdrop-blur-none'}
      `}
    >
      <div
        className="absolute bottom-0 left-0 right-0 h-[1px]"
        style={{
          background:
            scrollProgress > 0.1
              ? 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.2) 20%, rgba(255,255,255,0.3) 50%, rgba(255,255,255,0.2) 80%, transparent 100%)'
              : 'transparent',
          opacity: Math.min(scrollProgress * 2, 1),
        }}
      />

      {isRefreshing && (
        <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-white/50 to-transparent animate-pulse" />
      )}

      <div className="w-full px-3 sm:px-4 max-w-[1400px] mx-auto">
        <div className="flex justify-between items-center">
          <div className="flex-shrink-0">
            <button
              onClick={toggleDrawer}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 transition-all duration-200"
              aria-label={t('menu')}
            >
              <FaBars className="text-white text-base sm:text-lg" />
            </button>
          </div>

          <div
            className="flex-1 mx-2 sm:mx-4 overflow-hidden"
            style={{
              opacity: headerCityOpacity,
              transform: `translateY(${headerCityOpacity > 0 ? 0 : 10}px)`,
              transition: 'opacity 0.4s ease-out, transform 0.4s ease-out',
            }}
          >
            <div className="flex items-center justify-center gap-2 sm:gap-3">
              <div className="flex flex-col items-center min-w-0 max-w-[100px] sm:max-w-[160px] md:max-w-[280px]">
                <div className="w-full overflow-hidden">
                  <span
                    className={`text-white font-semibold text-sm sm:text-base md:text-lg whitespace-nowrap inline-block
                    ${cityName && cityName.length > 10 ? 'animate-marquee hover:[animation-play-state:paused]' : ''}`}
                  >
                    {cityName}
                  </span>
                </div>

                {weatherData && (
                  <div className="w-full overflow-hidden sm:hidden">
                    <span
                      className={`text-white/60 text-[10px] whitespace-nowrap inline-block
                      ${weatherData.current.condition.text.length > 12 ? 'animate-marquee hover:[animation-play-state:paused]' : ''}`}
                    >
                      {weatherData.current.condition.text}
                    </span>
                  </div>
                )}
              </div>

              {weatherData && (
                <span className="text-white font-bold text-base sm:text-lg flex-shrink-0">
                  {Math.round(getTemp(weatherData.current.temp_c))}°
                </span>
              )}
            </div>
          </div>

          <div className="flex-shrink-0 flex items-center gap-1 sm:gap-2">
            <button
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 disabled:opacity-50 transition-all duration-200"
              aria-label={t('refresh')}
            >
              <FaSync className={`text-white text-sm sm:text-base ${isRefreshing ? 'animate-spin' : ''}`} />
            </button>

            <button
              onClick={() => getCurrentLocation(true)}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 transition-all duration-200"
              aria-label={t('currentLocation')}
            >
              <FaLocationArrow className="text-white text-sm sm:text-base" />
            </button>

            <button
              onClick={() => setShowSearch(true)}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 transition-all duration-200"
              aria-label={t('search')}
            >
              <FaSearch className="text-white text-sm sm:text-base" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const HomeContent = ({
  cityName,
  weatherData,
  forecastData,
  scrollY,
  t,
  units,
  language,
  timeFormat,
  formatDate,
  formatTime,
  formatWeekday,
  formatShortDate,
  getTemp,
  getWindSpeed,
  getPrecip,
  getAirQualityIndex,
}) => {
  if (!weatherData || !forecastData) return null;

  const scrollProgress = Math.min(scrollY / 200, 1);
  const heroOpacity = Math.max(1 - scrollProgress * 1.8, 0);
  const heroTranslateY = scrollY * 0.4;
  const heroScale = 1 - scrollProgress * 0.05;

  return (
    <>
      <div
        className="relative flex flex-col items-center justify-center px-4"
        style={{ minHeight: '85vh' }}
      >
        <div
          className="w-full max-w-[440px] mx-auto"
          style={{
            transform: `translateY(-${heroTranslateY}px) scale(${heroScale})`,
            opacity: heroOpacity,
            willChange: 'transform, opacity',
          }}
        >
          <div className="text-center mb-4">
            <h1 className="text-2xl md:text-4xl font-bold text-white mb-1 drop-shadow-lg">
              {cityName}
            </h1>
            <div className="text-gray-100 text-sm md:text-base font-medium opacity-90">
              {formatDate(weatherData.location.localtime)}
            </div>
          </div>

          <WeatherDisplay
            weatherData={weatherData}
            forecastData={forecastData}
            t={t}
            getTemp={getTemp}
            getWindSpeed={getWindSpeed}
            getPrecip={getPrecip}
          />
        </div>
      </div>

      <div className="relative z-20 pb-16">
        <div className="p-3 md:p-4 max-w-[1200px] mx-auto flex flex-col gap-4 pb-24">
          <div className="w-full">
            <BlurCard>
              <HourlyForecast
                forecastData={forecastData}
                formatTime={formatTime}
                getTemp={getTemp}
              />
            </BlurCard>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            <div className="lg:col-span-1 xl:col-span-1">
              <BlurCard className="h-full min-h-[220px] flex flex-col justify-center">
                <DailyForecast
                  forecastData={forecastData}
                  t={t}
                  formatWeekday={formatWeekday}
                  formatShortDate={formatShortDate}
                  units={units}
                  language={language}
                />
              </BlurCard>
            </div>

            <BlurCard className="h-full min-h-[130px] flex flex-col justify-center">
              <AirQualityIndicator epaIndex={getAirQualityIndex(weatherData.current)} />
            </BlurCard>

            <BlurCard className="h-full min-h-[130px] flex flex-col justify-center">
              <ClothingRecommendation
                weatherConditionCode={weatherData.current.condition.code}
                temperature={weatherData.current.temp_c}
                windSpeed={weatherData.current.wind_kph}
              />
            </BlurCard>

            <BlurCard className="h-full min-h-[130px] flex flex-col items-center justify-center py-3">
              <h2 className="text-sm md:text-base font-semibold mb-1 text-center text-white/90">
                {t('windDirection')}
              </h2>
              <Compass
                windSpeed={Math.round(weatherData.current.wind_kph)}
                windDirection={weatherData.current.wind_dir}
              />
            </BlurCard>

            <BlurCard className="h-full min-h-[130px] flex flex-col justify-center">
              <MoonPhaseCard
                forecastData={forecastData}
                t={t}
                formatTime={formatTime}
              />
            </BlurCard>

            <div className="md:col-span-2 lg:col-span-1 xl:col-span-2">
              <BlurCard className="h-full min-h-[130px] flex flex-col justify-center">
                <SunriseSunsetCard
                  sunrise={WeatherDataUtils.getSunrise(forecastData)}
                  sunset={WeatherDataUtils.getSunset(forecastData)}
                  currentTime={weatherData.location.localtime}
                  timeFormat={timeFormat === '12h' ? 12 : 24}
                  timezone={weatherData.location.tz_id}
                />
              </BlurCard>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

const WeatherPage = ({
  toggleDrawer,
  userLocation,
  locationDecided,
  page = 'home',
  children,
}) => {
  const { t } = useTranslation();
  const navigate = useNavigate();

  const scrollContainerRef = useRef(null);
  const [scrollY, setScrollY] = useState(0);

  const {
    currentLocation,
    weatherData,
    forecastData,
    searchQuery,
    searchResults,
    savedCities,
    isLoading,
    error,
    locationError,
    weatherType,
    units,
    theme,
    showSearch,
    language,
    isChangingLanguage,
    timeFormat,
    isRefreshing,
    timeOfDay,
    setSearchQuery,
    setActiveTab,
    setShowSearch,
    setUnits,
    setTheme,
    setTimeFormat,
    fetchWeather,
    getCurrentLocation,
    setError,
    handleRefresh,
    handleLanguageChange,
    addSavedCity,
    removeSavedCity,
    useDefaultLocation,
    formatDate,
    formatTime,
    formatWeekday,
    formatShortDate,
    getTemp,
    getWindSpeed,
    getPrecip,
    getAirQualityIndex,
  } = useWeatherData(userLocation, locationDecided);

  const { showHeader } = useWeatherUI(
    page,
    weatherData,
    forecastData,
    theme,
    setTheme
  );

  const handleScroll = useCallback(() => {
    if (scrollContainerRef.current) {
      setScrollY(scrollContainerRef.current.scrollTop);
    }
  }, []);

  const handleRouteTabChange = useCallback(
    (tabId) => {
      navigate(TAB_PATHS[tabId] || '/');
    },
    [navigate]
  );

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    container.addEventListener('scroll', handleScroll, { passive: true });
    return () => container.removeEventListener('scroll', handleScroll);
  }, [handleScroll]);

  useEffect(() => {
    if (typeof setActiveTab === 'function') {
      setActiveTab(page);
    }
  }, [page, setActiveTab]);

  useEffect(() => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({ top: 0 });
    }
  }, [page]);

  const scrollProgress = Math.min(scrollY / 200, 1);
  const headerCityOpacity =
    scrollProgress > 0.2 ? Math.min((scrollProgress - 0.2) * 3, 1) : 0;
  const headerBlur =
    scrollProgress > 0.05 ? Math.min(scrollProgress * 25, 20) : 0;

  const cityName =
    typeof currentLocation === 'object' ? currentLocation?.name : currentLocation;

  const renderChildPage = () => {
    if (!children || !React.isValidElement(children)) {
      return (
        <HomeContent
          cityName={cityName}
          weatherData={weatherData}
          forecastData={forecastData}
          scrollY={scrollY}
          t={t}
          units={units}
          language={language}
          timeFormat={timeFormat}
          formatDate={formatDate}
          formatTime={formatTime}
          formatWeekday={formatWeekday}
          formatShortDate={formatShortDate}
          getTemp={getTemp}
          getWindSpeed={getWindSpeed}
          getPrecip={getPrecip}
          getAirQualityIndex={getAirQualityIndex}
        />
      );
    }

    const childPropsByPage = {
      map: {
        t,
        activeTab: page,
      },
      favorites: {
        t,
        savedCities,
        fetchWeather,
        setActiveTab: handleRouteTabChange,
        removeSavedCity,
        setShowSearch,
      },
      settings: {
        units,
        setUnits,
        theme,
        setTheme,
        timeFormat,
        setTimeFormat,
        language,
        handleLanguageChange,
        isChangingLanguage,
        t,
      },
    };

    const wrapperClassByPage = {
      // Карте нужна ТОЧНАЯ высота: она отдаёт свои границы нативному WebView.
      // h-full работает, потому что скролл-контейнер имеет заданную высоту (h-screen).
      map: `h-full overflow-hidden ${showHeader ? 'pt-[70px]' : ''}`,
      favorites: `p-5 max-w-4xl mx-auto pb-tabbar ${showHeader ? 'pt-[90px]' : ''}`,
      settings: `p-5 max-w-2xl mx-auto pb-tabbar ${showHeader ? 'pt-[90px]' : ''}`,
    };

    return (
      <div className={wrapperClassByPage[page] || ''}>
        {React.cloneElement(children, childPropsByPage[page] || {})}
      </div>
    );
  };

  return (
    <div className="relative w-[100vw] min-h-screen overflow-x-hidden left-1/2 right-1/2 -ml-[50vw] -mr-[50vw] -mt-4">
      <div className="fixed inset-0 z-0" style={{ filter: 'brightness(0.8)' }}>
        <WeatherBackground
          weatherType={weatherType}
          timeOfDay={timeOfDay}
          style={{ width: '100%', height: '100%' }}
        />
      </div>

      <HeaderBar
        showHeader={showHeader}
        headerBlur={headerBlur}
        scrollProgress={scrollProgress}
        headerCityOpacity={headerCityOpacity}
        isRefreshing={isRefreshing}
        cityName={cityName}
        weatherData={weatherData}
        getTemp={getTemp}
        toggleDrawer={toggleDrawer}
        handleRefresh={handleRefresh}
        getCurrentLocation={getCurrentLocation}
        setShowSearch={setShowSearch}
        t={t}
      />

      <div
        ref={scrollContainerRef}
        className={`relative z-10 h-screen text-white scrollbar-none ${
          page === 'map' ? 'overflow-hidden' : 'overflow-y-auto'
        } ${showSearch ? 'blur-sm pointer-events-none' : ''}`}
      >
        {renderChildPage()}
      </div>

      <NavigationBar />

      <SearchModal
        showSearch={showSearch}
        setShowSearch={setShowSearch}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        searchResults={searchResults}
        addSavedCity={addSavedCity}
        savedCities={savedCities}
        removeSavedCity={removeSavedCity}
        fetchWeather={fetchWeather}
        setActiveTab={handleRouteTabChange}
        t={t}
      />

      <LoadingIndicator isLoading={isLoading} t={t} />

      <ErrorModal
        error={error}
        isLoading={isLoading}
        setError={setError}
        locationError={locationError}
        useDefaultLocation={useDefaultLocation}
        getCurrentLocation={getCurrentLocation}
        t={t}
      />
    </div>
  );
};

export default WeatherPage;