

import React from 'react';
import { FaMapMarkerAlt, FaTimes, FaPlus } from 'react-icons/fa';
import BlurCard from 'weather-ui/BlurCard';

const FavoritesPage = ({
  t,
  savedCities = [],
  fetchWeather,
  setActiveTab,
  removeSavedCity,
  setShowSearch,
}) => {
  const hasCities = savedCities.length > 0;

  const openCity = (city) => {
    fetchWeather(`${city.name}, ${city.country}`);
    setActiveTab('home');
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-5">
      <div className="flex items-center justify-between mb-5 gap-3">
        <h1 className="text-xl sm:text-2xl font-semibold text-white truncate">
          {t('savedCities')}
        </h1>

        {hasCities && (
          <button
            type="button"
            onClick={() => setShowSearch(true)}
            // На мобилках: просто квадратная кнопка с плюсом. На ПК: с текстом
            className="flex flex-shrink-0 items-center justify-center gap-2 p-2.5 sm:px-4 sm:py-2 rounded-xl bg-blue-500 text-white font-medium hover:bg-blue-600 active:bg-blue-700 transition-colors"
            title={t('addCity')}
          >
            <FaPlus size={14} />
            <span className="hidden sm:inline">{t('addCity')}</span>
          </button>
        )}
      </div>

      {!hasCities ? (
        <BlurCard className="p-6 sm:p-8 rounded-2xl text-center">
          <div className="flex justify-center mb-4">
            <div className="w-14 h-14 rounded-full bg-white/10 flex items-center justify-center">
              <FaMapMarkerAlt className="text-blue-400" size={20} />
            </div>
          </div>

          <p className="text-white text-lg font-medium mb-2">
            {t('noSavedCities')}
          </p>

          <p className="text-gray-300 text-sm mb-6">
            {t('addCity')}
          </p>

          <button
            type="button"
            onClick={() => setShowSearch(true)}
            // w-full на мобилках делает кнопку большой и удобной для палца
            className="inline-flex w-full sm:w-auto justify-center items-center gap-2 px-5 py-3.5 rounded-xl bg-blue-500 text-white font-medium hover:bg-blue-600 active:bg-blue-700 transition-colors"
          >
            <FaPlus size={12} />
            {t('addCity')}
          </button>
        </BlurCard>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {savedCities.map((city, index) => (
            <BlurCard
              key={city.id ?? `${city.name}-${city.country}-${index}`}
              className="p-3 sm:p-4 rounded-2xl transition-transform active:scale-[0.98]"
            >
              <div className="flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => openCity(city)}
                  // active:opacity-70 дает понимание, что на карточку нажали
                  className="flex items-center gap-3 flex-1 text-left active:opacity-70 transition-opacity min-w-0"
                >
                  <div className="w-11 h-11 flex-shrink-0 rounded-xl bg-white/10 flex items-center justify-center">
                    <FaMapMarkerAlt className="text-blue-400" />
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="text-white font-medium truncate">
                      {city.name}
                    </div>
                    <div className="text-sm text-gray-300 truncate">
                      {city.country}
                    </div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    removeSavedCity(index);
                  }}
                  aria-label={`${t('remove')} ${city.name}`}
                  // flex-shrink-0 не даст кнопке сжаться, w-10 h-10 удобнее нажимать
                  className="flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center text-red-400 hover:bg-white/10 active:bg-red-500/20 transition-colors"
                >
                  <FaTimes size={14} />
                </button>
              </div>
            </BlurCard>
          ))}
        </div>
      )}
    </div>
  );
};

export default FavoritesPage;


