import React from 'react';
import { BrowserRouter, HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import WeatherPage from 'pages/WeatherPage';
import MapsPage from 'pages/MapsPage';
import FavoritesPage from 'pages/FavoritesPage';
import SettingsPanel from 'pages/SettingsPanel';

/*
 * ВАЖНО: выбор роутера зависит от того, откуда загружена страница.
 *
 * • dev-сервер (http://localhost:3000) — обычный BrowserRouter;
 * • release-сборка Android грузит бандл как file:///android_asset/dist/index.html.
 *
 * У file:// «непрозрачный» origin, и History API там запрещён:
 *
 *   SecurityError: Failed to execute 'replaceState' on 'History':
 *   A history state object with URL 'file:///' cannot be created in a document
 *   with origin 'null'.
 *
 * BrowserRouter дёргает replaceState сразу при старте (маршрут
 * file:///android_asset/dist/index.html не совпадает ни с одним path,
 * срабатывает <Navigate to="/" replace />) — исключение улетает наверх,
 * React не монтирует дерево и экран остаётся ПУСТЫМ.
 * Именно поэтому debug работал, а release показывал белый экран.
 *
 * HashRouter меняет только фрагмент (#/map) — это разрешено на file://
 * и является стандартным решением для локально загружаемых бандлов.
 */
const isFileProtocol =
  typeof window !== 'undefined' && window.location.protocol === 'file:';

const Router = isFileProtocol ? HashRouter : BrowserRouter;

const AppRouter = (props) => {
  return (
    <Router basename="/">
      <Routes>
        <Route path="/" element={<WeatherPage {...props} page="home" />} />

        <Route
          path="/map"
          element={
            <WeatherPage {...props} page="map">
              <MapsPage />
            </WeatherPage>
          }
        />

        <Route
          path="/favorites"
          element={
            <WeatherPage {...props} page="favorites">
              <FavoritesPage />
            </WeatherPage>
          }
        />

        <Route
          path="/settings"
          element={
            <WeatherPage {...props} page="settings">
              <SettingsPanel />
            </WeatherPage>
          }
        />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
};

export default AppRouter;
