import { useEffect, useState } from 'react';

export const useWeatherUI = (activeTab, weatherData, forecastData, theme, setTheme) => {
  const [systemTheme, setSystemTheme] = useState(null);

  // Determine if header should be shown
  const showHeader = activeTab === 'home' && weatherData && forecastData;

  // Android theme detection
  useEffect(() => {
    const handleAndroidTheme = (event) => {
      const isDark = event.detail;
      setSystemTheme(isDark ? 'dark' : 'light');
      if (theme === 'auto') {
        document.documentElement.classList.toggle('dark', isDark);
      }
    };

    window.addEventListener('androidThemeChanged', handleAndroidTheme);

    if (window.Android) {
      try {
        const isDark = window.Android.isDarkMode();
        setSystemTheme(isDark ? 'dark' : 'light');
      } catch (e) {
        console.log('Android interface error:', e);
      }
    }

    return () => {
      window.removeEventListener('androidThemeChanged', handleAndroidTheme);
    };
  }, [theme]);

  // Theme management
  useEffect(() => {
    if (theme === 'auto') {
      if (systemTheme !== null) {
        document.documentElement.classList.toggle('dark', systemTheme === 'dark');
      } else {
        const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
        const handler = (e) => document.documentElement.classList.toggle('dark', e.matches);
        document.documentElement.classList.toggle('dark', mediaQuery.matches);
        mediaQuery.addEventListener('change', handler);
        return () => mediaQuery.removeEventListener('change', handler);
      }
    } else {
      document.documentElement.classList.toggle('dark', theme === 'dark');
    }
  }, [theme, systemTheme]);

  return {
    showHeader,
    systemTheme
  };
};