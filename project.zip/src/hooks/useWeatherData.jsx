

import { useState, useEffect, useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { WeatherProvider, WEATHER_TYPES } from '@/api';

const STORAGE_KEY = 'weatherAppData';
const MIN_REFRESH_INTERVAL = 3600000;

export const useWeatherData = (userLocation, locationDecided = true) => {
  const { t, i18n } = useTranslation();
  
  const [weatherProvider] = useState(() => new WeatherProvider());
  
  const fetchIdRef = useRef(0);
  const initialLoadDoneRef = useRef(false);
  const isGettingLocationRef = useRef(false);
  
  const [currentLocation, setCurrentLocation] = useState('Moscow, Russia');
  const [weatherData, setWeatherData] = useState(null);
  const [forecastData, setForecastData] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [savedCities, setSavedCities] = useState([]);
  const [activeTab, setActiveTab] = useState('home');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [locationError, setLocationError] = useState(false);
  const [weatherType, setWeatherType] = useState(WEATHER_TYPES.CLEAR);
  const [units, setUnits] = useState('metric');
  const [theme, setTheme] = useState('auto');
  const [showSearch, setShowSearch] = useState(false);
  const [initialized, setInitialized] = useState(false);
  const [language, setLanguage] = useState('ru');
  const [isChangingLanguage, setIsChangingLanguage] = useState(false);
  const [timeFormat, setTimeFormat] = useState('24h');
  const [lastUpdateTime, setLastUpdateTime] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [timeOfDay, setTimeOfDay] = useState('day');

  const shouldRefreshOnLoad = useCallback((savedTime) => {
    if (!savedTime) return true;
    return Date.now() - savedTime > MIN_REFRESH_INTERVAL;
  }, []);

  const fetchWeather = useCallback(async (location, lang = language, force = false) => {
    if (!location) return;
    
    const currentFetchId = ++fetchIdRef.current;
    
    setIsLoading(true);
    setError(null);
    setLocationError(false);
    
    try {
      const data = await weatherProvider.getWeather(location, lang, 5);
      
      if (currentFetchId !== fetchIdRef.current) return;
      
      setWeatherData(data);
      setForecastData(data);
      setCurrentLocation({
        name: `${data.location.name}, ${data.location.country}`,
        tz_id: data.location.tz_id,
        coords: `${data.location.lat},${data.location.lon}`
      });
      setLastUpdateTime(Date.now());
    } catch (err) {
      if (currentFetchId !== fetchIdRef.current) return;
      console.error('Fetch weather error:', err);
      setError(err.message);
      setLocationError(true);
    } finally {
      if (currentFetchId === fetchIdRef.current) {
        setIsLoading(false);
        setIsRefreshing(false);
      }
    }
  }, [language, weatherProvider]);

  const handleRefresh = useCallback(() => {
    setIsRefreshing(true);
    if (typeof currentLocation === 'object' && currentLocation.coords) {
      fetchWeather(currentLocation.coords, language, true);
    } else {
      fetchWeather(currentLocation, language, true);
    }
  }, [currentLocation, fetchWeather, language]);

  // ========================================
  // getCurrentLocation — простой и надёжный
  // ========================================
  const getCurrentLocation = useCallback((force = false) => {
    if (isGettingLocationRef.current) {
      console.log('📍 getCurrentLocation: Already in progress');
      return;
    }
    
    isGettingLocationRef.current = true;
    setIsRefreshing(true);
    setError(null);
    setLocationError(false);

    console.log('📍 getCurrentLocation: Starting');

    let finished = false;

    const handleSuccess = (lat, lon, source) => {
      if (finished) {
        console.log('📍 Ignoring late success from:', source);
        return;
      }
      finished = true;
      cleanupAll();
      
      console.log('📍 Got coordinates from', source, ':', lat, lon);
      isGettingLocationRef.current = false;
      localStorage.setItem('hasRequestedLocation', 'true');
      localStorage.removeItem('locationRemindLater');
      fetchWeather(`${lat},${lon}`, language, true);
    };

    const handleFinalError = (msg) => {
      if (finished) {
        console.log('📍 Ignoring late error:', msg);
        return;
      }
      finished = true;
      cleanupAll();
      
      console.error('📍 Final location error:', msg);
      isGettingLocationRef.current = false;
      setError(msg);
      setLocationError(true);
      setIsRefreshing(false);
    };

    // === Общий cleanup ===
    let cleanupFunctions = [];
    const cleanupAll = () => {
      cleanupFunctions.forEach(fn => fn());
      cleanupFunctions = [];
    };

    // === Всегда слушаем Android события (если bridge есть) ===
    if (window.Android) {
      let androidListenersCleaned = false;

      const onLocationUpdate = (event) => {
        const data = event.detail;
        console.log('📍 Android location update event:', data);
        
        if (data && data.latitude && data.longitude && 
            data.latitude !== 0 && data.longitude !== 0) {
          handleSuccess(data.latitude, data.longitude, 'android');
        }
      };

      const onLocationError = (event) => {
        console.log('📍 Android location error event:', event.detail);
        // Не вызываем handleFinalError — даём browser шанс
      };

      const onPermissionResult = (event) => {
        const detail = event.detail;
        console.log('📍 Android permission result event:', detail);
        
        // Если пришёл объект с координатами
        if (detail && typeof detail === 'object' && detail.latitude && detail.longitude &&
            detail.latitude !== 0 && detail.longitude !== 0) {
          handleSuccess(detail.latitude, detail.longitude, 'android-permission');
          return;
        }

        const granted = typeof detail === 'boolean' ? detail : detail?.granted;
        if (granted && detail && detail.latitude && detail.longitude &&
            detail.latitude !== 0 && detail.longitude !== 0) {
          handleSuccess(detail.latitude, detail.longitude, 'android-permission-granted');
        }
      };

      window.addEventListener('androidLocationUpdate', onLocationUpdate);
      window.addEventListener('androidLocationError', onLocationError);
      window.addEventListener('androidLocationPermissionResult', onPermissionResult);

      cleanupFunctions.push(() => {
        if (!androidListenersCleaned) {
          androidListenersCleaned = true;
          window.removeEventListener('androidLocationUpdate', onLocationUpdate);
          window.removeEventListener('androidLocationError', onLocationError);
          window.removeEventListener('androidLocationPermissionResult', onPermissionResult);
        }
      });

      // Запрашиваем у Android
      if (typeof window.Android.requestLocationPermission === 'function') {
        try {
          console.log('📍 Calling Android.requestLocationPermission()');
          window.Android.requestLocationPermission();
        } catch (err) {
          console.error('📍 Android API call failed:', err);
        }
      }
    }

    // === Браузерная геолокация — запускаем ВСЕГДА параллельно ===
    const tryBrowser = (retryCount = 0) => {
      if (finished) return;
      
      console.log('📍 Browser geolocation attempt:', retryCount + 1);
      
      if (!navigator.geolocation) {
        // Если Android тоже не сработал — ошибка
        if (!window.Android) {
          handleFinalError(t('location.error.geolocationUnsupported'));
        }
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          handleSuccess(position.coords.latitude, position.coords.longitude, 'browser');
        },
        (err) => {
          if (finished) return;
          
          console.error('📍 Browser error:', err.code, 'attempt:', retryCount + 1);

          // PERMISSION_DENIED — retry (WebView может не применить сразу)
          if (err.code === 1 && retryCount < 2) {
            console.log('📍 Permission denied, retry after delay...');
            setTimeout(() => {
              if (!finished) tryBrowser(retryCount + 1);
            }, 1500);
            return;
          }

          // POSITION_UNAVAILABLE — retry
          if (err.code === 2 && retryCount < 2) {
            console.log('📍 Position unavailable, retry after delay...');
            setTimeout(() => {
              if (!finished) tryBrowser(retryCount + 1);
            }, 2000);
            return;
          }

          // TIMEOUT — попытка с низкой точностью
          if (err.code === 3 && retryCount < 1) {
            console.log('📍 Timeout, retry with low accuracy...');
            
            navigator.geolocation.getCurrentPosition(
              (position) => {
                handleSuccess(position.coords.latitude, position.coords.longitude, 'browser-low');
              },
              (retryErr) => {
                if (finished) return;
                // Все браузерные попытки исчерпаны
                // Если Android bridge есть — ждём ещё немного
                if (window.Android) {
                  console.log('📍 Browser exhausted, waiting for Android...');
                  setTimeout(() => {
                    if (!finished) {
                      handleFinalError(t('location.error.timeout'));
                    }
                  }, 10000);
                } else {
                  handleFinalError(t('location.error.timeout'));
                }
              },
              { enableHighAccuracy: false, timeout: 20000, maximumAge: 300000 }
            );
            return;
          }

          // Все браузерные попытки исчерпаны
          if (window.Android) {
            // Ждём Android
            console.log('📍 Browser failed, waiting for Android response...');
            setTimeout(() => {
              if (!finished) {
                switch (err.code) {
                  case 1:
                    handleFinalError(t('location.error.permissionDeniedBrowser'));
                    break;
                  case 2:
                    handleFinalError(t('location.error.positionUnavailable'));
                    break;
                  case 3:
                    handleFinalError(t('location.error.timeout'));
                    break;
                  default:
                    handleFinalError(t('location.error.general'));
                }
              }
            }, 10000);
          } else {
            switch (err.code) {
              case 1:
                handleFinalError(t('location.error.permissionDeniedBrowser'));
                break;
              case 2:
                handleFinalError(t('location.error.positionUnavailable'));
                break;
              case 3:
                handleFinalError(t('location.error.timeout'));
                break;
              default:
                handleFinalError(t('location.error.general'));
            }
          }
        },
        {
          enableHighAccuracy: retryCount === 0,
          timeout: retryCount === 0 ? 10000 : 15000,
          maximumAge: force ? 0 : 60000
        }
      );
    };

    // Запускаем браузерную геолокацию
    // Если Android — с небольшой задержкой, чтобы разрешение успело примениться
    if (window.Android) {
      setTimeout(() => {
        if (!finished) tryBrowser();
      }, 2000);
    } else {
      tryBrowser();
    }

    // Общий таймаут на всё
    const globalTimeout = setTimeout(() => {
      if (!finished) {
        handleFinalError(t('location.error.timeout'));
      }
    }, 45000);

    cleanupFunctions.push(() => clearTimeout(globalTimeout));

  }, [fetchWeather, language, t]);

  // Реагируем на userLocation из App
  useEffect(() => {
    if (!userLocation || !userLocation.latitude || !userLocation.longitude) return;
    
    console.log('📍 useWeatherData: userLocation changed:', userLocation);
    initialLoadDoneRef.current = true;
    
    fetchWeather(
      `${userLocation.latitude},${userLocation.longitude}`,
      language,
      true
    );
  }, [userLocation]); // eslint-disable-line react-hooks/exhaustive-deps

  // Загрузка данных после решения пользователя
  useEffect(() => {
    if (!locationDecided) {
      console.log('📍 Waiting for location decision...');
      return;
    }

    if (userLocation && userLocation.latitude && userLocation.longitude) {
      setInitialized(true);
      return;
    }

    if (initialLoadDoneRef.current) {
      setInitialized(true);
      return;
    }

    const loadSavedData = async () => {
      console.log('📍 Loading saved data');
      const savedData = localStorage.getItem(STORAGE_KEY);
      
      try {
        if (savedData) {
          const parsedData = JSON.parse(savedData);
          
          setSavedCities(parsedData.savedCities || []);
          setUnits(parsedData.units || 'metric');
          setTheme(parsedData.theme || 'auto');
          setWeatherType(parsedData.weatherType || WEATHER_TYPES.CLEAR);
          setLanguage(parsedData.language || 'ru');
          setTimeFormat(parsedData.timeFormat || '24h');
          setLastUpdateTime(parsedData.lastUpdateTime || null);
          
          await i18n.changeLanguage(parsedData.language || 'ru');
          
          if (parsedData.weatherData && parsedData.forecastData && 
              !shouldRefreshOnLoad(parsedData.lastUpdateTime)) {
            setWeatherData(parsedData.weatherData);
            setForecastData(parsedData.forecastData);
            setCurrentLocation(parsedData.lastLocation || 'Moscow, Russia');
            setIsLoading(false);
            initialLoadDoneRef.current = true;
            setInitialized(true);
            return;
          }
          
          if (parsedData.lastLocation) {
            const location = typeof parsedData.lastLocation === 'object' 
              ? parsedData.lastLocation.coords || parsedData.lastLocation.name
              : parsedData.lastLocation;
            await fetchWeather(location);
          } else {
            await fetchWeather('Moscow');
          }
        } else {
          await fetchWeather('Moscow');
        }
      } catch (err) {
        console.error('Error loading saved data:', err);
        await fetchWeather('Moscow');
      } finally {
        initialLoadDoneRef.current = true;
        setInitialized(true);
      }
    };

    loadSavedData();
  }, [locationDecided]); // eslint-disable-line react-hooks/exhaustive-deps

  // Save data
  useEffect(() => {
    if (!initialized || !weatherData) return;
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      savedCities, units, theme, lastLocation: currentLocation,
      weatherType, language, timeFormat, lastUpdateTime,
      weatherData, forecastData
    }));
  }, [initialized, weatherData, forecastData, currentLocation, savedCities, units, theme, weatherType, language, timeFormat, lastUpdateTime]);

  // Search
  useEffect(() => {
    if (searchQuery.trim().length < 2) {
      setSearchResults([]);
      return;
    }

    const timer = setTimeout(async () => {
      try {
        const results = await weatherProvider.searchLocations(searchQuery, language);
        setSearchResults(results);
      } catch (err) {
        setSearchResults([{ error: true, message: `${t('search.error')}: ${err.message}` }]);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery, t, language, weatherProvider]);

  const handleLanguageChange = async (newLang) => {
    if (language === newLang || isChangingLanguage) return;
    
    try {
      setIsChangingLanguage(true);
      await i18n.changeLanguage(newLang);
      setLanguage(newLang);
      
      const loc = typeof currentLocation === 'object' 
        ? currentLocation.coords || currentLocation.name 
        : currentLocation;
      await fetchWeather(loc, newLang, true);
    } catch (err) {
      console.error('Language change failed:', err);
    } finally {
      setIsChangingLanguage(false);
    }
  };

  useEffect(() => {
    if (!weatherData) return;
    setWeatherType(weatherProvider.getWeatherType(weatherData.current.condition.code));
  }, [weatherData, weatherProvider]);

  useEffect(() => {
    if (!weatherData) return;
    const hours = new Date(weatherData.location.localtime).getHours();
    setTimeOfDay(hours >= 6 && hours < 18 ? 'day' : 'night');
  }, [weatherData]);

  const formatTime = (dateString) => {
    return new Date(dateString).toLocaleTimeString(
      language === 'ru' ? 'ru-RU' : 'en-US',
      { hour: '2-digit', minute: '2-digit', hour12: timeFormat === '12h', timeZone: weatherData?.location?.tz_id }
    );
  };

/*  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString(
      language === 'ru' ? 'ru-RU' : 'en-US',
      { weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit', hour12: timeFormat === '12h', timeZone: weatherData?.location?.tz_id }
    );
  };*/
  
  const formatDate = (dateString) => {
  // Парсим строку вручную, чтобы избежать проблем с часовыми поясами
  const [datePart, timePart] = dateString.split(' ');
  const [year, month, day] = datePart.split('-').map(Number);
  const [hours, minutes] = timePart.split(':').map(Number);

  // Создаём дату через UTC, чтобы браузер не вмешивался
  const date = new Date(Date.UTC(year, month - 1, day, hours, minutes));

  const dateStr = date.toLocaleDateString(
    language === 'ru' ? 'ru-RU' : 'en-US',
    {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      timeZone: 'UTC'  // ← Ключевой момент: говорим "не конвертируй"
    }
  );

  // Форматируем время вручную
  let timeStr;
  if (timeFormat === '12h') {
    const period = hours >= 12 ? 'PM' : 'AM';
    const h12 = hours % 12 || 12;
    timeStr = `${h12}:${minutes.toString().padStart(2, '0')} ${period}`;
  } else {
    timeStr = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  }

  return `${dateStr}, ${timeStr}`;
};

  const formatWeekday = (dateString) => {
    return new Date(dateString).toLocaleDateString(
      language === 'ru' ? 'ru-RU' : 'en-US',
      { weekday: 'long', timeZone: weatherData?.location?.tz_id }
    );
  };

  const formatShortDate = (dateString) => {
    return new Date(dateString).toLocaleDateString(
      language === 'ru' ? 'ru-RU' : 'en-US',
      { day: 'numeric', month: 'short', timeZone: weatherData?.location?.tz_id }
    );
  };

  const formatRelativeTime = (timestamp) => {
    if (!timestamp) return t('neverUpdated');
    const diff = Math.floor((Date.now() - timestamp) / 1000);
    if (diff < 60) return t('justNow');
    const mins = Math.floor(diff / 60);
    if (mins < 60) return t('minutesAgo', { count: mins });
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return t('hoursAgo', { count: hrs });
    return t('daysAgo', { count: Math.floor(hrs / 24) });
  };

  const addSavedCity = (city) => {
    if (!savedCities.some(c => c.name === city.name && c.country === city.country)) {
      setSavedCities([...savedCities, city]);
    }
  };

  const removeSavedCity = (index) => setSavedCities(savedCities.filter((_, i) => i !== index));

  const useDefaultLocation = () => {
    fetchWeather('Moscow');
    setLocationError(false);
  };

  const getTemp = (tempC, tempF) => units === 'metric' ? Math.round(tempC) : Math.round(tempF);
  const getWindSpeed = (kph) => units === 'metric' ? `${kph} ${t('units.kmh')}` : `${Math.round(kph * 0.621371)} ${t('units.mph')}`;
  const getPrecip = (mm) => units === 'metric' ? `${mm} ${t('units.mm')}` : `${Math.round(mm * 0.0393701)} ${t('units.in')}`;
  const getAirQualityIndex = (current) => current?.air_quality ? Math.round(current.air_quality['us-epa-index']) : null;

  return {
    currentLocation, weatherData, forecastData, searchQuery, searchResults,
    savedCities, activeTab, isLoading, error, locationError, weatherType,
    units, theme, showSearch, language, isChangingLanguage, timeFormat,
    lastUpdateTime, isRefreshing, timeOfDay,
    setSearchQuery, setActiveTab, setShowSearch, setUnits, setTheme,
    setTimeFormat, fetchWeather, getCurrentLocation, handleRefresh,
    handleLanguageChange, addSavedCity, removeSavedCity, useDefaultLocation,
    formatDate, formatTime, formatWeekday, formatShortDate, formatRelativeTime,
    getTemp, getWindSpeed, getPrecip, getAirQualityIndex, setError,           // ← ДОБАВИТЬ
    setLocationError    
  };
};