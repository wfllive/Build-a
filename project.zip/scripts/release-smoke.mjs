/**
 * Смоук-тест релизной сборки: эмулирует запуск бандла ВНУТРИ Android WebView.
 *
 * Зачем нужен: debug грузит приложение с dev-сервера (http://localhost:3000),
 * а release — из ассетов (file:///android_asset/dist/index.html). Это разные
 * origin'ы с разными ограничениями браузера, поэтому ошибка вида «в debug всё
 * работает, в release белый экран» ловится только здесь.
 *
 * Что проверяется:
 *   • бандл собирается;
 *   • на origin file:// приложение реально монтируется в #root;
 *   • нет необработанных исключений на старте;
 *   • мост отдаёт insets и они превращаются в CSS-переменные.
 *
 * Запуск (jsdom ставится один раз):
 *   npm i -D jsdom
 *   node scripts/release-smoke.mjs
 *
 * Исторический пример пойманной здесь ошибки:
 *   SecurityError: replaceState() cannot update history to the URL file:///
 *   — BrowserRouter не работает на file://, нужен HashRouter.
 */

import * as esbuild from 'esbuild';
import { JSDOM } from 'jsdom';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const r = (p) => path.resolve(root, p);
const outfile = path.join(os.tmpdir(), 'meteo-release-smoke.js');

// ── 1. Сборка ────────────────────────────────────────────────────────────────

await esbuild.build({
  entryPoints: [r('src/index.jsx')],
  bundle: true,
  outfile,
  format: 'iife',
  platform: 'browser',
  target: 'es2020',
  jsx: 'automatic',
  loader: {
    '.js': 'jsx', '.jsx': 'jsx', '.png': 'empty', '.svg': 'empty',
    '.css': 'empty', '.json': 'json',
  },
  define: { 'process.env.NODE_ENV': '"production"' },
  alias: {
    '@': r('src'),
    '@assets': r('src/assets'),
    drawer: r('src/drawer'),
    pages: r('src/pages'),
    localization: r('src/localization'),
    weather: r('src/weather'),
    'weather-ui': r('src/weather/ui'),
    'weather-widgets': r('src/weather/weather-widgets'),
    'weather-icons': r('src/weather/icons'),
  },
  logLevel: 'error',
});

// ── 2. Окружение как в Android WebView (origin file://) ──────────────────────

const errors = [];
const dom = new JSDOM(
  '<!doctype html><html><head></head><body><div id="root"></div></body></html>',
  {
    runScripts: 'outside-only',
    pretendToBeVisual: true,
    url: 'file:///android_asset/dist/index.html',
  }
);
const { window } = dom;

window.matchMedia = window.matchMedia || ((query) => ({
  matches: false, media: query, onchange: null,
  addListener() {}, removeListener() {},
  addEventListener() {}, removeEventListener() {}, dispatchEvent() {},
}));
window.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} };
window.IntersectionObserver = class {
  observe() {} unobserve() {} disconnect() {} takeRecords() { return []; }
};
window.visualViewport = { width: 412, height: 915, addEventListener() {}, removeEventListener() {} };
window.scrollTo = () => {};
// jsdom не реализует прокрутку элементов, в WebView она есть
window.Element.prototype.scrollTo = window.Element.prototype.scrollTo || function () {};
window.Element.prototype.scrollIntoView = window.Element.prototype.scrollIntoView || function () {};
window.requestAnimationFrame = (cb) => setTimeout(() => cb(Date.now()), 0);
window.cancelAnimationFrame = (id) => clearTimeout(id);
window.fetch = async () => ({ ok: false, status: 500, json: async () => ({}), text: async () => '' });

// canvas в jsdom не реализован
const canvasCtx = new Proxy({}, {
  get: (target, key) => (key === 'canvas' ? {} : (key in target ? target[key] : () => ({ data: [] }))),
  set: () => true,
});
window.HTMLCanvasElement.prototype.getContext = () => canvasCtx;
window.HTMLCanvasElement.prototype.toDataURL = () => '';

// ── 3. Мок нативного моста (ровно те методы, что есть в NativeBridge.kt) ─────

const insetsJson = JSON.stringify({
  px: {},
  css: {
    top: 0, bottom: 0, left: 0, right: 0,
    tappableBottom: 0, tappableLeft: 0, tappableRight: 0,
    imeBottom: 0, cutoutTop: 0, cutoutBottom: 0,
  },
  window: { css: { top: 96, bottom: 130, left: 0, right: 0, tappableBottom: 130 } },
  density: 2.75, navigationMode: 'buttons', isLandscape: false, keyboardVisible: false,
});

window.AndroidBridge = {
  bridgeVersion: () => 2,
  getInsets: () => insetsJson,
  requestInsets: () => {},
  isDarkMode: () => false,
  getAppVersion: () => '9.0.3',
  getDeviceInfo: () => '{}',
  getLocationStatus: () => 'denied',
  requestLocationPermission: () => {},
  mapUpdate: () => '{"ok":true}',
  mapSetUrl: () => {}, mapShow: () => {}, mapHide: () => {},
  mapReload: () => {}, mapSuspend: () => {}, mapRelease: () => {},
  mapStatus: () => '{}',
  getAdFreeState: () => '{"adsDisabled":false,"canActivate":true}',
  isRewardedAdReady: () => false,
  showRewardedAd: () => '{"success":false}',
  activateAdFreeFor5Minutes: () => '{"ok":true}',
  checkForUpdates: () => {}, checkIsLatestVersion: () => {},
  startFlexibleUpdate: () => {}, installUpdate: () => {}, log: () => {},
};
window.Android = window.AndroidBridge;
window.AndroidTheme = {
  setTheme() {}, getCurrentTheme: () => 'auto',
  getSystemTheme: () => 'light', isDarkMode: () => false,
};
window.AndroidApi = { getApiKey: () => 'test' };

// ── 4. Запуск ────────────────────────────────────────────────────────────────

window.addEventListener('error', (e) => errors.push(`window.onerror: ${e.error?.stack || e.message}`));
window.addEventListener('unhandledrejection', (e) => errors.push(`unhandledrejection: ${e.reason}`));

const log = console.log;
console.error = (...args) => errors.push(`console.error: ${args.map(String).join(' ').slice(0, 400)}`);
console.warn = () => {};
console.log = () => {};

try {
  window.eval(fs.readFileSync(outfile, 'utf8'));
} catch (error) {
  errors.push(`THROW на верхнем уровне модуля: ${error.stack || error.message}`);
}

await new Promise((resolve) => setTimeout(resolve, 1500));

// ── 5. Результат ─────────────────────────────────────────────────────────────

const rootEl = window.document.getElementById('root');
const rendered = rootEl.childElementCount > 0;
const html = window.document.documentElement;

log('');
log('  origin              : file:///android_asset/dist/index.html');
log(`  #root детей         : ${rootEl.childElementCount}`);
log(`  разметки, символов  : ${(rootEl.innerHTML || '').length}`);
log(`  --app-bottom-gap    : ${html.style.getPropertyValue('--app-bottom-gap') || '(не задана)'}`);
log(`  data-nav-mode       : ${html.getAttribute('data-nav-mode')}`);
log(`  ошибок              : ${errors.length}`);
errors.slice(0, 10).forEach((e, i) => log(`    [${i + 1}] ${e.slice(0, 400)}`));
log('');
log(rendered && errors.length === 0
  ? '  ✅ Релизный бандл стартует на file:// без ошибок'
  : '  ❌ ПРОБЛЕМА: в release будет белый экран (см. ошибки выше)');
log('');

process.exit(rendered && errors.length === 0 ? 0 : 1);
