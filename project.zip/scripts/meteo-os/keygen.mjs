#!/usr/bin/env node
/**
 * Meteo OS — генерация пары ключей для подписи OTA-обновлений.
 *
 * Запускается ОДИН раз:
 *   node scripts/meteo-os/keygen.mjs
 *
 * Результат:
 *   scripts/meteo-os/meteo_os_private.pem     — ПРИВАТНЫЙ ключ.
 *       Никогда не коммитить (уже в .gitignore). Хранить как пароль:
 *       им подписывается каждый релиз (pack.mjs).
 *
 *   android/app/src/main/assets/meteo_os_public.pem — ПУБЛИЧНЫЙ ключ.
 *       Вшивается в APK; им приложение проверяет подпись манифеста.
 *       Коммитится в репозиторий.
 *
 * После генерации нужно пересобрать APK, чтобы публичный ключ попал в assets.
 */

import { generateKeyPairSync } from 'node:crypto';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, '..', '..');

const privatePath = join(__dirname, 'meteo_os_private.pem');
const publicPath = join(root, 'android', 'app', 'src', 'main', 'assets', 'meteo_os_public.pem');

if (existsSync(privatePath)) {
  console.error(`Приватный ключ уже существует: ${privatePath}`);
  console.error('Если действительно нужен новый — удалите старый вручную.');
  console.error('ВНИМАНИЕ: со сменой ключа старые APK перестанут принимать новые обновления!');
  process.exit(1);
}

const { publicKey, privateKey } = generateKeyPairSync('rsa', {
  modulusLength: 3072,
  publicKeyEncoding: { type: 'spki', format: 'pem' },
  privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
});

mkdirSync(dirname(publicPath), { recursive: true });
writeFileSync(privatePath, privateKey, { mode: 0o600 });
writeFileSync(publicPath, publicKey);

console.log('Ключи Meteo OS сгенерированы:');
console.log(`  приватный (СЕКРЕТ): ${privatePath}`);
console.log(`  публичный (в APK):  ${publicPath}`);
console.log('');
console.log('Дальше:');
console.log('  1. Сделайте резервную копию приватного ключа в надёжном месте.');
console.log('  2. Пересоберите APK — публичный ключ должен попасть в assets.');
console.log('  3. Публикуйте релизы через scripts/meteo-os/pack.mjs.');
