#!/usr/bin/env node
/**
 * Meteo OS — упаковка OTA-релиза веб-бандла.
 *
 * Берёт собранный vite-бандл (android/app/src/main/assets/dist), собирает из
 * него zip, считает SHA-256, подписывает манифест приватным RSA-ключом и
 * складывает всё в release/meteo-os/:
 *
 *   meteo-os-<версия>.zip  — сам бандл (загрузить в GitHub Release)
 *   meteo-os.json          — манифест (загрузить в тот же Release)
 *
 * ВАЖНО: у Meteo OS СВОЯ линейка версий (1.0.0, 1.0.1, 1.1.0, ...),
 * НЕ связанная с versionName APK — чтобы обновления интерфейса не путались
 * с нативными обновлениями приложения в магазине.
 *
 * Использование:
 *   node scripts/meteo-os/keygen.mjs                # один раз: пара ключей
 *   npm run build                                   # свежий бандл
 *   node scripts/meteo-os/pack.mjs 1.0.1 --notes "Что нового"
 *
 * Если бандл требует новых методов моста (новый APK) — укажите минимальный
 * versionCode приложения: --min-version-code 94. Старые APK тогда покажут
 * «рекомендуем обновить приложение» вместо загрузки.
 *
 * Публикация (см. docs/meteo-os-updates.md):
 *   gh release create meteo-os-v1.0.1 release/meteo-os/meteo-os-1.0.1.zip \
 *      release/meteo-os/meteo-os.json --title "Meteo OS 1.0.1"
 *
 * APK при этом трогать не нужно: приложение само найдёт манифест по
 * BuildConfig.METEO_OS_MANIFEST_URL (releases/latest/download/meteo-os.json).
 */

import { createSign, createHash } from 'node:crypto';
import { execSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, '..', '..');

const DIST_DIR = join(root, 'android', 'app', 'src', 'main', 'assets', 'dist');
const OUT_DIR = join(root, 'release', 'meteo-os');
const PRIVATE_KEY = join(root, 'scripts', 'meteo-os', 'meteo_os_private.pem');

// GitHub-репозиторий, куда публикуются релизы Meteo OS.
const REPO = 'wfllive/Meteo-Live-off-9';

// ── Аргументы ────────────────────────────────────────────────────────────────

const args = process.argv.slice(2);
const version = args.find((a) => !a.startsWith('--'));
const notesIndex = args.indexOf('--notes');
const notes = notesIndex !== -1 ? args[notesIndex + 1] || '' : '';
const minVersionCodeIndex = args.indexOf('--min-version-code');
const minVersionCode = minVersionCodeIndex !== -1
  ? Number(args[minVersionCodeIndex + 1] || 0)
  : 0;

if (!version || !/^\d+(\.\d+)*([.-][A-Za-z0-9]+)*$/.test(version)) {
  console.error('Использование: node scripts/meteo-os/pack.mjs <версия> [--notes "..."] [--min-version-code N]');
  console.error('Пример:        node scripts/meteo-os/pack.mjs 1.0.1 --notes "Исправлен виджет ветра"');
  console.error('У Meteo OS своя линейка версий (1.x), не связанная с версией APK.');
  process.exit(1);
}

// ── Проверки ─────────────────────────────────────────────────────────────────

if (!existsSync(join(DIST_DIR, 'index.html'))) {
  console.error(`Не найден бандл: ${DIST_DIR}/index.html`);
  console.error('Сначала соберите веб: npm run build');
  process.exit(1);
}

mkdirSync(OUT_DIR, { recursive: true });

// ── Zip ──────────────────────────────────────────────────────────────────────

const zipName = `meteo-os-${version}.zip`;
const zipPath = join(OUT_DIR, zipName);

console.log(`Упаковываю ${DIST_DIR} → ${zipPath}`);
execSync(`cd "${DIST_DIR}" && rm -f "${zipPath}" && zip -r -q "${zipPath}" .`, { stdio: 'inherit', shell: '/bin/bash' });

const zipBytes = readFileSync(zipPath);
const sha256 = createHash('sha256').update(zipBytes).digest('hex');
const size = statSync(zipPath).size;

// ── Подпись ──────────────────────────────────────────────────────────────────
// Каноничная строка "version\nsha256\nsize" — её же проверяет
// MeteoOsUpdateManager.verifySignature() публичным ключом из assets.

let signature = null;
if (existsSync(PRIVATE_KEY)) {
  const signer = createSign('RSA-SHA256');
  signer.update(`${version}\n${sha256}\n${size}`, 'utf8');
  signature = signer.sign(readFileSync(PRIVATE_KEY, 'utf8')).toString('base64');
  console.log('Манифест подписан приватным ключом.');
} else {
  console.warn('⚠️  Приватный ключ не найден (scripts/meteo-os/meteo_os_private.pem).');
  console.warn('   Манифест НЕ подписан. Если в APK вшит публичный ключ — обновление будет отклонено.');
  console.warn('   Сгенерируйте пару: node scripts/meteo-os/keygen.mjs');
}

// ── Манифест ─────────────────────────────────────────────────────────────────

const manifest = {
  version,
  url: `https://github.com/${REPO}/releases/download/meteo-os-v${version}/${zipName}`,
  sha256,
  size,
  minVersionCode,
  notes,
  signature: signature || '',
  publishedAt: new Date().toISOString(),
};

const manifestPath = join(OUT_DIR, 'meteo-os.json');
writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + '\n');

console.log('');
console.log('Готово:');
console.log(`  ${zipPath}  (${(size / 1024 / 1024).toFixed(2)} МБ)`);
console.log(`  ${manifestPath}`);
console.log(`  SHA-256: ${sha256}`);
console.log('');
console.log('Публикация на GitHub:');
console.log(`  gh release create meteo-os-v${version} \\`);
console.log(`     "${zipPath}" "${manifestPath}" \\`);
console.log(`     --repo ${REPO} --title "Meteo OS ${version}" --notes "${notes || 'Обновление интерфейса'}" --latest`);
